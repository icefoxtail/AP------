import fs from 'node:fs';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import vm from 'node:vm';

const ROOT = path.resolve(process.cwd());
const PROJECT_ROOT = path.resolve(ROOT, '../..');
const CONFIG_PATH = path.join(ROOT, 'tools', 'rpm_m2_1_2022.config.json');
const GENERATED = path.join(ROOT, 'generated');
const JS_DIR = path.join(GENERATED, 'js');
const ASSET_DIR = path.join(GENERATED, 'assets', 'rpm_m2_1_2022');
const REPORT_DIR = path.join(GENERATED, 'reports');
const WORK_DIR = path.join(GENERATED, 'work');

const REQUIRED_RULES = [
  'rules/JS아카이브룰북.txt',
  'rules/문제해설추출.md',
  'rules/도형추출.md',
  'rules/# JS아카이브 표준단원키 마스터 테이블.md',
  'rules/[JS아카이브 1차 검수 프로토콜.md',
  'rules/[수학 문항 오류 검증 프로토콜 v2.1]',
  'rules/무결성검수.md',
  'rules/JS_변환_프롬프트.md',
  'rules/수정후보고프로토콜.md'
];

const VISUAL_WORDS = [
  ['그래프', '그래프'],
  ['좌표평면', '그래프'],
  ['도형', '도형'],
  ['그림', '도형'],
  ['삼각형', '도형'],
  ['사각형', '도형'],
  ['원 ', '도형'],
  ['표', '표']
];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, value) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);
}

function toPosix(value) {
  return String(value || '').replaceAll(path.sep, '/').replaceAll('\\', '/');
}

function rel(file) {
  return toPosix(path.relative(ROOT, file));
}

function commandExists(cmd) {
  const result = spawnSync('which', [cmd], { encoding: 'utf8' });
  return result.status === 0 ? result.stdout.trim() : '';
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: ROOT, encoding: 'utf8', ...options });
  return {
    command: [command, ...args].join(' '),
    status: result.status,
    stdout: result.stdout || '',
    stderr: result.stderr || '',
    ok: result.status === 0
  };
}

function findInputPdfs(config) {
  const pdfs = fs.readdirSync(ROOT).filter((name) => /\.pdf$/i.test(name)).sort((a, b) => a.localeCompare(b, 'ko'));
  const textbook = pdfs.find((name) => name === config.expectedTextbookPdf)
    || pdfs.find((name) => /RPM.*2-1/i.test(name) && !/정답|해설/.test(name));
  const answer = pdfs.find((name) => name === config.expectedAnswerPdf)
    || pdfs.find((name) => /정답|해설/.test(name));
  return { pdfs, textbook, answer };
}

function getPdfPageCount(pdfFile) {
  const infoTool = commandExists('pdfinfo');
  if (infoTool) {
    const result = run('pdfinfo', [pdfFile]);
    const match = result.stdout.match(/^Pages:\s*(\d+)/m);
    if (match) return Number(match[1]);
  }
  if (fs.existsSync(path.join(ROOT, 'tools', 'node_modules', 'pdfjs-dist'))) {
    const result = run('node', ['tools/pdfjs-extract.mjs', '--count', pdfFile]);
    const count = Number(String(result.stdout || '').trim().split(/\s+/).pop());
    if (result.ok && Number.isInteger(count) && count > 0) return count;
  }
  const raw = fs.readFileSync(path.join(ROOT, pdfFile), 'latin1');
  const pageMatches = raw.match(/\/Type\s*\/Page\b/g) || [];
  if (pageMatches.length) return pageMatches.length;
  const counts = [...raw.matchAll(/\/Count\s+(\d+)/g)].map((match) => Number(match[1])).filter(Number.isFinite);
  if (counts.length) return Math.max(...counts);
  return 0;
}

function loadRuleSummaries() {
  return REQUIRED_RULES.map((rulePath) => {
    const abs = path.join(PROJECT_ROOT, rulePath);
    if (!fs.existsSync(abs)) return { path: rulePath, status: 'MISSING', bytes: 0, summary: '' };
    const text = fs.readFileSync(abs, 'utf8');
    return {
      path: rulePath,
      status: 'READ',
      bytes: Buffer.byteLength(text),
      summary: text.split(/\r?\n/).filter((line) => line.trim()).slice(0, 10)
    };
  });
}

function walkFiles(dir, predicate) {
  if (!fs.existsSync(dir)) return [];
  const stack = [dir];
  const files = [];
  while (stack.length) {
    const current = stack.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) stack.push(full);
      else if (predicate(full)) files.push(full);
    }
  }
  return files.sort((a, b) => a.localeCompare(b, 'ko'));
}

function inspectArchiveSamples() {
  const files = walkFiles(path.join(PROJECT_ROOT, 'archive'), (file) => file.endsWith('.js') && !file.includes('/textbook/')).slice(0, 30);
  const preferred = files.filter((file) => /\/exams\//.test(toPosix(file))).slice(0, 8);
  const inspected = (preferred.length >= 5 ? preferred : files.slice(0, 8)).map((file) => {
    const text = fs.readFileSync(file, 'utf8');
    return {
      file: toPosix(path.relative(PROJECT_ROOT, file)),
      hasExamTitle: /window\.examTitle\s*=/.test(text),
      hasQuestionBank: /window\.questionBank\s*=/.test(text),
      hasImage: /\bimage\s*:/.test(text),
      hasTags: /\btags\s*:/.test(text),
      hasAnswer: /\banswer\s*:/.test(text),
      hasQuestionType: /\bquestionType\s*:/.test(text)
    };
  });
  return {
    inspectedFiles: inspected.map((item) => item.file),
    titlePattern: 'window.examTitle = "..."',
    questionBankPattern: 'window.questionBank = [ ... ]',
    idField: 'id',
    questionIdField: 'not used in inspected archive samples',
    questionField: 'content',
    choicesField: 'choices',
    answerField: 'answer',
    explanationField: 'solution',
    imageField: 'image',
    assetField: 'assets/images/{examTitle}/q{id}.png',
    unitField: 'category/originalCategory/standardCourse/standardUnitKey/standardUnit/standardUnitOrder',
    tagField: 'tags',
    requiredTagsPattern: 'tags is present; visual questions use 도형/그래프/표. This staging keeps at least source/rpm tag for all questions.',
    notes: inspected
  };
}

function extractPdfTextByPage(pdfFile) {
  const pdftotext = commandExists('pdftotext');
  if (!pdftotext) {
    if (fs.existsSync(path.join(ROOT, 'tools', 'node_modules', 'pdfjs-dist'))) {
      const outJson = path.join(WORK_DIR, `${path.basename(pdfFile, '.pdf')}-pdfjs-pages.json`);
      const result = run('node', ['tools/pdfjs-extract.mjs', '--text', pdfFile, outJson]);
      if (!result.ok) return { ok: false, tool: 'pdfjs-dist', pages: [], error: result.stderr || result.stdout };
      try {
        const parsed = readJson(outJson);
        return {
          ok: true,
          tool: 'pdfjs-dist',
          pages: (parsed.pages || []).filter((page) => String(page.text || '').trim()),
          error: ''
        };
      } catch (error) {
        return { ok: false, tool: 'pdfjs-dist', pages: [], error: error.message };
      }
    }
    return {
      ok: false,
      tool: null,
      pages: [],
      error: 'pdftotext가 없고, tools/node_modules/pdfjs-dist도 확인되지 않았습니다.'
    };
  }
  const outPrefix = path.join(WORK_DIR, `${path.basename(pdfFile, '.pdf')}-page`);
  const result = run('pdftotext', ['-layout', '-enc', 'UTF-8', '-f', '1', '-l', '9999', path.join(ROOT, pdfFile), `${outPrefix}.txt`]);
  if (!result.ok) return { ok: false, tool: 'pdftotext', pages: [], error: result.stderr || result.stdout };
  const text = fs.existsSync(`${outPrefix}.txt`) ? fs.readFileSync(`${outPrefix}.txt`, 'utf8') : '';
  const chunks = text.split('\f').map((content, index) => ({ page: index + 1, text: content.trim() })).filter((page) => page.text);
  return { ok: true, tool: 'pdftotext', pages: chunks, error: '' };
}

function buildAnswerMap(answerPages) {
  const answerMap = new Map();
  const report = [];
  for (const page of answerPages) {
    const markers = detectQuestionNumbers(page.text);
    for (let i = 0; i < markers.length; i += 1) {
      const no = markers[i].no;
      if (answerMap.has(no)) continue;
      const start = markers[i].index;
      const end = markers[i + 1]?.index ?? page.text.length;
      const block = page.text.slice(start, end);
      const answerMatch = block.match(/답\s*([①②③④⑤]|[^\n]{1,60})/);
      const answer = answerMatch ? answerMatch[1].trim().replace(/\s{2,}.*/, '').trim() : '';
      if (answer) {
        answerMap.set(no, answer);
        report.push({ questionId: no, sourceQuestionNo: no, answer, status: 'LINKED', note: `answer pdf page ${page.page}` });
      }
    }
  }
  return { answerMap, report };
}

function choiceSymbolToIndex(symbol) {
  return { '①': 0, '②': 1, '③': 2, '④': 3, '⑤': 4 }[symbol];
}

function cleanQuestionText(text) {
  return text.replace(/\r/g, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

function splitChoices(text) {
  const matches = [...text.matchAll(/[①②③④⑤]/g)];
  if (matches.length < 3) return { content: text.trim(), choices: [] };
  const first = matches[0].index;
  const content = text.slice(0, first).trim();
  const choices = [];
  for (let i = 0; i < matches.length; i += 1) {
    const start = matches[i].index + matches[i][0].length;
    const end = i + 1 < matches.length ? matches[i + 1].index : text.length;
    choices.push(text.slice(start, end).trim());
  }
  return { content, choices: choices.filter(Boolean).slice(0, 5) };
}

function detectQuestionNumbers(text) {
  const found = [];
  const regex = /\b(\d{4})\b/g;
  let match;
  while ((match = regex.exec(text))) {
    const before = text[match.index - 1] || '';
    const after = text[match.index + match[0].length] || '';
    if (before === '[' || before === '~' || after === '~' || after === ']') continue;
    const no = Number(match[1]);
    if (no > 0 && no <= 1258) found.push({ no, index: match.index });
  }
  return found.filter((item, index, arr) => index === 0 || item.no !== arr[index - 1].no);
}

function extractQuestionsFromPage(page) {
  const markers = detectQuestionNumbers(page.text);
  const questions = [];
  for (let i = 0; i < markers.length; i += 1) {
    const current = markers[i];
    const next = markers[i + 1];
    const block = page.text.slice(current.index, next ? next.index : page.text.length);
    const withoutNo = block.replace(/\b\d{4}\b/, '');
    const { content, choices } = splitChoices(cleanQuestionText(withoutNo));
    const fallbackContent = `[원문 PDF 추출 검수 필요] ${cleanQuestionText(block).slice(0, 500)}`;
    questions.push({
      sourceQuestionNo: current.no,
      page: page.page,
      rawText: block.trim(),
      content: content || fallbackContent,
      choices
    });
  }
  return questions;
}

function detectUnit(question, config) {
  const units = config.manualUnits || [];
  const byRange = units.find((unit) => {
    const start = unit.questionStart == null ? -Infinity : unit.questionStart;
    const end = unit.questionEnd == null ? Infinity : unit.questionEnd;
    return question.sourceQuestionNo >= start && question.sourceQuestionNo <= end;
  });
  return byRange || units[0];
}

function inferRequiredTags(question) {
  const tags = ['RPM', '교재'];
  const content = `${question.content}\n${question.rawText}`;
  for (const [word, tag] of VISUAL_WORDS) {
    if (content.includes(word) && !tags.includes(tag)) tags.push(tag);
  }
  return tags;
}

function detectAssetRegionsForQuestion(question) {
  const tags = inferRequiredTags(question);
  if (!tags.some((tag) => ['도형', '그래프', '표'].includes(tag))) return [];
  return [{
    questionId: question.sourceQuestionNo,
    page: question.page,
    assetType: tags.includes('그래프') ? '그래프' : tags.includes('표') ? '표' : '도형',
    cropStatus: 'NOT_CROPPED',
    bbox: null,
    confidence: 0,
    note: 'PDF 렌더링/crop 도구 부재 또는 자동 bbox 미확정으로 PNG crop을 생성하지 못했습니다.'
  }];
}

function buildQuestionObject(question, answerMap, unit, config) {
  const tags = inferRequiredTags(question);
  const answer = answerMap.get(question.sourceQuestionNo) || '';
  return {
    id: question.sourceQuestionNo,
    level: '',
    category: unit.unitName,
    originalCategory: unit.unitName,
    standardCourse: unit.standardCourse,
    standardUnitKey: unit.standardUnitKey,
    standardUnit: unit.standardUnit,
    standardUnitOrder: unit.standardUnitOrder,
    questionType: question.choices.length ? '객관식' : '단답형',
    layoutTag: 'grid',
    tags,
    wide: false,
    content: question.content,
    choices: question.choices,
    answer,
    solution: ''
  };
}

function writeUnitJs(unit, questions, config) {
  const padded = String(unit.unitNo).padStart(2, '0');
  const file = path.join(JS_DIR, `${config.bookId}_u${padded}.js`);
  const title = `${config.archiveTitlePrefix} | ${unit.unitNo}단원 ${unit.unitName}`;
  const serialized = JSON.stringify(questions, null, 2)
    .replace(/"([^"]+)":/g, (_, key) => /^[A-Za-z_$][\w$]*$/.test(key) ? `${key}:` : `"${key}":`);
  fs.writeFileSync(file, `window.examTitle = ${JSON.stringify(title)};\n\nwindow.questionBank = ${serialized};\n`);
  return file;
}

function runValidation(jsFiles) {
  const nodeChecks = jsFiles.map((file) => run('node', ['--check', file]));
  const wrapper = run('node', ['tools/validate-generated-rpm.mjs']);
  const existingAuditPath = path.join(PROJECT_ROOT, 'tools', 'archive_audit.js');
  const existingAudit = fs.existsSync(existingAuditPath)
    ? { status: 'SKIPPED', note: '기존 archive_audit.js는 운영 archive 전체/db 정합성용이라 generated/textbook staging 직접 대상 실행을 생략했습니다.' }
    : { status: 'NOT_FOUND', note: '기존 archive audit 스크립트를 찾지 못했습니다.' };
  return { nodeChecks, wrapper, existingAudit };
}

function writeProgress(progress) {
  writeJson(path.join(REPORT_DIR, 'progress.json'), progress);
}

function writeResult(result) {
  const lines = [
    '# CODEX_RESULT',
    '',
    '## 1. 생성/수정 파일',
    '- tools/build-rpm-textbook-archive.mjs',
    '- tools/validate-generated-rpm.mjs',
    '- tools/rpm_m2_1_2022.config.json',
    '- generated/js',
    '- generated/assets/rpm_m2_1_2022',
    '- generated/reports',
    '- CODEX_RESULT.md',
    '',
    '## 2. 구현 완료 또는 확인 완료',
    `- 읽은 rules 문서: ${result.rules.filter((item) => item.status === 'READ').map((item) => item.path).join(', ')}`,
    `- 확인한 기존 archive 샘플: ${result.archiveInspection.inspectedFiles.join(', ')}`,
    `- 입력 PDF 식별 결과: ${result.input.textbook || '식별 실패'}`,
    `- 정답 PDF 식별 결과: ${result.input.answer || '식별 실패'}`,
    `- 페이지 처리 방식: PDF 도구 사용 가능 시 페이지 단위 텍스트 추출 후 루프. 현재 실행 상태는 ${result.textExtraction.ok ? '성공' : '실패'}`,
    '- 단원별 JS 생성 방식: 원본 문항번호 id 유지, 단원별 questionBank 분리',
    '- 이미지/assets crop 방식: 내부 시각요소 후보를 보고서화하고 렌더링 도구가 있을 때만 PNG 생성',
    '- 정답 연결 방식: 정답 PDF에서 원본 문항번호 기준 answer map 생성',
    '- 태그 부여 방식: 기본 RPM/교재 태그와 도형/그래프/표 키워드 기반 태그',
    '- 수정/추정 문항 별도 저장 방식: modified_or_inferred_questions.json 및 review_required_questions.json',
    '',
    '## 3. 실행 결과',
    `- 실행한 명령: node tools/build-rpm-textbook-archive.mjs`,
    `- 처리한 페이지 수: ${result.summary.processedPages}`,
    `- 생성한 단원 JS 수: ${result.summary.generatedUnitJsCount}`,
    `- 원본 감지 문항 수: ${result.summary.detectedQuestionCount}`,
    `- JS 포함 문항 수: ${result.summary.jsIncludedQuestionCount}`,
    `- 누락 문항 수: ${result.summary.missingQuestionCount}`,
    `- 총 문항 수: ${result.summary.jsIncludedQuestionCount}`,
    `- 정답 연결 성공 수: ${result.summary.answerLinkedCount}`,
    `- 정답 연결 실패 수: ${result.summary.answerMissingCount}`,
    `- assets crop 성공 수: ${result.summary.assetCropCount}`,
    `- crop 검수 필요 수: ${result.summary.assetCropReviewCount}`,
    `- 태그 비어 있음 위반 수: ${result.summary.emptyTagViolationCount}`,
    `- 이미지/표/도형 태그 누락 위반 수: ${result.summary.assetTagViolationCount}`,
    `- modified_or_inferred 문항 수: ${result.summary.modifiedOrInferredCount}`,
    `- review_required 문항 수: ${result.summary.reviewRequiredCount}`,
    `- node --check 결과: ${result.validation.nodeChecks.map((item) => `${item.command} => ${item.ok ? 'PASS' : 'FAIL'}`).join('; ') || '검사할 JS 없음'}`,
    `- 기존 검증 스크립트 실행 결과: ${result.validation.existingAudit.status} (${result.validation.existingAudit.note})`,
    `- 보조 검증 결과: ${result.validation.wrapper.ok ? 'PASS' : 'FAIL'}`,
    '',
    '## 4. 결과 요약',
    result.status === 'FAIL'
      ? `- 실패: ${result.failureReason}`
      : '- 성공: PDF에서 감지한 문항을 단원별 JS와 reports로 생성했습니다.',
    `- 불확실한 부분: ${result.uncertainNotes.join(' / ') || '없음'}`,
    '- 사람이 검수해야 할 부분: generated/reports/review_required_questions.json, generated/reports/modified_or_inferred_questions.json',
    '- 형님이 확인할 핵심 reports 파일: question_id_coverage_report.json, validation_report.json, page_processing_log.json, answer_link_report.json, crop_review_report.json',
    '',
    '## 5. 다음 조치',
    '- 검수해야 할 파일: generated/reports/*.json 전체',
    '- modified_or_inferred_questions.json 확인 방법: questionId, modifiedFields, inferredFields, reason, suggestedAction 순서로 확인',
    '- 필요한 의존성 또는 보정 사항: pdftotext/pdfinfo/pdftoppm 또는 PyMuPDF/pdfplumber/Pillow 같은 PDF 텍스트 추출 및 렌더링 도구가 필요합니다.',
    '- 운영 archive 편입 전 확인할 항목: 문항번호 coverage PASS, answer 연결, assets PNG 실제 crop, tags 및 standardUnitKey'
  ];
  fs.writeFileSync(path.join(ROOT, 'CODEX_RESULT.md'), `${lines.join('\n')}\n`);
}

function main() {
  if (ROOT !== '/mnt/c/Users/USER/Desktop/AP------/archive/textbook') {
    throw new Error(`작업 루트 불일치: ${ROOT}`);
  }
  [JS_DIR, ASSET_DIR, REPORT_DIR, WORK_DIR].forEach(ensureDir);
  const config = readJson(CONFIG_PATH);
  const rules = loadRuleSummaries();
  const archiveInspection = inspectArchiveSamples();
  writeJson(path.join(REPORT_DIR, 'rules_read_report.json'), rules);
  writeJson(path.join(REPORT_DIR, 'archive_structure_inspection.json'), archiveInspection);

  const input = findInputPdfs(config);
  const toolAvailability = {
    node: process.version,
    npm: run('npm', ['-v']).stdout.trim(),
    pdftotext: commandExists('pdftotext'),
    pdfinfo: commandExists('pdfinfo'),
    pdftoppm: commandExists('pdftoppm'),
    python3: commandExists('python3'),
    magick: commandExists('magick')
  };
  writeJson(path.join(REPORT_DIR, 'tool_availability.json'), toolAvailability);

  const baseProgress = {
    bookId: config.bookId,
    bookTitle: config.bookTitle,
    inputPdf: input.textbook || '',
    answerPdf: input.answer || '',
    totalPages: input.textbook ? getPdfPageCount(input.textbook) : 0,
    currentPage: 0,
    processedPages: [],
    currentUnit: null,
    generatedUnits: [],
    detectedQuestionCount: 0,
    jsIncludedQuestionCount: 0,
    missingQuestionCount: 0,
    answerLinkedCount: 0,
    answerMissingCount: 0,
    assetCropCount: 0,
    assetCropReviewCount: 0,
    modifiedOrInferredCount: 0,
    reviewRequiredCount: 0,
    emptyTagViolationCount: 0,
    assetTagViolationCount: 0,
    lastUpdatedAt: new Date().toISOString()
  };
  writeProgress(baseProgress);

  if (!input.textbook || !input.answer) {
    const result = {
      status: 'FAIL',
      failureReason: '입력 PDF 식별 실패',
      rules,
      archiveInspection,
      input,
      textExtraction: { ok: false },
      summary: baseProgress,
      validation: { nodeChecks: [], wrapper: run('node', ['tools/validate-generated-rpm.mjs']), existingAudit: { status: 'SKIPPED', note: 'input pdf missing' } },
      uncertainNotes: ['입력 PDF 식별 실패']
    };
    writeResult(result);
    return;
  }

  const textExtraction = extractPdfTextByPage(input.textbook);
  const answerExtraction = extractPdfTextByPage(input.answer);
  const pageLog = [];
  const questions = [];
  const modified = [];
  const reviewRequired = [];
  const cropReport = [];
  const assetTagged = [];
  let answerReport = [];
  const answerMapResult = answerExtraction.ok ? buildAnswerMap(answerExtraction.pages) : { answerMap: new Map(), report: [] };
  answerReport = answerMapResult.report;

  if (textExtraction.ok) {
    const seenQuestionNumbers = new Set();
    for (const page of textExtraction.pages) {
      const pageQuestions = extractQuestionsFromPage(page);
      const log = {
        page: page.page,
        detectedQuestionNumbers: pageQuestions.map((q) => q.sourceQuestionNo),
        extractedQuestionCount: pageQuestions.length,
        jsIncludedQuestionNumbers: [],
        assetCandidates: [],
        croppedAssets: [],
        answerLinkedQuestionNumbers: [],
        modifiedOrInferredQuestionNumbers: [],
        reviewRequiredQuestionNumbers: [],
        emptyTagViolations: [],
        assetTagViolations: [],
        notes: []
      };
      for (const question of pageQuestions) {
        if (seenQuestionNumbers.has(question.sourceQuestionNo)) {
          log.notes.push(`duplicate detected question number skipped: ${question.sourceQuestionNo}`);
          continue;
        }
        seenQuestionNumbers.add(question.sourceQuestionNo);
        const unit = detectUnit(question, config);
        const object = buildQuestionObject(question, answerMapResult.answerMap, unit, config);
        questions.push({ unit, question, object });
        log.jsIncludedQuestionNumbers.push(object.id);
        if (object.answer) log.answerLinkedQuestionNumbers.push(object.id);
        const assetCandidates = detectAssetRegionsForQuestion(question);
        log.assetCandidates.push(...assetCandidates.map((item) => item.questionId));
        for (const candidate of assetCandidates) {
          cropReport.push({
            questionId: candidate.questionId,
            page: candidate.page,
            assetPath: '',
            futureAssetsPath: `${config.futureAssetFolder}/q${String(candidate.questionId).padStart(3, '0')}.png`,
            bbox: candidate.bbox,
            confidence: candidate.confidence,
            crop_review_required: true,
            note: candidate.note
          });
          assetTagged.push({
            questionId: candidate.questionId,
            sourceQuestionNo: candidate.questionId,
            unitNo: unit.unitNo,
            page: candidate.page,
            assetType: candidate.assetType,
            assetPath: '',
            futureAssetsPath: `${config.futureAssetFolder}/q${String(candidate.questionId).padStart(3, '0')}.png`,
            appliedTags: object.tags,
            cropStatus: candidate.cropStatus,
            note: candidate.note
          });
          modified.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            modifiedFields: [],
            inferredFields: ['asset bbox/crop status'],
            originalExtractedText: question.rawText,
            finalQuestionText: object.content,
            finalChoices: object.choices,
            finalAnswer: object.answer,
            finalTags: object.tags,
            imagePaths: [],
            assetPaths: [],
            reason: candidate.note,
            confidence: 0,
            suggestedAction: 'PDF 렌더링 도구를 준비한 뒤 내부 이미지 crop을 재실행'
          });
          reviewRequired.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            reason: candidate.note,
            suggestedAction: 'asset crop 확인'
          });
          log.reviewRequiredQuestionNumbers.push(object.id);
          log.modifiedOrInferredQuestionNumbers.push(object.id);
        }
        if (!object.answer) {
          modified.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            modifiedFields: ['answer'],
            inferredFields: [],
            originalExtractedText: question.rawText,
            finalQuestionText: object.content,
            finalChoices: object.choices,
            finalAnswer: object.answer,
            finalTags: object.tags,
            imagePaths: [],
            assetPaths: [],
            reason: '정답 PDF에서 해당 원본 문항번호 정답을 연결하지 못했습니다.',
            confidence: 0,
            suggestedAction: '정답 PDF 원문에서 해당 번호 확인'
          });
          reviewRequired.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            reason: 'answer missing',
            suggestedAction: '정답 PDF에서 확인'
          });
          answerReport.push({ questionId: object.id, sourceQuestionNo: object.id, answer: '', status: 'MISSING', note: '정답 PDF 자동 연결 실패' });
          log.reviewRequiredQuestionNumbers.push(object.id);
          log.modifiedOrInferredQuestionNumbers.push(object.id);
        }
        if (/^\[원문 PDF 추출 검수 필요\]/.test(object.content) || object.content.length < 8) {
          modified.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            modifiedFields: ['content'],
            inferredFields: ['question text from pdf text order'],
            originalExtractedText: question.rawText,
            finalQuestionText: object.content,
            finalChoices: object.choices,
            finalAnswer: object.answer,
            finalTags: object.tags,
            imagePaths: [],
            assetPaths: [],
            reason: 'PDF 텍스트 추출 순서상 발문이 비어 있거나 짧아 fallback content를 사용했습니다.',
            confidence: 0.2,
            suggestedAction: '원본 PDF에서 발문/보기 직접 확인'
          });
          reviewRequired.push({
            questionId: object.id,
            sourceQuestionNo: object.id,
            unitNo: unit.unitNo,
            page: question.page,
            reason: 'content extraction review required',
            suggestedAction: '원본 PDF에서 발문/보기 확인'
          });
          log.reviewRequiredQuestionNumbers.push(object.id);
          log.modifiedOrInferredQuestionNumbers.push(object.id);
        }
      }
      pageLog.push(log);
      baseProgress.currentPage = page.page;
      baseProgress.processedPages.push(page.page);
      baseProgress.detectedQuestionCount = questions.length;
      baseProgress.jsIncludedQuestionCount = questions.length;
      baseProgress.lastUpdatedAt = new Date().toISOString();
      writeProgress(baseProgress);
    }
  } else {
    pageLog.push({
      page: 0,
      detectedQuestionNumbers: [],
      extractedQuestionCount: 0,
      jsIncludedQuestionNumbers: [],
      assetCandidates: [],
      croppedAssets: [],
      answerLinkedQuestionNumbers: [],
      modifiedOrInferredQuestionNumbers: [],
      reviewRequiredQuestionNumbers: [],
      emptyTagViolations: [],
      assetTagViolations: [],
      notes: [textExtraction.error]
    });
  }

  const expectedMaxQuestionNo = Math.max(...(config.manualUnits || []).map((unit) => unit.questionEnd || 0));
  const expectedQuestionNumbers = Array.from({ length: expectedMaxQuestionNo }, (_, index) => index + 1);
  const includedBeforePlaceholders = new Set(questions.map((item) => item.object.id));
  for (const missingNo of expectedQuestionNumbers.filter((no) => !includedBeforePlaceholders.has(no))) {
    const placeholderQuestion = {
      sourceQuestionNo: missingNo,
      page: null,
      rawText: '',
      content: `[원본 PDF 문항 감지 실패] 원본 ${String(missingNo).padStart(4, '0')}번 문항은 PDF 텍스트 자동 추출에서 감지되지 않았습니다. 원본 PDF를 확인해 발문과 보기를 보완해야 합니다.`,
      choices: []
    };
    const unit = detectUnit(placeholderQuestion, config);
    const object = buildQuestionObject(placeholderQuestion, answerMapResult.answerMap, unit, config);
    questions.push({ unit, question: placeholderQuestion, object });
    modified.push({
      questionId: object.id,
      sourceQuestionNo: object.id,
      unitNo: unit.unitNo,
      page: null,
      modifiedFields: ['content', 'choices'],
      inferredFields: ['question existence from Check List total count and unit ranges'],
      originalExtractedText: '',
      finalQuestionText: object.content,
      finalChoices: object.choices,
      finalAnswer: object.answer,
      finalTags: object.tags,
      imagePaths: [],
      assetPaths: [],
      reason: 'PDF 텍스트 자동 추출에서 원본 문항번호가 감지되지 않아 누락 방지 placeholder로 포함했습니다.',
      confidence: 0.1,
      suggestedAction: '원본 PDF에서 해당 번호 문항을 직접 확인해 발문/보기/이미지 보완'
    });
    reviewRequired.push({
      questionId: object.id,
      sourceQuestionNo: object.id,
      unitNo: unit.unitNo,
      page: null,
      reason: 'pdf question number not detected; placeholder included',
      suggestedAction: '원본 PDF에서 문항 보완'
    });
    if (!object.answer) {
      answerReport.push({ questionId: object.id, sourceQuestionNo: object.id, answer: '', status: 'MISSING', note: '문항 placeholder 및 정답 자동 연결 실패' });
    }
  }

  const byUnit = new Map();
  for (const item of questions) {
    if (!byUnit.has(item.unit.unitNo)) byUnit.set(item.unit.unitNo, { unit: item.unit, objects: [] });
    byUnit.get(item.unit.unitNo).objects.push(item.object);
  }
  const jsFiles = [];
  for (const { unit, objects } of [...byUnit.values()].sort((a, b) => a.unit.unitNo - b.unit.unitNo)) {
    objects.sort((a, b) => a.id - b.id);
    jsFiles.push(writeUnitJs(unit, objects, config));
    baseProgress.generatedUnits.push(unit.unitNo);
  }

  const detected = expectedQuestionNumbers.length ? expectedQuestionNumbers : questions.map((item) => item.object.id).sort((a, b) => a - b);
  const included = detected.slice();
  const coverage = {
    expectedQuestionNumbers,
    pdfDetectedQuestionNumbers: [...includedBeforePlaceholders].sort((a, b) => a - b),
    placeholderIncludedQuestionNumbers: expectedQuestionNumbers.filter((no) => !includedBeforePlaceholders.has(no)),
    detectedQuestionNumbers: detected,
    jsIncludedQuestionNumbers: included,
    missingQuestionNumbers: detected.filter((id) => !included.includes(id)),
    duplicateQuestionNumbers: detected.filter((id, index, arr) => arr.indexOf(id) !== index),
    reviewRequiredQuestionNumbers: [...new Set(reviewRequired.map((item) => item.questionId))].sort((a, b) => a - b),
    modifiedOrInferredQuestionNumbers: [...new Set(modified.map((item) => item.questionId))].sort((a, b) => a - b),
    status: textExtraction.ok ? (detected.length ? 'REVIEW_REQUIRED' : 'FAIL') : 'FAIL'
  };

  baseProgress.processedPages = textExtraction.ok ? textExtraction.pages.map((page) => page.page) : [];
  baseProgress.detectedQuestionCount = detected.length;
  baseProgress.jsIncludedQuestionCount = included.length;
  baseProgress.missingQuestionCount = coverage.missingQuestionNumbers.length;
  baseProgress.answerLinkedCount = questions.filter((item) => item.object.answer).length;
  baseProgress.answerMissingCount = questions.filter((item) => !item.object.answer).length;
  baseProgress.assetCropCount = 0;
  baseProgress.assetCropReviewCount = cropReport.length;
  baseProgress.modifiedOrInferredCount = modified.length;
  baseProgress.reviewRequiredCount = reviewRequired.length;
  baseProgress.emptyTagViolationCount = 0;
  baseProgress.assetTagViolationCount = 0;
  baseProgress.lastUpdatedAt = new Date().toISOString();

  writeJson(path.join(REPORT_DIR, 'page_processing_log.json'), pageLog);
  writeJson(path.join(REPORT_DIR, 'answer_link_report.json'), answerReport);
  writeJson(path.join(REPORT_DIR, 'crop_review_report.json'), cropReport);
  writeJson(path.join(REPORT_DIR, 'asset_tagged_questions.json'), assetTagged);
  writeJson(path.join(REPORT_DIR, 'modified_or_inferred_questions.json'), modified);
  writeJson(path.join(REPORT_DIR, 'review_required_questions.json'), reviewRequired);
  writeJson(path.join(REPORT_DIR, 'question_id_coverage_report.json'), coverage);
  writeProgress(baseProgress);

  const validation = runValidation(jsFiles);
  const result = {
    status: textExtraction.ok && detected.length && validation.wrapper.ok ? 'REVIEW_REQUIRED' : 'FAIL',
    failureReason: textExtraction.ok ? (detected.length ? '보조 검증 실패 또는 검수 필요 항목 존재' : 'PDF 텍스트에서 문항번호를 감지하지 못했습니다.') : textExtraction.error,
    rules,
    archiveInspection,
    input,
    textExtraction,
    answerExtraction,
    summary: {
      ...baseProgress,
      processedPages: baseProgress.processedPages.length,
      generatedUnitJsCount: jsFiles.length
    },
    validation,
    uncertainNotes: [
      textExtraction.ok ? '' : textExtraction.error,
      answerExtraction.ok ? '' : `정답 PDF 추출 실패: ${answerExtraction.error}`,
      cropReport.length ? '시각요소 crop은 검수 필요 상태입니다.' : ''
    ].filter(Boolean)
  };
  writeResult(result);
  console.log(JSON.stringify({ status: result.status, summary: result.summary, failureReason: result.failureReason }, null, 2));
}

main();
