import fs from 'node:fs';
import path from 'node:path';
import * as pdfjs from './node_modules/pdfjs-dist/legacy/build/pdf.mjs';

async function loadDocument(pdfPath) {
  const data = new Uint8Array(fs.readFileSync(pdfPath));
  return pdfjs.getDocument({
    data,
    disableFontFace: true,
    useSystemFonts: true,
    stopAtErrors: false
  }).promise;
}

function joinTextItems(items) {
  const rows = new Map();
  for (const item of items) {
    if (!item.str || !String(item.str).trim()) continue;
    const y = Math.round(item.transform[5]);
    if (!rows.has(y)) rows.set(y, []);
    rows.get(y).push({ x: item.transform[4], text: item.str });
  }
  return [...rows.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([, row]) => row.sort((a, b) => a.x - b.x).map((item) => item.text).join(' '))
    .join('\n');
}

async function main() {
  const [mode, input, output] = process.argv.slice(2);
  if (!mode || !input) {
    console.error('usage: node tools/pdfjs-extract.mjs --count input.pdf | --text input.pdf output.json');
    process.exit(2);
  }
  const absInput = path.resolve(process.cwd(), input);
  const doc = await loadDocument(absInput);
  if (mode === '--count') {
    console.log(doc.numPages);
    return;
  }
  if (mode !== '--text' || !output) {
    console.error('usage: node tools/pdfjs-extract.mjs --text input.pdf output.json');
    process.exit(2);
  }
  const pages = [];
  for (let pageNo = 1; pageNo <= doc.numPages; pageNo += 1) {
    const page = await doc.getPage(pageNo);
    const content = await page.getTextContent({ includeMarkedContent: false });
    pages.push({
      page: pageNo,
      text: joinTextItems(content.items).trim()
    });
  }
  fs.mkdirSync(path.dirname(path.resolve(process.cwd(), output)), { recursive: true });
  fs.writeFileSync(path.resolve(process.cwd(), output), `${JSON.stringify({ pages }, null, 2)}\n`);
}

main().catch((error) => {
  console.error(error?.stack || error?.message || error);
  process.exit(1);
});
