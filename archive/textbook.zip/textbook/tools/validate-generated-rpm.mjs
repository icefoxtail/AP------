import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const ROOT = path.resolve(process.cwd());
const GENERATED = path.join(ROOT, 'generated');
const JS_DIR = path.join(GENERATED, 'js');
const REPORT_DIR = path.join(GENERATED, 'reports');

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function listJsFiles() {
  if (!fs.existsSync(JS_DIR)) return [];
  return fs.readdirSync(JS_DIR)
    .filter((name) => name.endsWith('.js'))
    .map((name) => path.join(JS_DIR, name))
    .sort((a, b) => a.localeCompare(b, 'ko'));
}

function loadQuestionBank(file) {
  const source = fs.readFileSync(file, 'utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: file });
  return {
    examTitle: sandbox.window.examTitle,
    questionBank: Array.isArray(sandbox.window.questionBank) ? sandbox.window.questionBank : []
  };
}

function hasNonEmptyTags(question) {
  return Array.isArray(question.tags) && question.tags.some((tag) => String(tag || '').trim());
}

function validate() {
  const requiredFields = [
    'id',
    'level',
    'category',
    'originalCategory',
    'standardCourse',
    'standardUnitKey',
    'standardUnit',
    'standardUnitOrder',
    'questionType',
    'layoutTag',
    'tags',
    'wide',
    'content',
    'choices',
    'answer',
    'solution'
  ];
  const report = {
    status: 'PASS',
    files: [],
    failures: [],
    warnings: [],
    summary: {
      jsFileCount: 0,
      questionCount: 0,
      emptyTagViolationCount: 0,
      assetTagViolationCount: 0,
      missingAssetFileCount: 0,
      duplicateQuestionNumbers: [],
      missingQuestionNumbers: []
    }
  };

  const files = listJsFiles();
  report.summary.jsFileCount = files.length;
  if (!files.length) {
    report.status = 'FAIL';
    report.failures.push('generated/js 아래에 검증할 JS 파일이 없습니다.');
  }

  const seen = new Map();
  for (const file of files) {
    const rel = path.relative(ROOT, file).replaceAll(path.sep, '/');
    const fileReport = { file: rel, questionCount: 0, failures: [], warnings: [] };
    try {
      const { examTitle, questionBank } = loadQuestionBank(file);
      if (!examTitle) fileReport.failures.push('window.examTitle 값 없음');
      if (!Array.isArray(questionBank)) fileReport.failures.push('window.questionBank 배열 아님');
      fileReport.questionCount = questionBank.length;
      report.summary.questionCount += questionBank.length;

      for (const question of questionBank) {
        const id = Number(question.id);
        if (!Number.isInteger(id)) fileReport.failures.push(`id 비정수: ${question.id}`);
        if (seen.has(id)) report.summary.duplicateQuestionNumbers.push(id);
        seen.set(id, rel);

        for (const field of requiredFields) {
          if (!(field in question)) fileReport.failures.push(`${id}번 필드 누락: ${field}`);
        }
        if (!String(question.content || '').trim()) fileReport.failures.push(`${id}번 content 비어 있음`);
        if (!hasNonEmptyTags(question)) {
          report.summary.emptyTagViolationCount += 1;
          fileReport.failures.push(`${id}번 tags 비어 있음`);
        }

        const tags = Array.isArray(question.tags) ? question.tags : [];
        const needsVisualTag = /\[도형필요\]|\[그래프필요\]|\[표필요\]|다음 그림|다음 그래프|아래 표|다음 표/.test(String(question.content || ''));
        if (needsVisualTag && !tags.some((tag) => ['도형', '그래프', '표'].includes(tag))) {
          report.summary.assetTagViolationCount += 1;
          fileReport.failures.push(`${id}번 시각요소 태그 누락`);
        }
        if (question.image) {
          const imageName = path.basename(question.image);
          const local = path.join(ROOT, 'generated', 'assets', 'rpm_m2_1_2022', imageName);
          if (!fs.existsSync(local)) {
            report.summary.missingAssetFileCount += 1;
            fileReport.failures.push(`${id}번 image 파일 없음: ${question.image}`);
          }
        }
      }
    } catch (error) {
      fileReport.failures.push(`로드 실패: ${error.message}`);
    }
    if (fileReport.failures.length) report.status = 'FAIL';
    report.files.push(fileReport);
  }

  const coverage = readJson(path.join(REPORT_DIR, 'question_id_coverage_report.json'), null);
  if (coverage) {
    report.summary.missingQuestionNumbers = coverage.missingQuestionNumbers || [];
    if (report.summary.missingQuestionNumbers.length) report.status = 'FAIL';
  }
  if (report.summary.duplicateQuestionNumbers.length) report.status = 'FAIL';

  fs.mkdirSync(REPORT_DIR, { recursive: true });
  fs.writeFileSync(path.join(REPORT_DIR, 'validation_report.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify({ status: report.status, summary: report.summary }, null, 2));
  if (report.status === 'FAIL') process.exitCode = 1;
}

validate();
