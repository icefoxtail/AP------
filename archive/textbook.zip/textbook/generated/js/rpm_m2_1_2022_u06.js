window.examTitle = "22개정 RPM 중학수학 2-1 | 6단원 연립일차방정식";

window.questionBank = [
  {
    id: 652,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0652",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 653,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-y=-2a\n연립방정식 [ 을 만족시키는 x 의 값이 y 의\n5x+4y=11\n2x-7y=a-3\n연립방정식 [ 의 해가 일차방정식 x-3y=6\n2x+y=a\n값의 3 배일 때, 상수 a 의 값을 구하시오.\n을 만족시킬 때, 상수 a 의 값을 구하시오.",
    choices: [],
    answer: "2a+7b=2_0+7_ ;7!; =1 1",
    solution: ""
  },
  {
    id: 654,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2y=x\n연립방정식 [ 의 해가 일차방정식\nx+ay=-6\n3x+5y=11 을 만족시킬 때, 상수 a 의 값은?",
    choices: [
      "-11",
      "-8",
      "-5",
      "-2",
      "0"
    ],
    answer: "②",
    solution: ""
  },
  {
    id: 655,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 세 일차방정식이 공통인 해를 가질 때, 상수 a 의 값을\n구하시오.\nx+2y=3 , 2x-3y=-1 , 2ax-3y=5",
    choices: [],
    answer: "∴ ab=4_(-5)=-20 -20",
    solution: ""
  },
  {
    id: 656,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0656",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 657,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+3y=a-10\n연립방정식 [ 을 만족시키는 x 의 값이 y 의\n4x-y=1\n값보다 4 만큼 클 때, 상수 a 의 값을 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 658,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ax+5y=-7a\n[ x y\n연립방정식 를 만족시키는 와 의 값의\n3x+y=4\n차가 8 일 때, 상수 a 의 값은? (단, x>y)\neunji010220@naver.com",
    choices: [
      "1",
      ";2#;",
      "2",
      ";2%;",
      "3"
    ],
    answer: "∴ a+b=2+5=7 7",
    solution: ""
  },
  {
    id: 659,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "방정식 5x-y=-ax+3y+8=10 을 만족시키는 x 와 y\n의 값의 비가 2` : `5 일 때, 상수 a 의 값을 구하시오.\n. 연립일차방정식\nIV\n96",
    choices: [],
    answer: "∴ b=-5",
    solution: ""
  },
  {
    id: 660,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 두 연립방정식의 해가 서로 같을 때, 상수 a , b 의 값은? ax+by=4\n[\n연립방정식 에서 잘못하여 a 와 b 를 바꾸어\nbx-ay=3\n놓고 풀었더니 x=2 , y=1 이었다. 이때 상수 a , b 에 대하\n-x+4y=11 -2x-5y=-4\n[ , [\nax+2y=-5 3x+by=-13 여 b-a 의 값을 구하시오.",
    choices: [
      "a=-1 , b=-2",
      "a=-1 , b=2",
      "a=1 , b=2",
      "a=3 , b=-2",
      "a=3 , b=2"
    ],
    answer: "∴ b-a=1-2=-1 -1",
    solution: ""
  },
  {
    id: 661,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x+7y=-9 ax-by=-13\n두 연립방정식 [ , [ 의 해가\nax+by=-3 4x+15y=-1\n서로 같을 때, 상수 a , b 에 대하여 a+b 의 값을 구하시오.",
    choices: [],
    answer: "-6",
    solution: ""
  },
  {
    id: 662,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ax+by=13 3x-5y=11\n두 연립방정식 [ , [ 의 해가",
    choices: [],
    answer: "∴ a= ;2%; ④",
    solution: ""
  },
  {
    id: 663,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0663",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 664,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ax-y=11\n[\n연립방정식 을 푸는데 윤호는 a 를 잘못 보고\n4x+by=7\n풀어서 x=1 , y=1 을 얻었고, 우진이는 b 를 잘못 보고 풀\n어서 x=5 , y=-1 을 얻었다. 이때 처음 연립방정식의 해\n를 구하시오. (단, a , b 는 상수이다.)",
    choices: [],
    answer: "∴ b=-2 ④",
    solution: ""
  },
  {
    id: 665,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-y=13\neunji010220@naver.com\n[\n연립방정식 을 풀 때, 2x-y=13 의 13 을\n9x-8y=10\n잘못 보고 풀어서 y=1 을 얻었다. 이때 13 을 어떤 수로 잘\n못 보고 풀었는지 구하시오.",
    choices: [],
    answer: "수히 많다. ②",
    solution: ""
  },
  {
    id: 666,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x+3y=5 ax-2by=-2\nax-by=6\n서로 같을 때, 상수 a , b 에 대하여 a-b 의 값을 구하시오.\n연립방정식 [ 에서 잘못하여 a 와 b 를 바꾸어\nbx-ay=1\n놓고 풀었더니 x=3 , y=2 이었다. 이때 처음 연립방정식\n의 해를 구하시오. (단, a , b 는 상수이다.)\n연립일차방정식\n06\n97",
    choices: [],
    answer: "-2",
    solution: ""
  },
  {
    id: 667,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0667",
    choices: [],
    answer: "따라서 해가 무수히 많다.",
    solution: ""
  },
  {
    id: 668,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y=6 4x-y=-8\n[ [",
    choices: [
      "보기\n다음 의 일차방정식 중 두 방정식을 한 쌍으로 하는 연\n2x-y=3 -6x-y=2\n립방정식을 만들었을 때, 해가 무수히 많은 것은?\n10x=5(3y-1) x-2y=5",
      "[",
      "[\n보기\n2x+1=3y 2x-y=3(y-3)\nㄱ. 2y=4-3x ㄴ. 2x+3y-4=0\nx+5y=12\n[",
      "ㄷ. 6x+4y-8=0 ㄹ. 3y=6-2x\n2(x-5y)-y=3",
      "ㄱ, ㄴ"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 669,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식 [ 의 해가 없을 때, 상수 a , b\n4x+2y=a+b\n(a+6)x-2y=-8\n연립방정식 [ 의 해가 무수히 많을\n의 조건을 구하시오.\n3x+(b-5)y=8\n때, 상수 a , b 에 대하여 a+b 의 값을 구하시오.\n. 연립일차방정식\nIV\n98",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 670,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x-4y=a 2y=3x-5\n연립방정식 [ 의 해가 무수히 많을 때, 상수 a , 연립방정식 [ 의 해가 없을 때, 상수 a 의 값을\nbx-8y=4 ay=6x+3\nb 의 값은? 구하시오.",
    choices: [
      "a=-2 , b=6",
      "a=1 , b=-6",
      "a=1 , b=5",
      "a=2 , b=-6",
      "a=2 , b=6"
    ],
    answer: "x=-2 , y=-3",
    solution: ""
  },
  {
    id: 671,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 연립방정식 중 해가 없는 것은?",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 672,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(a-1)x+y=3",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 673,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y\n2 =2Ü` x+y=3\n0.0 H 2x+0.0 H 3y=0.1\n[ 에서 [\nx-y\n[\n연립방정식 의 해는? 3 =3 x-y=1\n1. H 3x-y=3\n① x=-2 , y=4 ② x=1 , y=7",
    choices: [],
    answer: "a=3 b=2 ab=3_2=6 6",
    solution: ""
  },
  {
    id: 674,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0674",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 675,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "0. H 4(x-1)+1. H 2y=0. H 5\nx y y x y\n(2 _2 )Ü`Ö16 =8Ü` , 3 _(3 )Û`=3Ú`â`\n연립방정식 [ 의 해가\n0.0 H 1x+0.0 H 3(y-6)=-0.1 H 6\nx=a , y=b 일 때, b-a 의 값을 구하시오.",
    choices: [
      "3",
      "4",
      "5",
      "6",
      "7\n연립일차방정식\n06\n99"
    ],
    answer: "1단계 ∴ x+y=4+3=7 ⑤",
    solution: ""
  },
  {
    id: 676,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0676\n③ x=3 , y=1 ④ x=4 , y=3\n3x+2y x+5 3y-1\n2 =2 _2\n[\nx , y 가 자연수일 때, 연립방정식 의\n⑤ x=5 , y=3\nx 3y\n25 Ö5 =1\n해가 x=a , y=b 이다. 이때 ab 의 값을 구하시오.",
    choices: [
      "x=3 , y=1",
      "x=4 , y=3\n3x+2y x+5 3y-1\n2 =2 _2\n[\nx , y 가 자연수일 때, 연립방정식 의",
      "x=5 , y=3\nx 3y\n25 Ö5 =1\n해가 x=a , y=b 이다. 이때 ab 의 값을 구하시오."
    ],
    answer: "a=3 , b + 3",
    solution: ""
  },
  {
    id: 677,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 의 순서쌍 (p , q) 가 연립방정식\nx+1 y-1 x y\n2 _4 =16 9 _3 =81\n두 등식 , 을 모두 만족시키는\n0. H 5x-0. H 1y=-1. H 8\n( x y ax+3y-8=0\n자연수 , 가 일차방정식 을 만족시킬 때,\n{\nx+3 5-y\na\n상수 의 값은?\n-  =1\n¥ 9\n2 4",
    choices: [
      "-3",
      "-2",
      "-1\n의 해일 때, p+q 의 값은?",
      "1",
      "2"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 678,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 두 등식을 모두 만족시키는 자연수 x , y 에 대하여 x+y\n의 값은?",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 679,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0679",
    choices: [],
    answer: "∴ ab=-2_1=-2 ①",
    solution: ""
  },
  {
    id: 680,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "정식을 만들었더니 해가 x=5 , y=-2 이었다. 이때 두 일\n다음 중 문장을 미지수가 2 개인 일차방정식으로 나타낸 것\n차방정식을 모두 고른 것은?\n으로 옳지 않은 것은?\n보기",
    choices: [
      "300 원짜리 연필 x 자루와 500 원짜리 볼펜 y 자루의 가격\nㄱ. x+2y=4 ㄴ. 3x+y=13\n은 11000 원이다. 300x+500y=11000\nㄷ. 2x-5y=0 ㄹ. 3x+4y=7\neunji0102",
      "오리 x 마리와 소 y 마리의 다리의 개수의 합은 40 이다.\n2x+4y=40",
      "ㄱ, ㄴ",
      "ㄱ, ㄷ",
      "ㄴ, ㄷ"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 681,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식 [ 의 해가 x=2 , y=1 일 때, 상수\nx-y=b\n다음 x , y 의 순서쌍 중 일차방정식 2x-3y+9=0 의 해가\na , b 에 대하여 ab 의 값은?\n아닌 것은?",
    choices: [
      "-2",
      "-1",
      "0",
      "(-6 , -1)",
      "(-3 , 1)"
    ],
    answer: "다. ③ , ⑤",
    solution: ""
  },
  {
    id: 682,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 보기 중 미지수가 2 개인 일차방정식인 것을 모두 고른 1\nx , y 의 순서쌍 { 6 , -  } , (b , -1) 이 모두 일차방정식\n3\n것은?\nax-3y+1=0 의 해일 때, 3a+b 의 값은?\n보기\n(단, a 는 상수이다.)\nx\nㄱ. + ;8}; =0 ㄴ. ;[@; - ;]%; =6\n4",
    choices: [
      "11",
      "12`",
      "13\nㄷ. yÛ`+x=4 ㄹ. x=y-7",
      "14",
      "15\nㅁ. 2(x-y)=x-2y+1 ㅂ. x(y+3)=xy-y"
    ],
    answer: "⑤",
    solution: ""
  },
  {
    id: 683,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 보기 의 일차방정식 중 두 일차방정식을 택하여 연립방",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 684,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x+ay=4",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 685,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0685",
    choices: [],
    answer: "이상에서 미지수가 2 개인 일차방정식은 ㄱ, ㄹ, ㅂ이다. ④",
    solution: ""
  },
  {
    id: 686,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0686",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 687,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2 4 5\nx , y 의 순서쌍 (a+1 , 2-b) 가 연립방정식 x , y 에 대하여 y-x 의 값을 구하시오.\n3(2x-y)-4y=5\n[ 의 해일 때, a+b 의 값을 구하시오.\n7x-2(x+2y)=6\n연립일차방정식\n06\n101",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 688,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y+1\nx-1\n2x-3y=-4 (\n-  = ;2!;\n[\n다음 일차방정식 중 연립방정식 의 해를\n2 3\n연립방정식 { 의 해가 일차방정\n2x=5y+8\n0.2x-0.3(x-y)=-0.5\n¥ 9\n한 해로 갖는 것을 모두 고르면? (정답 2 개)\n식 ax+by=5 를 만족시킬 때, 상수 a , b 에 대하여",
    choices: [
      "x+y=-10",
      "x-2y=-1\n4a-2b 의 값을 구하시오.",
      "3x-5y=-3",
      "3y-x=-4",
      "4x=7y-2"
    ],
    answer: "∴ 2a+b=2_3+2=8 ④",
    solution: ""
  },
  {
    id: 689,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x-y=-11 yy` ㉠\n(x-1)`:`(y+1)=2`:`1\n[\n다음 중 연립방정식 에 대한 설명\n[\n연립방정식 을 풀면?\n2x+5y=4 yy` ㉡\n2x-3y=7\n으로 옳은 것은?",
    choices: [
      "x=-5 , y=-1",
      "x=-1 , y=-5",
      "㉠을 y=3x-11 로 변형하여 ㉡에 대입하여 풀 수 있",
      "x=1 , y=-5",
      "x=5 , y=-1\n다."
    ],
    answer: "a=-2-2=-4 -4",
    solution: ""
  },
  {
    id: 690,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-x+y-19 x+y-14\nx-2\n방정식 =  =  를 만족시키는",
    choices: [],
    answer: "9 ∴ a-b=3-(-2)=5 \b ⑤",
    solution: ""
  },
  {
    id: 691,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0691",
    choices: [],
    answer: "∴ a-b+c=6-5+1=2 ②",
    solution: ""
  },
  {
    id: 692,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[\n연립방정식 의 해가 무수히 많도록 하\n2x+y=2\nx-2y=a\n연립방정식 [ 의 해가 x+y=-1 을 만족\n는 상수 a 의 값은?\n4x+3y=a-1\n시킬 때, 상수 a 의 값을 구하시오.",
    choices: [
      "-4",
      "-1",
      "2",
      "4",
      "5"
    ],
    answer: "∴ 4a-2b=2(2a-b)=2_5=10 10",
    solution: ""
  },
  {
    id: 693,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 연립방정식 중 해가 없는 것을 모두 고르면?\n7x-5y=9 bx+9y=5\n(정답 2 개)\n두 연립방정식 [ 과 [ 의 해가\n2x+ay=7 -3x+y=-5\n2x+y=6 x+y=5",
    choices: [
      "[",
      "[\n서로 같을 때, 상수 a , b 에 대하여 a-b 의 값은?\n4x+2y=2 x-y=3",
      "-5",
      "-3",
      "-1\n2x+y=2 3y=2x-8\n[ ["
    ],
    answer: "⑤",
    solution: ""
  },
  {
    id: 694,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "a b\nax+by=3\n(\nx-  y=2\n[\n연립방정식 를 푸는데 예은이는 바르게 풀어\n3  2\ncx-2y=9\n연립방정식 { 의 해가 x=1 , y=-1 일\na\nx+ ;1õ0; y=0.1\n서 x=3 , y=-3 을 얻었고, 지훈이는 c 를 잘못 보고 풀어\n¥ 9\n10\n서 x=-2 , y=3 을 얻었다. 이때 상수 a , b , c 에 대하여\n때, 상수 a , b 에 대하여 2a+b 의 값은?\na-b+c 의 값은?",
    choices: [
      "2",
      "4",
      "6",
      "1",
      "2"
    ],
    answer: "∴ y-x=3-(-4)=7 7",
    solution: ""
  },
  {
    id: 695,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(a-1)x+2y=4",
    choices: [],
    answer: "3",
    solution: ""
  },
  {
    id: 696,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0696",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 697,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0697",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 698,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ax+6y=2\n2x+y=21\n연립방정식 [ 의 해가 무수히 많을 때, 일차방\n연립방정식 [ 을 만족시키는 x 와 y 의 값의\nx-2y=b\n-4x+ay=3\n정식 ax+by=-12 의 자연수인 해를 구하시오.\n비가 2` : `3 일 때, 상수 a 의 값을 구하시오.\n(단, a , b 는 상수이다.)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 699,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0699",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 700,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 가 자연수일 때, 일차방정식 x+2y=14 의 모든 해를 2x+5y=3\n연립방정식 [ 을 만족시키는 x , y 의 값이\nx , y 의 순서쌍으로 나타내면 (x Á , y Á ) , (xª , yª) , y , ax+by=-21\n(x Ç , y Ç ) 이다. a=x Á +xª+ y +x Ç ,\nx+3y=1\n[\n연립방정식 를 만족시키는 x , y 의 값의 각각\nb=y Á +yª+ y +y Ç 이라 할 때, a-b+n 의 값을 구하시\nbx+ay=2\n오.\n3 배이다. 이때 상수 a , b 에 대하여 ab 의 값을 구하시오.\neunji010220@naver.c",
    choices: [],
    answer: "27",
    solution: ""
  },
  {
    id: 701,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0701",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 702,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "0.4x-0.3y=2.1\nx+y 3x-y\n[\n연립방정식 의 해가 x=a , y=b 일 때,\n2 3\n0. H 3x-0. H 1y=1. H 3 자연수 x , y 에 대하여 = ;8!; , =3 일 때, x+y 의\nx\ny+1\n3\n4\na-b\n의 값을 구하시오.\n값을 구하시오.\n연립일차방정식\n06\n103",
    choices: [],
    answer: "2 점 슛: 8 개, 3 점 슛: 4 개",
    solution: ""
  },
  {
    id: 703,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "는 데 2 시간이 걸렸다 . 다음 물음에 답하시오 .\n립방정식을 세우시오.\n집에서 서점까지의 거리를 x `km , 서점에서 학교",
    choices: [],
    answer: "∴ ab=4_1=4 4",
    solution: ""
  },
  {
    id: 704,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "까지의 거리를 y `km 라 할 때, 다음 표를 완성하시오.\n집 `~` 서점 서점 `~` 학교 전체\n거리 x` km y` km 6` km\n속력\n시속 2` km\n[0705~0706] 닭과 토끼가 모두 20 마리 있다 . 닭과 토끼의 다\n시간 2 시간\n리 수의 합이 44 일 때 , 다음 물음에 답하시오 .\n닭이 x 마리, 토끼가 y 마리 있다고 할 때, x , y 에",
    choices: [],
    answer: "∴ y=6 10 , 6",
    solution: ""
  },
  {
    id: 705,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x y\n, 에 대한 연립방정식을 세우시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 706,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "에서 학교까지의 거리를 각각 구하시오.\n있는지 구하시오.\n어떤 농구 선수가 한 경기에서 2 점 슛과 3 점 슛\n[0707~0708]\n을 합하여 12 개 성공하여 28 점을 얻었다 . 다음 물음에 답하시 농도에 대한 문제\n07 - 3\n오 .\n3`% 의 소금물과 8`% 의 소금물을 섞어서 6`%\n[0714~0716]\n성공한 2 점 슛의 개수를 x , 3 점 슛의 개수를 y 라",
    choices: [],
    answer: "양변에 -3 을 곱하면 9x+2y=36 닭 : 18 마리, 토끼 : 2 마리",
    solution: ""
  },
  {
    id: 707,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 소금물 100` g 을 만들었다 . 다음 물음에 답하시오 .\n할 때, x , y 에 대한 연립방정식을 세우시오.\n3`% 의 소금물의 양을 x `g , 8`% 의 소금물의 양을",
    choices: [],
    answer: "x=2 , y=9",
    solution: ""
  },
  {
    id: 708,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "각 몇 개인지 구하시오.\n섞기 전 섞은 후\n농도 ( % ) 3 8 6\n소금물의 양 ( g ) x y 100\n소금의 양 ( g )\n[0709~0710] 한 개에 200 원인 사탕과 한 개에 300 원인 초콜\n릿을 합하여 15 개를 구입하고 4200 원을 지불하였다 . 다음 물\nx , y 에 대한 연립방정식을 세우시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 709,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식을 풀어 3`% 의 소금물과 8`% 의 소금",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 710,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "몇 개인지 구하시오.\n연립일차방정식의 활용\n07\n105",
    choices: [],
    answer: "5",
    solution: ""
  },
  {
    id: 711,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식을 풀어 두 수를 각각 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 712,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "대한 연립방정식을 세우시오.\n연립방정식을 풀어 집에서 서점까지의 거리, 서점",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 713,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식을 풀어 닭과 토끼가 각각 몇 마리씩",
    choices: [],
    answer: "㉠ - ㉡을 하면 -x=-2 ∴ x=2 따라서 작은 수는 14 이다. ②",
    solution: ""
  },
  {
    id: 714,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "y `g 이라 할 때, 다음 표를 완성하시오.\n연립방정식을 풀어 성공한 2 점 슛과 3 점 슛은 각",
    choices: [],
    answer: "52",
    solution: ""
  },
  {
    id: 715,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "음에 답하시오 .\n사탕의 개수를 x , 초콜릿의 개수를 y 라 할 때, x ,",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 716,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y 에 대한 연립방정식을 세우시오.\n물의 양을 각각 구하시오.\n연립방정식을 풀어 구입한 사탕과 초콜릿은 각각",
    choices: [],
    answer: "28",
    solution: ""
  },
  {
    id: 717,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0717",
    choices: [],
    answer: "23",
    solution: ""
  },
  {
    id: 718,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두 자리 자연수가 있다. 이 수의 십의 자리의 숫자의 2 배는\n어떤 두 정수의 합은 36 이고 차는 4 이다. 두 정수 중 큰 수\n일의 자리의 숫자보다 1 만큼 크고, 십의 자리의 숫자와 일\n를 구하시오.\n의 자리의 숫자를 바꾼 수는 처음 수보다 9 만큼 크다고 한\n다. 이때 처음 수를 구하시오.",
    choices: [],
    answer: "따라서 두 정수 중 큰 수는 20 이다. 20",
    solution: ""
  },
  {
    id: 719,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두 자리 자연수가 있다. 이 수는 각 자리의 숫자의 합의 7 배\n어떤 두 수의 차는 15 이고 작은 수의 3 배에서 큰 수를 빼면\n이고 십의 자리의 숫자와 일의 자리의 숫자를 바꾼 수는 처\n13 이다. 이때 작은 수는?\neunji010220@naver.com\n음 수보다 18 만큼 작다고 한다. 이때 처음 수를 구하시오.",
    choices: [
      "10",
      "14",
      "19",
      "23",
      "29"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 720,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두 수 중 큰 수를 작은 수로 나누면 몫은 7 이고 나머지는 4 비밀번호는 세 자리 자연수이다. 십의 자리의 숫자는 백\n이다. 또 큰 수의 2 배를 작은 수로 나누면 몫은 15 이고 나 의 자리의 숫자와 일의 자리의 숫자의 합인 5 와 같고,\n백의 자리의 숫자와 일의 자리의 숫자를 바꾼 수는 처\n머지는 2 이다. 이때 두 수의 합을 구하시오.\n음 수보다 99 만큼 작다.\n. 연립일차방정식\nIV\n106",
    choices: [],
    answer: "집에서 서점까지의 거리: 2` km,",
    solution: ""
  },
  {
    id: 721,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두 수의 합은 49 이고 큰 수를 작은 수로 나누면 몫은 2 이고 두 자리 자연수가 있다. 이 수의 각 자리의 숫자의 합은 10\n나머지는 4 이다. 이때 두 수의 차를 구하시오. 이고, 십의 자리의 숫자와 일의 자리의 숫자를 바꾼 수는\n처음 수보다 54 만큼 클 때, 처음 수를 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 722,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0722",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 723,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0723",
    choices: [],
    answer: "19 10y+x=(10x+y)-18 x-y=2 yy` ㉡",
    solution: ""
  },
  {
    id: 724,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음은 어느 체육관의 한 회원의 사물함의 비밀번호에 대한\n설명이다. 회원의 사물함의 비밀번호를 구하시오.",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 725,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "현재 아버지와 아들의 나이의 차는 30 살이고, 지금부터 15",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 726,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "현재 어머니와 딸의 나이의 합은 45 살이고 나이의 차는 27",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 727,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0727",
    choices: [],
    answer: "24 살",
    solution: ""
  },
  {
    id: 728,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0728",
    choices: [],
    answer: "15 살 답 120 `cmÛ `",
    solution: ""
  },
  {
    id: 729,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "년 후에 아버지의 나이는 아들의 나이의 2 배가 된다고 한\n어느 공원의 입장료는 어른이 1800 원, 어린이가 600 원이\n다. 현재 아들의 나이는?\n다. 어른과 어린이를 합하여 모두 20 명이 입장하는데 입장",
    choices: [
      "12 살",
      "13 살",
      "14 살\n료가 18000 원이 들었다고 할 때, 입장한 어린이는 몇 명인\neunji010220@naver.c",
      "15 살",
      "16 살\n가?"
    ],
    answer: "42 1800x+600y=18000 3x+y=30 yy` ㉡",
    solution: ""
  },
  {
    id: 730,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "살이다. 현재 어머니와 딸의 나이를 각각 구하시오.\n볼펜 4 자루와 공책 2 권의 가격은 4000 원이고, 볼펜 3 자루\n와 공책 4 권의 가격은 5000 원이다. 이때 볼펜 한 자루의 가\n격을 구하시오.",
    choices: [],
    answer: "600 원",
    solution: ""
  },
  {
    id: 731,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "현재 삼촌의 나이가 동호의 나이의 3 배이고, 8 년 후에는 삼\n은수와 준희가 가지고 있는 연필은 모두 40 자루이고, 은수\n촌의 나이가 동호의 나이의 2 배가 된다고 한다. 현재 삼촌\n가 준희에게 연필 3 자루를 주었더니 준희가 가지고 있는\n의 나이를 구하시오.\n연필 수는 은수가 가지고 있는 연필 수의 3 배가 되었다고\n한다. 이때 처음 은수가 가지고 있던 연필은 몇 자루인지\n구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 732,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "주원이에게는 쌍둥이 동생 2 명이 있다. 주원이는 동생보다\n어떤 제과점에서 와플 한 개를 만들려면 우유 1 컵, 달걀 2 개\n3 살 많고, 현재 주원이와 동생들의 나이의 합은 39 살이다.\n가 필요하고, 케이크 한 개를 만들려면 우유 3 컵, 달걀 4 개\n현재 주원이의 나이를 구하시오.\n가 필요하다. 우유 13 컵, 달걀 20 개를 모두 사용하여 와플과\n케이크를 만들 때, 만들 수 있는 와플의 개수를 구하시오.\n연립일차방정식의 활용\n07\n107",
    choices: [],
    answer: "어머니: 36 살, 딸 : 9 살",
    solution: ""
  },
  {
    id: 733,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "지민이와 지수가 가위바위보를 하여 이긴 사람은 2 계단씩\n둘레의 길이가 46 `cm 인 직사각형에서 가로의 길이는 세로\n올라가고 진 사람은 1 계단씩 내려가기로 하였다. 얼마 후\n의 길이의 2 배보다 1 `cm 짧다고 한다. 이때 이 직사각형의\n지민이는 처음 위치보다 21 계단을, 지수는 3 계단을 올라가\n넓이를 구하시오.\n있었다. 이때 지민이가 이긴 횟수를 구하시오.\n(단, 비기는 경우는 없었다.)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 734,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "길이가 170 `cm 인 줄을 두 개로 나누었더니 짧은 줄의 길",
    choices: [],
    answer: "4 번",
    solution: ""
  },
  {
    id: 735,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "아랫변의 길이가 윗변의 길이보다 4 `cm 더 긴 사다리꼴이",
    choices: [],
    answer: "210",
    solution: ""
  },
  {
    id: 736,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "인지 구하시오.\n가로의 길이가 8 `cm , 세로의\n길이가 4 `cm 인 직사각형이 있\n4`cm\n다. 이 직사각형의 가로와 세로\n8`cm\n의 길이를 늘여서 오른쪽 그림\n과 같은 도형을 만들었다. 가로로 늘인 길이는 세로로 늘인",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 737,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0737",
    choices: [],
    answer: "168",
    solution: ""
  },
  {
    id: 738,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: ";3!;\n이가 긴 줄의 길이의 보다 10 `cm 만큼 길었다. 이때 짧\n20 문제가 출제된 어느 수학 시험에서 한 문제를 맞히면 5\n은 줄의 길이를 구하시오. 점을 얻고, 틀리면 2 점이 감점된다고 한다. 수미가 72 점을\n얻었다면 수미가 맞힌 문제의 개수를 구하시오.\neunji0102",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 739,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "있다. 이 사다리꼴의 높이가 4 `cm 이고 넓이가 28 `cmÛ ` 일\n1 부터 100 까지의 자연수가 각각 하나씩 적힌 100 장의 카\n때, 아랫변의 길이를 구하시오.\n드가 들어 있는 상자에서 은영이와 세호 두 사람이 각각 한\n장씩 카드를 꺼내 적힌 수를 비교하여 큰 수가 나오는 사람\n은 5 점, 작은 수가 나오는 사람은 3 점을 얻는다고 한다. 얼\n마 후 은영이의 점수의 합은 38 점, 세호의 점수의 합은 42\n점이었을 때, 은영이가 세호보다 큰 수를 뽑은 것은 몇 번",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 740,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "길이보다 2 `cm 더 길고, 새로 만든 도형의 넓이는 원래 직\n공장에서 어떤 제품을 생산하는데 합격품은 50 원의 이익을\n사각형의 넓이의 2 배일 때, 가로의 길이는 몇 cm 늘였는가?\n얻고, 불량품은 100 원의 손해가 생긴다고 한다. 이 제품을\n250 개 생산하여 6500 원의 이익을 얻었을 때, 합격품의 개",
    choices: [
      "2 `cm",
      "2.5 `cm",
      "3 `cm\n수를 구하시오.",
      "3.5 `cm",
      "4 `cm\n. 연립일차방정식\nIV\n108"
    ],
    answer: "따라서 짧은 줄의 길이는 50 `cm 이다. 50 `cm",
    solution: ""
  },
  {
    id: 741,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "를 구하시오.\n어느 중학교의 올해 학생 수는 작년에 비하여 남학생은\n4`% 감소하고, 여학생은 5`% 증가하여 전체적으로 2 명이\n감소한 408 명이었다. 올해의 여학생 수를 구하시오.",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 742,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "각각 30`% 의 이익을 붙여 정가를 정하였다. 두 종류의 과\n어느 인터넷 카페의 지난달 회원은",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 743,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어느 가게에서 원가가 400 원인 수제 사탕과 원가가 600 원\n지난달 부모님의 휴대 전화 요금의 합은 50000 원이었다.\n인 수제 초콜릿을 합하여 500 개를 구입하고, 수제 사탕은\n이번 달 휴대 전화 요금은 지난달에 비하여 어머니는 10`%\n20`% , 수제 초콜릿은 25`% 의 이익을 각각 붙여 정가를 정\n감소하고, 아버지는 15`% 증가하여 부모님의 휴대 전화\n하였다. 두 제품을 모두 판매하면 54000 원의 이익이 생긴\n요금의 합은 5`% 증가하였다. 이번 달 아버지의 휴대 전화\n다고 할 때, 수제 사탕은 모두 몇 개인지 구하시오.\n요금을 구하시오.\n연립일차방정식의 활용\n07\n109",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 744,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "감소한 후의 양 { ;10B0; }\n1- y\nA , B 두 상품을 합하여 20000 원에 사서 A 상품은 원가의\n20`% 의 이익을 붙이고, B 상품은 원가에서 30`% 를 할인\n하여 팔면 3000 원의 이익이 생긴다고 한다. B 상품의 원가",
    choices: [],
    answer: "4 시간",
    solution: ""
  },
  {
    id: 745,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어느 제과 회사에서 새로 개발한 두 종류의 과자의 원가에",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 746,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0746",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 747,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0747",
    choices: [],
    answer: "34500 원",
    solution: ""
  },
  {
    id: 748,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "전체 회원이 45 명인 어느 산악회에서 남자 회원의 75`% 와\n어느 수조에 물이 가득 차 있다. 이 수조의 물을 A 호스로\n여자 회원의 84`% 가 이번 산행에 참가하였다. 산행에 참\n2 시간 동안 뺀 후 B 호스로 4 시간 동안 빼거나 A 호스로 eunji0102\n가한 회원이 전체 회원의 80`% 일 때, 산행에 참가한 남자\n3 시간 동안 뺀 후 B 호스로 2 시간 동안 빼면 모두 뺄 수 있\n회원 수를 구하시오.\n다. 이 수조의 물을 A 호스로만 모두 빼는 데는 몇 시간이\n걸리는지 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 749,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연우가 4 시간 동안 한 후 지수가 2 시간 동안 하면 마칠 수\n는 돈의 ;2!; 을 내서 10000 원짜리 물건을 구입하였다. 가은\n있는 일이 있다. 이 일을 연우가 혼자 1 시간 동안 하고, 연\n이와 시현이의 남은 돈을 비교했더니 시현이가",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 750,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "혜리와 어머니가 함께 6 일 동안 작업하여 마칠 수 있는 일\n3\n전체 학생이 21 명인 어느 학급에서 남학생의 과 여학생\n을 혜리가 3 일 동안 작업한 후 나머지를 어머니가 15 일 동\n4\n안 작업하여 모두 마쳤다. 이 일을 혜리가 혼자 하면 마치\n2\n의 는 축구를 좋아한다고 한다. 축구를 좋아하는 학생이\n3\n는 데 며칠이 걸리는가?\n5\n전체 학생의 일 때, 이 학급의 여학생 수를 구하시오.",
    choices: [
      "7 일",
      "8 일",
      "9 일\n7",
      "10 일",
      "11 일"
    ],
    answer: "300 개 따라서 여학생 수는 9 이다. 답 9",
    solution: ""
  },
  {
    id: 751,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0751",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 752,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "가은이는 가지고 있는 돈의 ;3!; 을 내고, 시현이는 가지고 있",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 753,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "떠난 지 몇 분 후인지 구하시오.\n철수는 집에서 도서관까지 가는데 처음에는 시속 6 `km 로\n달리다가 도중에 시속 4 `km 로 걸었다. 총 5 `km 의 거리를\n가는 데 1 시간이 걸렸다고 할 때, 달려간 거리를 구하시오.",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 754,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "가?\n2 `km\n어느 등산객이 상급자 코스를 따라 시속 로 올라가서\n30\n정상에서 분 동안 휴식 후 초급자 코스를 따라 시속",
    choices: [
      "1` km",
      "2` km",
      "3` km\n4 `km 4\n로 내려왔더니 총 시간이 걸렸다. 상급자 코스가 초",
      "4` km",
      "5` km\n1 `km\n급자 코스보다 더 길 때, 등산한 총거리를 구하시오."
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 755,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "하여 마주 보고 걷다가 10 분 만에 만났다. 창민이가\n진영이는 집에서 서점을 거쳐 학교까지 왕복하는데 갈 때는\n360 `m 를 걷는 동안에 현우는 120 `m 를 걸었다고 할 때,\n집에서 서점까지 시속 6 `km 로 달리고, 서점에서 학교까지\n창민이가 1 분 동안 걸은 거리는?\n는 시속 4 `km 로 걸어서 총 3 시간 20 분이 걸렸다. 올 때는\n(단, 창민이와 현우는 일정한 속력으로 걷는다.)\n학교에서 서점까지 시속 6 `km 로 달리고, 서점에서 집까지\n는 시속 8 `km 로 달렸더니 총 2 시간 15 분이 걸렸다. 집에",
    choices: [
      "70 `m",
      "80 `m",
      "90 `m\n서 서점을 거쳐 학교까지의 거리를 구하시오.",
      "100 `m",
      "110 `m\n연립일차방정식의 활용\n07\n111"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 756,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "+( 나중 속력으로 갈 때 걸린 시간 )=( 전체 걸린 시간 )\n동생이 학교를 향해 분속 50 `m 로 걸어간 지 15 분 후에 형\n이 분속 80 `m 로 뒤따라갔다. 두 사람이 만나는 것은 형이",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 757,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "18 `km 떨어진 두 지점에서 수빈이는 시속 4 `km 로, 태현\n이는 시속 5 `km 로 동시에 출발하여 마주 보고 걷다가 도\n중에 만났다. 이때 태현이는 수빈이보다 몇 km 더 걸었는",
    choices: [],
    answer: "14000 원",
    solution: ""
  },
  {
    id: 758,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0758",
    choices: [],
    answer: "따라서 달려간 거리는 3` km 이다. 3` km",
    solution: ""
  },
  {
    id: 759,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "는 데 20 분, 내려오는 데 10 분이 걸렸다. 이때 강물의 속력\n둘레의 길이가 2 `km 인 호수의 둘레를 나연이와 종혁이가\n은? (단, 배와 강물의 속력은 일정하다.)\n일정한 속력으로 걷고 있다. 두 사람이 같은 지점에서 동시",
    choices: [
      "분속 90 `m",
      "분속 100 `m",
      "분속 110 `m\n에 출발하여 같은 방향으로 돌면 1 시간 후에 처음으로 만",
      "분속 120 `m",
      "분속 130 `m\n나고, 반대 방향으로 돌면 20 분 후에 처음으로 만난다고 한\n다. 나연이가 종혁이보다 걷는 속력이 빠를 때, 나연이와\n종혁이의 속력은 각각 시속 몇 km 인지 구하시오."
    ],
    answer: "9` km",
    solution: ""
  },
  {
    id: 760,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "가는 데 3 시간, 내려오는 데 1 시간 30 분이 걸렸다. 이때 정\neunji0102\n둘레의 길이가 0.45 km 인 공원의 둘레를 형과 동생이 같은\n지한 물에서의 보트의 속력을 구하시오.\n지점에서 동시에 서로 반대 방향으로 출발하였다. 형은 분속\n(단, 보트와 강물의 속력은 일정하다.)\n50 `m , 동생은 분속 40 m 로 걸을 때, 두 사람이 처음 만나는\n것은 출발한 지 몇 분 후인지 구하시오.",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 761,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "A 선착장에서 B 선착장까지 유람선을 타고 강을 따라 내\n둘레의 길이가 6 `km 인 트랙을 기환이와 지유가 일정한 속\n려오는 데 45 분, 거슬러 올라가는 데 90 분이 걸렸다. 정지\n력으로 달리고 있다. 같은 지점에서 동시에 출발하여 반대\n한 물에서 유람선은 분속 100 `m 로 일정하게 움직일 때,\n방향으로 달리면 30 분 후에 처음으로 만나고, 같은 방향으\nA , B 두 선착장 사이의 거리는?\n로 달리면 2 시간 후에 기환이가 지유를 두 바퀴 앞지른다\n(단, 강물의 속력은 일정하다.)\n고 한다. 이때 기환이의 속력은?",
    choices: [
      "3` km",
      "4` km",
      "5` km\n5` km `",
      "시속 6` km",
      "시속 7` km"
    ],
    answer: "①",
    solution: ""
  },
  {
    id: 762,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "하늘이는 배를 타고 길이가 4000 `m 인 강을 거슬러 올라가",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 763,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "초연이는 보트를 타고 길이가 30 `km 인 강을 거슬러 올라",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 764,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0764",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 765,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "농도가 서로 다른 두 종류의 소금물 A , B 가 있다. 소금물\nA 를 100` g , 소금물 B 를 200` g 섞으면 4`% 의 소금물이 되\n3`% 의 소금물과 6`% 의 소금물을 섞어서 4`% 의 소금물\n고, 소금물 A 를 200` g , 소금물 B 를 100` g 섞으면 5`% 의\n300` g 을 만들려고 한다. 6`% 의 소금물을 몇 g 섞어야 하\n소금물이 된다. 이때 소금물 B 의 농도는?\n는가?",
    choices: [
      "100` g",
      "120` g",
      "150` g",
      "2`%",
      "3`%"
    ],
    answer: "5 분",
    solution: ""
  },
  {
    id: 766,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "농도가 서로 다른 두 종류의 소금물 A , B 가 있다. 소금물\n4`% 의 소금물에 소금을 더 넣었더니 16`% 의 소금물 200` g A 를 30` g , 소금물 B 를 20` g 섞으면 8`% 의 소금물이 되고,\n이 되었다. 이때 더 넣은 소금의 양을 구하시오. 소금물 A 를 20` g , 소금물 B 를 30` g 섞으면 9`% 의 소금물\n이 된다. 이때 두 소금물 A , B 의 농도 차를 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 767,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "10`% 의 소금물과 6`% 의 소금물을 섞은 다음 물 100` g 을 농도가 서로 다른 두 종류의 설탕물 A , B 가 각각 600` g 씩\n더 넣었더니 8`% 의 소금물 700` g 이 되었다. 이때 10`% 의 있다. 두 설탕물 A , B 를 각각 100` g , 500` g 을 섞으면 7`%\n소금물은 몇 g 을 섞었는가? 의 설탕물이 되고, 남아 있는 설탕물 A , B 를 섞으면 3`%\n의 설탕물이 된다. 이때 설탕물 B 의 농도는?",
    choices: [
      "300` g",
      "350` g",
      "400` g",
      "450` g",
      "500` g"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 768,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0768",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 769,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0769",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 770,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0770",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 771,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두 식품 A , B 에서 A 식품에는 단백질이 30`% , 지방이\n일정한 속력으로 달리는 기차가 1500 `m 길이의 철교를 완\n10`% 들어 있고, B 식품에는 단백질이 20`% , 지방이\n전히 지나는 데 55 초가 걸리고, 2100 `m 길이의 터널을 완\n40`% 들어 있다고 한다. 두 식품만 섭취하여 단백질 30` g ,\n전히 지나는 데 75 초가 걸린다고 한다. 이 기차의 속력은?\n지방 20` g 을 얻으려면 A 식품은 몇 g 을 섭취해야 하는가?",
    choices: [
      "초속 30 `m",
      "초속 35 `m",
      "초속 40 `m",
      "30` g",
      "50` g"
    ],
    answer: "합금 A : 400 `g , 합금 B : 300 `g",
    solution: ""
  },
  {
    id: 772,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "다음 표는 두 합금 A , B 에 들어 있는 구리와 아연의 비율\n일정한 속력으로 달리는 기차가 400 `m 길이의 다리를 완\n을 백분율로 나타낸 것이다. 이 두 종류의 합금을 합하여\n전히 지나는 데 30 초가 걸리고,",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 773,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "길이가 400 `m 인 다리를 화물 열차가 일정한 속력으로 완\n전히 지나는 데 56 초가 걸렸고, 화물 열차보다 길이가",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 774,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0774",
    choices: [],
    answer: "5`%",
    solution: ""
  },
  {
    id: 775,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0775",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 776,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "80 `m 짧은 KTX 는 이 다리를 화물 열차의 3 배의 일정한\n어느 연구소에서 니켈과 아연을 섞은 신소재 합금을 개발\n속력으로 완전히 지나는 데 16 초가 걸렸다고 한다. 이때 화\n중이다. 현재 보유한 니켈과 아연을 1` : `3 의 비율로 섞은 합\n물 열차의 길이는?\n금 A 와 니켈과 아연을 3` : `2 의 비율로 섞은 합금 B 를 녹여\n서 니켈과 아연을 2` : `3 의 비율로 섞은 신소재 합금 280` g 을",
    choices: [
      "160` m",
      "180` m",
      "200` m\n만들려고 할 때, 필요한 합금 B 의 양을 구하시오.",
      "220` m",
      "240` m\n(단, 두 합금 A , B 는 니켈과 아연만 포함한다.)\n. 연립일차방정식\nIV\n114"
    ],
    answer: "①",
    solution: ""
  },
  {
    id: 777,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y =4.0 H 7 ;1ª5Á0; = ;50; = = ;;Ác¢;; =d\n2_5Û`_b",
    choices: [],
    answer: "따라서 선우가 과녁을 맞힌 화살의 개수는 18 이다. 18",
    solution: ""
  },
  {
    id: 778,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "각 자리의 숫자의 합이 9 인 두 자리 자연수가 있다. 이 수",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 779,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "현재 아버지의 나이가 아들의 나이보다 32 살이 더 많고, 8\n년 후에는 아버지의 나이가 아들의 나이의 2 배보다 14 살이\n더 많다고 한다. 8 년 후의 아버지의 나이는?",
    choices: [],
    answer: "42+8=50` (살) ⑤",
    solution: ""
  },
  {
    id: 780,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음은 서윤이가 제과점에서 빵과 우유를 구입하고 받은\n영수증인데 일부가 찢어져 보이지 않는다. 서윤이가 구입\n한 도넛의 개수를 구하시오.",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 781,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "합이 100 인 두 자연수가 있다. 큰 수를 작은 수로 나누면 선우가 과녁에 화살을 쏘아 맞히는 게임을 하는데 과녁을\n몫은 5 이고 나머지는 10 일 때, 이 두 수 중 큰 수는? 맞히면 10 점을 얻고, 맞히지 못하면 5 점이 감점된다고 한\n다. 선우가 총 30 개의 화살을 쏘아 120 점을 얻었을 때, 선",
    choices: [
      "75",
      "80",
      "85\n우가 과녁을 맞힌 화살의 개수를 구하시오.",
      "90",
      "95\neunji010220@naver.c"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 782,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 십의 자리의 숫자와 일의 자리의 숫자를 바꾼 수는 처음\n어느 극장의 어제 전체 관객은",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 783,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0783\n① 40 살 ② 42 살 ③ 45 살\n어느 음반 제작 회사에서 새로 제작한 두 음악 CD 를 원가\n④ 47 살 ⑤ 50 살\n에 12`% 의 이익을 붙여 정가를 정하였더니 두 음악 CD 의\n정가의 합이 25760 원이었다. 두 음악 CD 의 원가의 차가\n3000 원일 때, 더 비싼 음악 CD 의 원가를 구하시오.",
    choices: [
      "40 살",
      "42 살",
      "45 살\n어느 음반 제작 회사에서 새로 제작한 두 음악 CD 를 원가",
      "47 살",
      "50 살\n에 12`% 의 이익을 붙여 정가를 정하였더니 두 음악 CD 의\n정가의 합이 25760 원이었다. 두 음악 CD 의 원가의 차가\n3000 원일 때, 더 비싼 음악 CD 의 원가를 구하시오."
    ],
    answer: "",
    solution: ""
  },
  {
    id: 784,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "영 수 증\n어느 수조에 물을 채우는데 A 호스로 9 시간 동안 넣고, B\n주문번호: 02-210701 20◯◯.◯◯.◯◯ 16:27\n품목 단가(원) 수량(개) 금액(원)\n호스로 2 시간 동안 넣었더니 수조가 가득 찼다. 또 같은 수\n단팥빵 1,200 2 2,400\n조에 A 호스로 3 시간 동안 넣고, B 호스로 6 시간 동안 넣\n도넛 1,500\n었더니 수조가 가득 찰 때, A 호스로만 수조를 가득 채우\n식빵 2,600\n는 데는 몇 시간이 걸리는지 구하시오.\n우유 1,000 3\n합계 11 16,600\n연립일차방정식의 활용\n07\n115",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 785,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0785",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 786,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "정원이가 출발한 지 10 분 후에 민아가 자전거를 타고 같은\n방향으로 출발하였다. 정원이는 분속 400 `m 로 달리고 민\n아는 분속 600 `m 로 자전거를 타고 따라갈 때, 두 사람이\n만나게 되는 것은 민아가 출발한 지 몇 분 후인가?",
    choices: [
      "10 분",
      "15 분",
      "20 분"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 787,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "속력이 일정한 배를 타고 길이가 28 `km 인 강을 거슬러 올\n라가는 데 1 시간 10 분, 내려오는 데 40 분이 걸렸다. 정지\n한 물에서의 배의 속력은? (단, 강물의 속력은 일정하다.)",
    choices: [
      "시속 29` km",
      "시속 30` km",
      "시속 31` km",
      "시속 32` km",
      "시속 33` km"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 788,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "몇 kg 이 필요한지 구하시오.\n8`% 의 소금물 200` g 이 있다. 여기에 15`% 의 소금물을 넣\n어서 농도가 13`% 가 되게 하려고 할 때, 넣어야 할 15`%\n의 소금물의 양을 구하시오.\n. 연립일차방정식\nIV\n116",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 789,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3 `km\n등산을 하는데 올라갈 때는 시속 로 걷고, 내려올 때 농도가 서로 다른 두 소금물 A , B 가 있다. 소금물 A 를\n4 `km 4 `km\n는 올라갈 때보다 더 먼 길을 시속 로 걸어서 100` g , 소금물 B 를 200` g 섞으면 6`% 의 소금물이 되고,\n4 30\n총 시간 분이 걸렸다. 이때 내려온 거리를 구하시오. 소금물 A 를 200` g , 소금물 B 를 100` g 섞으면 8`% 의 소금\n물이 된다. 이때 소금물 A 의 농도는?",
    choices: [
      "4`%",
      "8`%",
      "10`%",
      "12`%",
      "15`%"
    ],
    answer: "따라서 내려온 거리는 10` km 이다. 10` km",
    solution: ""
  },
  {
    id: 790,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "④ 25 분 ⑤ 30 분\n길이가 200 `m 인 기차 A 는 어느 다리를 완전히 지나는 데\n30 초가 걸리고, 길이가 150 `m 인 기차 B 는 이 다리를 기차\nA 의 2 배의 속력으로 완전히 지나는 데 14 초가 걸린다고\n한다. 이때 다리의 길이를 구하시오.\n(단, 기차 A , B 의 속력은 일정하다.)\neunji0102",
    choices: [],
    answer: "다. ③",
    solution: ""
  },
  {
    id: 791,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "A 는 구리를 10`% , 주석을 30`% 포함한 합금이고, B 는\n구리를 20`% , 주석을 10`% 포함한 합금이다. 이 두 종류\n의 합금을 녹인 후 다시 섞어서 구리와 주석을 각각 5` kg ,\n4` kg 씩 포함하는 합금으로 만들려고 한다. 이때 합금 A 는",
    choices: [],
    answer: "따라서 정지한 물에서의 배의 속력은 시속 33` km 이다. ⑤",
    solution: ""
  },
  {
    id: 792,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0792",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 793,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 그림과 같이 모양과 크기가 같은 직사각형 모양의 타일\n10 장을 겹치지 않게 빈틈없이 이어 붙여 큰 직사각형을 만들",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 794,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "재형이가 집에서 출발하여 할머니 댁까지 자동차를 타고\n둘레의 길이가 4 `km 인 공원의 둘레를 A , B 두 사람이 자\n갔다. 시속 90 `km 로 가면 예정 소요 시간보다 30 분이 덜\n전거를 타고 일정한 속력으로 달리고 있다. 두 사람이 같은\n걸리고, 시속 75 `km 로 가면 예정 소요 시간보다 6 분이 더\n지점에서 동시에 출발하여 같은 방향으로 돌면 1 시간 후에\n걸린다. 집에서 할머니 댁까지의 거리와 예정 소요 시간을\n처음으로 만나고, 반대 방향으로 돌면 10 분 후에 처음으로\n차례대로 구하시오.\n만난다고 할 때, A 의 속력을 구하시오.\n(단, A 의 속력이 B 의 속력보다 더 빠르다.)\n연립일차방정식의 활용\n07\n117",
    choices: [],
    answer: "300+100=400 400",
    solution: ""
  },
  {
    id: 795,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "시하의 휴대 전화의 비밀번호는 네 자리 숫자로 되어 있고,\n어떤 음악회에서 연주 시간이 5 분인 곡 x 곡과 연주 시간이\n각 자리의 숫자는 0 또는 한 자리 자연수이다. 다음 조건을\n8 분인 곡 y 곡을 연주하여 공연 시간을 1 시간 56 분으로 계\n만족시키는 비밀번호를 구하시오.\n획했으나 실제로는 연주 시간이 5 분인 곡 y 곡과 연주 시간\n이 8 분인 곡 x 곡을 연주하여 1 시간 47 분이 걸렸다. 곡과\n㈎",
    choices: [],
    answer: "연 시간을 식으로 나타낸다 . 270` km, 3 시간 30 분",
    solution: ""
  },
  {
    id: 796,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "었더니 그 둘레의 길이가 62 `cm 이었다. 이때 큰 직사각형의\n어느 자격 시험에 응시한 남학생과 여학생 수의 비는 3` : `1 ,\n세로의 길이를 구하시오.\n합격자의 남학생과 여학생 수의 비는 5` : `2 , 불합격자의 남\n학생과 여학생 수의 비는 10` : `3 이다. 합격자가 140 명일\neunji0102\n때, 자격 시험에 응시한 전체 학생 수를 구하시오.",
    choices: [],
    answer: "10 `cm",
    solution: ""
  },
  {
    id: 797,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0797",
    choices: [],
    answer: ";9Ó0; ;6#0);",
    solution: ""
  },
  {
    id: 798,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ㄷ. y=3 ㄹ. xy=10\nx 1 2 3 4 5 y\nㅁ. y= ;2!; (x-3) ㅂ. x+4y\ny y\neunji010220@naver.c\ny 가 x 에 대한 함수인지 말하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 799,
    level: "",
    category: "연립일차방정식",
    originalCategory: "연립일차방정식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-03",
    standardUnit: "연립일차방정식",
    standardUnitOrder: 3,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 문장에서 y 를 x 에 대한 식으로 나타내고 ,\n[0811~0813]\ny 가 x 에 대한 일차함수인지 말하시오 .\n한 변의 길이가 x `cm 인 정사각형의 넓이는",
    choices: [],
    answer: "x 절편: 3 , y 절편: -2",
    solution: ""
  }
];
