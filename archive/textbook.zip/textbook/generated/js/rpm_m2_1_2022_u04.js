window.examTitle = "22개정 RPM 중학수학 2-1 | 4단원 일차부등식";

window.questionBank = [
  {
    id: 421,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-5 -4 -3 -2 -1\n6 4\nx-5\n-x+4<x+2 ;5{; -1>",
    choices: [],
    answer: "풀이 참조",
    solution: ""
  },
  {
    id: 422,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3\n\u000e\u0013 \u000e\u0012 \u0011 \u0012 \u0013\n일차부등식\n04\n61",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 423,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 문장을 부등식으로 나타낸 것으로 옳지 않은 것은?\n다음 중 부등식이 아닌 것을 모두 고르면? (정답 2 개)",
    choices: [
      "x 에서 5 를 뺀 수는 15 보다 작다. x-5<15",
      "x-5=2",
      "5-1>0",
      "x+4<2x",
      "x 의 2 배는 x 에 7 을 더한 수보다 작지 않다."
    ],
    answer: "",
    solution: ""
  },
  {
    id: 424,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6x>20\n다음 보기 중 부등식인 것은 모두 몇 개인가?\n보기\nㄱ. x-1 É 3 ㄴ. 6x+2\nㄷ. 3-9>-5 ㄹ. 3_2-1=7",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 425,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형",
      "표"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0425\n① x 의 4 배에서 9 를 뺀 수는 10 보다 크다. 4x-9>10\n다음 표에서 부등식이 있는 칸을 모두 색칠할 때, 나타나는\n② 현재 x 살인 형우의 7 년 후의 나이는 30 살 미만이다.\n알파벳을 구하시오.\nx+7 É 30\n③ 한 변의 길이가 x `cm 인 정삼각형의 둘레의 길이는\n-5<9 3x-1=8 x-2y\n25 `cm 이상이다. 3x>25\nx+5>-1 -4x+1 8+7=15\n④ 전교생 300 명 중에서 여학생이 x 명일 때, 남학생은 150\n4x ¾ 10-x 10-8<5 2x É 8\n명보다 적다. 300-x<150\n⑤ 한 개에 500 원인 귤 x 개의 가격은 10000 원을 넘지 않\n는다. 500x<10000\n. 일차부등식\nIII\n62",
    choices: [
      "x 의 4 배에서 9 를 뺀 수는 10 보다 크다. 4x-9>10\n다음 표에서 부등식이 있는 칸을 모두 색칠할 때, 나타나는",
      "현재 x 살인 형우의 7 년 후의 나이는 30 살 미만이다.\n알파벳을 구하시오.\nx+7 É 30",
      "한 변의 길이가 x `cm 인 정삼각형의 둘레의 길이는\n-5<9 3x-1=8 x-2y\n25 `cm 이상이다. 3x>25\nx+5>-1 -4x+1 8+7=15",
      "전교생 300 명 중에서 여학생이 x 명일 때, 남학생은 150\n4x ¾ 10-x 10-8<5 2x É 8\n명보다 적다. 300-x<150",
      "한 개에 500 원인 귤 x 개의 가격은 10000 원을 넘지 않\n는다. 500x<10000\n. 일차부등식\nIII\n62"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 426,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0426",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 427,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ㅁ. 3(x-2)<0 ㅂ. 5x=10\n다음 문장을 부등식으로 나타내시오.",
    choices: [
      "1 개",
      "2 개",
      "3 개\n어떤 수 a 에 3 을 더한 수는 b 의 5 배보다 크지 않다.",
      "4 개",
      "5 개"
    ],
    answer: "a+3 É 5b -5a<-5b 의 양변에서 8 을 빼면",
    solution: ""
  },
  {
    id: 428,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 문장을 부등식으로 나타낸 것으로 옳은 것을 모두 고\n르면? (정답 2 개)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 429,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 [ ] 안의 수가 주어진 부등식의 해가 아닌 것은?",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 430,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0430",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 431,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 부등식 중 x=3 을 해로 갖는 것은?",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 432,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0432",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 433,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0433\n① x+2>3 [ 2 ] ② 2x-1 É 10 [ 5 ]\na>b 일 때 , 다음 중 옳지 않은 것은?\n③ 3x>x+2 [ -1 ] ④ -2x É x+6 [ -2 ] eunji010220@naver.c\n① a+7>b+7 ② -3a<-3b\n⑤ 5x+8<2x+1 [ -3 ]\n③ ;2 A ;- 4> ;2 B ; -4 ④ 10-a>10-b\n⑤ -5a-8<-5b-8",
    choices: [
      "x+2>3 [ 2 ]",
      "2x-1 É 10 [ 5 ]\na>b 일 때 , 다음 중 옳지 않은 것은?",
      "3x>x+2 [ -1 ]",
      "-2x É x+6 [ -2 ] eunji010220@naver.c",
      "a+7>b+7"
    ],
    answer: "따라서 옳지 않은 것은 ⑤ 이다. ⑤",
    solution: ""
  },
  {
    id: 434,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 부등식 4-x<2 의 해를 모두 고르면? (정답 2 개)\na<b 일 때 , 다음 중  안에 들어갈 부등호의 방향이 나머",
    choices: [
      "0",
      "1",
      "2\n지 넷과 다른 하나는?",
      "3",
      "4"
    ],
    answer: "따라서 옳은 것은 ① , ④ 이다. ① , ④",
    solution: ""
  },
  {
    id: 435,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0435\n① x+5>10 ② 2x-7>0\n,\n-5a-6<-5b-6 일 때 다음 중 옳은 것은?\n③ 2(x+1) É 7 ④ 7-3x<-x\n① a<b ② -8a>-8b\n⑤ 13-x ¾ x+7\n③ ;6A; < ;6B; ④ 1- ;2A; >1- ;2B;\n⑤ 4a-3>4b-3",
    choices: [
      "x+5>10",
      "2x-7>0\n,\n-5a-6<-5b-6 일 때 다음 중 옳은 것은?",
      "2(x+1) É 7",
      "7-3x<-x",
      "a<b"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 436,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x 의 값이 -2 , -1 , 0 , 1 일 때, 다음 부등식 중 해가 없는\n다음 중 옳지 않은 것은?\n것은?",
    choices: [
      "a<b 이면 7a<7b 이다.\n2x>x-1 2-x>x+3",
      "a-1>b-1 이면 -3a<-3b 이다.\n5x+6 É -4 3(x+2)<5",
      "5a ¾ 5b 이면 - ;2A; É - ;2B; 이다.",
      ";2{; +1<x",
      "a+2<b+2 이면 -6a-1>-6b-1 이다."
    ],
    answer: "⑤",
    solution: ""
  },
  {
    id: 437,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0437 ① 2x+1=3 ② 6(1-x) ¾ -2+3x\n③ xÛ`+x-1>0 ④ 3-x<5-x\n2<x<5 이고 A=-2x+5 일 때, A 의 값의 범위는?\n⑤ xÛ`-6 É xÛ`-x\n① -5<A<1 ② -5 É A<1 ③ -5<A É 1\n④ -1<A<5 ⑤ -1 É A<5",
    choices: [
      "2x+1=3",
      "6(1-x) ¾ -2+3x",
      "xÛ`+x-1>0",
      "3-x<5-x\n2<x<5 이고 A=-2x+5 일 때, A 의 값의 범위는?",
      "xÛ`-6 É xÛ`-x"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 438,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-1 É x<3 일 때, 다음 중 4x-3 의 값이 될 수 있는 것을",
    choices: [
      "1- ;2{; <0\n모두 고르면? (정답 2 개)",
      "-9",
      "-3",
      "3",
      "9"
    ],
    answer: "따라서 일차부등식이 아닌 것은 ⑤ 이다. ⑤",
    solution: ""
  },
  {
    id: 439,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0439\n③ 한 봉지에 70` g 인 과자 x 봉지의 무게는 500` g 보다 가\nx\n볍다.\n-3<4-  É 2 일 때, x 의 값의 범위를 구하시오.\n2\n④ 밑변의 길이가 6 `cm , 높이가 x `cm 인 삼각형의 넓이는\n20 `cm Û` 미만이다.\n⑤ 10` km 의 거리를 시속 x` km 로 걸으면 2 시간 이상이\n걸린다.",
    choices: [
      "한 봉지에 70` g 인 과자 x 봉지의 무게는 500` g 보다 가\nx\n볍다.\n-3<4-  É 2 일 때, x 의 값의 범위를 구하시오.\n2",
      "밑변의 길이가 6 `cm , 높이가 x `cm 인 삼각형의 넓이는\n20 `cm Û` 미만이다.",
      "10` km 의 거리를 시속 x` km 로 걸으면 2 시간 이상이\n걸린다."
    ],
    answer: "",
    solution: ""
  },
  {
    id: 440,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x\n-9<x É 12 이고 A=-  +2 일 때, A 의 값이 될 수 있",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 441,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "방향이 바뀜에 주의한다 .\n다음 중 일차부등식인 것을 모두 고르면? (정답 2 개)",
    choices: [],
    answer: "∴ x ¾ -5 ②",
    solution: ""
  },
  {
    id: 442,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 일차부등식이 아닌 것은?",
    choices: [
      "5-3x ¾ x+9",
      "6x É 3x+1",
      "x-2xÛ`>7-2xÛ`",
      "2x+3+4x>2(3x+1)"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 443,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 문장을 부등식으로 나타낼 때, 일차부등식이 아닌\n것은?\n① x 에 5 를 더한 수의 2 배는 35 보다 작거나 같다.\n② x 와 80 의 평균은 90 보다 크다.",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 444,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3\n부등식 2x-10 ¾ ax+3+4x 가 x 에 대한 일차부등식일\n는 수 중 가장 큰 정수를 m , 가장 작은 정수를 n 이라 하자.\n때, 다음 중 상수 a 의 값이 될 수 없는 것은?\n이때 m+n 의 값을 구하시오.",
    choices: [
      "-2",
      "-1",
      "0",
      "1",
      "2\n. 일차부등식\nIII\n64"
    ],
    answer: "②",
    solution: ""
  },
  {
    id: 445,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 일차부등식 -2x+5<2x-3 의 해를 수직선 위\n에 바르게 나타낸 것은?\n① ②",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 446,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 일차부등식 중 해가 나머지 넷과 다른 하나는?",
    choices: [
      "5x+7>-23",
      "x-6<2x",
      "10-x<x-2",
      "7x+9>4x-9",
      "-2x-11<3x+19"
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 447,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 일차부등식 중 해를 수직선\n위에 나타내었을 때, 오른쪽 그림 \u0015\n과 같지 않은 것은?",
    choices: [],
    answer: "2",
    solution: ""
  },
  {
    id: 448,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "등호의 방향이 바뀐다 .\n⑵ 부등식의 해와 수직선 일차부등식 5(x+9) ¾- 3(x-5)-10 을 풀면?\nx ¾ a , x É a a 에 대응하는 수직선 위의 점을 ●로 표시",
    choices: [
      "x É -5",
      "x ¾ -5",
      "x É -1\nx>a , x<a a 에 대응하는 수직선 위의 점을 ○로 표시",
      "x ¾ -1",
      "x ¾ 1"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 449,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-2\n-2\n다음 중 일차부등식 3(x+1)-2(x-1)<6 의 해를 수직",
    choices: [
      "선 위에 바르게 나타낸 것은?\n2 2",
      "1 1\n2",
      "6 6\neunji0102",
      "11"
    ],
    answer: "따라서 일차부등식인 것은 ② , ⑤ 이다. ② , ⑤",
    solution: ""
  },
  {
    id: 450,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 2(x+3)-3x<x+1 을 만족시키는 가장 작\n은 정수 x 의 값을 구하시오.",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 451,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0451\n① 2x-6 É x-2 ② 4x+3 É x+15\n일차부등식 1-(3-x) ¾ 2x-9 를 만족시키는 자연수 x\n③ 5x+1 ¾ 6x-3 ④ 2x+6 ¾ 4x-4\n의 개수를 구하시오.\n⑤ 8-x ¾ 3x-8\n일차부등식\n04\n65",
    choices: [
      "2x-6 É x-2",
      "4x+3 É x+15\n일차부등식 1-(3-x) ¾ 2x-9 를 만족시키는 자연수 x",
      "5x+1 ¾ 6x-3",
      "2x+6 ¾ 4x-4\n의 개수를 구하시오.",
      "8-x ¾ 3x-8\n일차부등식\n04\n65"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 452,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x-2\n일차부등식 -0.3x É - ;2!; 을 만족시키는 자연수 x\n3",
    choices: [],
    answer: "x ¾ ;a%;",
    solution: ""
  },
  {
    id: 453,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 0.14x-0.5>0.03(x-2) 를 풀면?",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 454,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-1 5x-3\n일차부등식 -  >1 을 만족시키는 가장 큰\n3 4",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 455,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 0.7x-5<1.5x+0.6 의 해를 x>a 라 하고,",
    choices: [],
    answer: "=4 , a-4=16 ∴ a=20 20",
    solution: ""
  },
  {
    id: 456,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 개수는?\na<0 일 때, x 에 대한 일차부등식 2-ax<5 를 풀면?",
    choices: [
      "1",
      "2",
      "3",
      "x<- ;a#;",
      "x>- ;a#;"
    ],
    answer: "①",
    solution: ""
  },
  {
    id: 457,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0457\n① x<-4 ② x>-4 ③ x<4\na>0 일 때, x 에 대한 일차부등식 -ax>6a 를 풀면?\n④ x>4 ⑤ x>8\n① x<-6 ② x>-6 ③ x<- ;6!;\neunji0102\n④ x> ;6!; ⑤ x>6",
    choices: [
      "x<-4",
      "x>-4",
      "x<4\na>0 일 때, x 에 대한 일차부등식 -ax>6a 를 풀면?",
      "x>4",
      "x>8"
    ],
    answer: "x<-6 ①",
    solution: ""
  },
  {
    id: 458,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "정수 x 의 값을 구하시오.\na<0 일 때, x 에 대한 일차부등식 4(ax-2) É ax+7 을\n푸시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 459,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "1 3 1\n일차부등식 x-1<  x+  의 해를 x<b 라 할 때, 상\n2  7  2\na>3 일 때, x 에 대한 일차부등식 3x+2a ¾ 6+ax 를 만\n수 a , b 에 대하여 b-a 의 값을 구하시오.\n족시키는 모든 자연수 x 의 값의 합을 구하시오.\n. 일차부등식\nIII\n66",
    choices: [],
    answer: "다. ⑤",
    solution: ""
  },
  {
    id: 460,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3\n두 일차부등식 x-4 ¾ -1 , 4(5-x) É a+1 의 해가 서\n4\n일차부등식 5x-1>8x+a 의 해가 x<-3 일 때, 상수 a\n로 같을 때, 상수 a 의 값은?\n의 값을 구하시오.",
    choices: [
      "-5",
      "-3",
      "3",
      "5",
      "7"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 461,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 x+11<3(x+a) 의 해가 x>7 일 때, 상수 a",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 462,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0462",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 463,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0463",
    choices: [],
    answer: "2",
    solution: ""
  },
  {
    id: 464,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0464",
    choices: [],
    answer: "3x ¾ 12 ∴ x ¾ 4 a-2=-4 ∴ a=-2 \b ⑤",
    solution: ""
  },
  {
    id: 465,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 값은?\n다음 두 일차부등식의 해가 서로 같을 때, 상수 a 의 값을\n구하시오.",
    choices: [
      "-5",
      "-3",
      "-1",
      "2",
      "3\n5x+2<2x-1 , 3x<a-x"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 466,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 2x+5 ¾ -2x+a+1 의 해 중 가장 작은 수가\n두 일차부등식 2(x+8)-4x ¾ -x+6 ,\n4 일 때, 상수 a 의 값을 구하시오.\neunji010220@naver.com\n0.2x+1 ¾ x+k 의 해가 서로 같을 때, 상수 k 의 값을 구\n하시오.",
    choices: [],
    answer: "∴ 4 É a<6 \b ④",
    solution: ""
  },
  {
    id: 467,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "2x+a x\n일차부등식 2-  >  -1 의\n3 6\n두 일차부등식 0.12x+0.1>0.05(x-5) ,\n\u000e\u0013\n해를 수직선 위에 나타내면 오른쪽\nx-a 2x-1 1\n<  +  의 해가 서로 같을 때, 상수 a 의 값을\n2 3 6\n그림과 같다. 이때 상수 a 의 값을 구하시오.\n구하시오.\n일차부등식\n04\n67",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 468,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 ax+5<5x-4 의 해가 x>3 일 때, 상수 a 의",
    choices: [],
    answer: "14",
    solution: ""
  },
  {
    id: 469,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 ax+2<2(x-1) 의 해가",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 470,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x-5 2x+a\n일차부등식 -  >0 을 만족시키는 자연수 x\n2 3\n2 a 2\n일차부등식 x-2>  x-  의 해가 x<-10 일 때, 상\n3  5  3\n가 존재하지 않을 때, 상수 a 의 값 중 가장 작은 수를 구하\n수 a 의 값을 구하시오.\n시오.\n. 일차부등식\nIII\n68",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 471,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "값은?\n일차부등식 a-5x ¾ -3x 를 만족시키는 자연수 x 가 2 개",
    choices: [
      "-5",
      "-2",
      "-1\n일 때, 상수 a 의 값의 범위는?",
      "2",
      "5"
    ],
    answer: "-4",
    solution: ""
  },
  {
    id: 472,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "오른쪽 그림과 같을 때, 상수 a 의 값은? 1\n일차부등식 6x+a<5x+2 를 만족시키는 자연수 x 가 3 개",
    choices: [
      "-10",
      "-8",
      "-6\n일 때, 상수 a 의 값의 범위를 구하시오.",
      "-4",
      "-2\neunji010220@naver.com"
    ],
    answer: "\b -2 É a<-1",
    solution: ""
  },
  {
    id: 473,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0473",
    choices: [],
    answer: "-1<x É 2 ③",
    solution: ""
  },
  {
    id: 474,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0474",
    choices: [],
    answer: "따라서 옳지 않은 것은 ⑤ 이다. ⑤ x<3 의 양변에 4 를 곱하면 4x<12",
    solution: ""
  },
  {
    id: 475,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 [ ] 안의 수가 주어진 부등식의 해가 아닌 것은?",
    choices: [
      "x+3>-1 [ -3 ]",
      "-4x-1 É 7 [ -2 ]",
      "3x-2<6 [ 2 ]",
      "5x ¾ 3x+7 [ 3 ]\n;3@;",
      "x-1<5 [ 6 ]"
    ],
    answer: "4",
    solution: ""
  },
  {
    id: 476,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중  안에 들어갈 부등호의 방향이 나머지 넷과 다른\n하나는?",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 477,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 문장을 부등식으로 나타낸 것으로 옳지 않은 것은? y=-5x+2 일 때, -8 É y<7 을 만족시키는 x 의 값의 범\n위는?",
    choices: [
      "x 에 7 을 더한 수는 x 의 3 배보다 크다. x+7>3x",
      "가로의 길이가 x `cm , 세로의 길이가 4 `cm 인 직사각형",
      "-2<x É 1",
      "-2 É x<1\n의 넓이는 20 `cm Û ` 보다 작지 않다. 4x ¾ 20",
      "-1<x É 2"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 478,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2\n부등식 ax-3x+1<x-7 이 x 에 대한 일차부등식일 때,\n다음 중 상수 a 의 값이 될 수 없는 것은?",
    choices: [
      "-4",
      "-2",
      "2",
      "3",
      "4"
    ],
    answer: "-8",
    solution: ""
  },
  {
    id: 479,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 2(x+4)-3(x+1)>2 를 만족시키는 x 에\n대하여 A=4x-7 일 때, 자연수 A 의 개수를 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 480,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0480\n① a-2<b-2 이면 a b 이다.\n다음 일차부등식 중 해가 나머지 넷과 다른 하나는?\n② - ;7A; >- ;7B; 이면 a b 이다.\n① 2-x<5 ② 2x-5<5x+4\n③ 1-a<1-b 이면 a b 이다.\n③ 3(2x+1)>4x-3 ④ 0.2x-0.8<0.6x+0.4\n2x-1 1\n④ ;3A; -1< ;3B; -1 이면 a b 이다.\n⑤ >  x\n5 3\n⑤ -2a+3>-2b+3 이면 a b 이다.\n일차부등식\n04\n69",
    choices: [
      "a-2<b-2 이면 a b 이다.\n다음 일차부등식 중 해가 나머지 넷과 다른 하나는?",
      "- ;7A; >- ;7B; 이면 a b 이다.",
      "2-x<5",
      "2x-5<5x+4",
      "1-a<1-b 이면 a b 이다."
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 481,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0481",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 482,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "a>5 일 때, x 에 대한 일차부등식 5x+6a<ax+30 을 풀\n면?",
    choices: [
      "x<-6",
      "x>-6",
      "x<5",
      "x<6",
      "x>6"
    ],
    answer: "x>6 ⑤ 는 합은",
    solution: ""
  },
  {
    id: 483,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 x+3 ¾ 5x-a 의 해 중 가장 큰 수가 -1 일\n④ ;2%; É a<5 ⑤ ;2%; É a É 5\n때, 상수 a 의 값을 구하시오.\n. 일차부등식\nIII\n70",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 484,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "2x+1 1 일차부등식 4x-2(x-5) É a 의 해를 수직선 위에 나타내\n다음 중 일차부등식 0.25(3x-2)-  >  의 해를\n3 6\n면 다음 그림과 같다. 이때 상수 a 의 값은?\n수직선 위에 바르게 나타낸 것은?",
    choices: [
      "-3\n-12 12",
      "2",
      "4",
      "6",
      "8"
    ],
    answer: "②",
    solution: ""
  },
  {
    id: 485,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 ax+11>-7 의 해가 x>-9 일 때, 상수 a 의\n값을 구하시오.",
    choices: [],
    answer: "-2",
    solution: ""
  },
  {
    id: 486,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 9x-10<4x+2a 를 만족시키는 자연수 x 가\n3 개일 때, 상수 a 의 값의 범위는?",
    choices: [
      "a> ;2%;",
      "a É 5",
      ";2%; <a É 5"
    ],
    answer: "4",
    solution: ""
  },
  {
    id: 487,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0487",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 488,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식 3(7-3x)>2(x+2)-5 를 만족시키는 x 의",
    choices: [],
    answer: "-7 a , b 의 값을 구한다 .",
    solution: ""
  },
  {
    id: 489,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4 a\nx-4\n일차부등식 x+  ¾ x-0.5 를 만족시키는 음의 정수 x\n두 일차부등식 ;2{;- < ;2%;, 3- ;6!; x<-x+2a 의 해\n3  6\n4\n가 2 개 이상일 때, 상수 a 의 값 중 가장 작은 수를 구하시오.\n가 서로 같을 때, 상수 a 의 값을 구하시오.\n일차부등식\n04\n71",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 490,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x 3\n-2<x É 8 일 때, A=3-  를 만족시키는 모든 정수 A 일차부등식 (a+b)x+2a-3b<0 의 해가 x>-  일\n2 4\n의 값의 합을 구하시오. 때, 일차부등식 (a-2b)x+3a-b<0 의 해를 구하시오.\n(단, a , b 는 상수이다.)",
    choices: [],
    answer: "3x+7 , 3x+7 , 10 , 9",
    solution: ""
  },
  {
    id: 491,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "값 중에서 가장 큰 정수를 a , 일차부등식\n1\n일차부등식 (a-1)x>b 의 해가 x<  이고 |b|=1 일 때,\n3\n1.8x+0.5>1.3x-1 을 만족시키는 x 의 값 중에서 가장\n상수 a , b 에 대하여 a-b 의 값을 구하시오.\n작은 정수를 b 라 할 때, ab 의 값을 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 492,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0492",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 493,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "수의 3 배에 7 을 더한 수보다 작다고 할 때, 어떤 자연수 중\n올 때는 같은 길을 시속 3` km 로 걸어서 전체 걸리는 시간을\n가장 큰 수를 구하려고 한다. 다음  안에 알맞은 것을 써\n4 시간 이내로 하려고 한다 . 최대 몇 km 떨어진 지점까지 올라\n넣으시오.\n갔다 내려올 수 있는지 구하려고 할 때 , 다음 물음에 답하시오 .\nx `km 떨어진 지점까지 올라갔다 내려온다고 할\n❶ 미지수 정하기 어떤 자연수를 x 라 하자.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 494,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "10`% 의 소금물 400` g 에 물을 넣어서 농도가\n[0504~0507]\n8`% 이하가 되게 하려고 한다 . 최소 몇 g 의 물을 넣어야 하는\n부등식을 푸시오.",
    choices: [],
    answer: "x+(x+1)>53",
    solution: ""
  },
  {
    id: 495,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "지 구하려고 할 때 , 다음 물음에 답하시오 .\n가장 작은 두 자연수를 구하시오. 물을 x `g 넣는다고 할 때, 아래 표를 완성하시오.",
    choices: [],
    answer: "㉡을 (a-2b)x+3a-b<0 에 대입하면 x>26",
    solution: ""
  },
  {
    id: 496,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0496",
    choices: [],
    answer: "x>-8",
    solution: ""
  },
  {
    id: 497,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "부등식을 푸시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 498,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "최소 몇 g 의 물을 넣어야 하는지 구하시오.",
    choices: [],
    answer: ":¢4°:",
    solution: ""
  },
  {
    id: 499,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "일차부등식의 활용\n05\n73",
    choices: [],
    answer: "다. 11 개",
    solution: ""
  },
  {
    id: 500,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "어떤 자연수의 5 배에서 13 을 뺀 수는 때, 아래 표를 완성하시오.\n5x-13 yy ㉠\n올라갈 때 내려올 때\n어떤 자연수의 3 배에 7 을 더한 수는\n❷ 부등식 세우기 거리 x` km x` km\nyy ㉡\n속력 시속 2` km\n㉠이 ㉡보다 작으므로\n시간\n5x-13< yy ㉢\n㉢의 부등식을 풀면 x<\n❸ 부등식 풀기\n부등식을 세우시오.",
    choices: [],
    answer: "-1",
    solution: ""
  },
  {
    id: 501,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "따라서 어떤 자연수 중 가장 큰 수는 이다.\n㉢에 x=9 를 대입하면 부등식이 참이고,\n부등식을 푸시오.",
    choices: [],
    answer: ";2{; + ;3{; É 4",
    solution: ""
  },
  {
    id: 502,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "❹ 확인하기 x=10 을 대입하면 부등식이 거짓이므로 문\n제의 뜻에 맞는다.\n최대 몇 km 떨어진 지점까지 올라갔다 내려올",
    choices: [],
    answer: ":ª5¢:",
    solution: ""
  },
  {
    id: 503,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "수 있는지 구하시오.\n연속하는 두 자연수의 합이 53 보다 크다고 한\n[0494~0496]\n다 . 이를 만족시키는 가장 작은 두 자연수를 구하려고 할 때 ,\n다음 물음에 답하시오 . 농도에 대한 문제\n05 - 3\n두 자연수 중 작은 수를 x 라 할 때, 부등식을 세우시오.",
    choices: [],
    answer: "있다. :ª5¢:` km",
    solution: ""
  },
  {
    id: 504,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "물을 넣기 전 물을 넣은 후\n농도 (%) 10 8\n[0497~0499] 한 개에 800 원인 초콜릿을",
    choices: [],
    answer: "1",
    solution: ""
  },
  {
    id: 505,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "초콜릿을 x 개 산다고 할 때, 부등식을 세우시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 506,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "부등식을 푸시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 507,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "초콜릿을 최대 몇 개까지 살 수 있는지 구하시오.",
    choices: [],
    answer: "따라서 11 개월 후부터이다. ③",
    solution: ""
  },
  {
    id: 508,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "터인가? (단, 이자는 생각하지 않는다.)\n연속하는 두 홀수가 있다. 작은 수의 4 배에서 10 을 뺀 것은",
    choices: [
      "7 개월",
      "8 개월",
      "9 개월\n큰 수의 2 배 이상일 때, 이를 만족시키는 가장 작은 두 홀",
      "10 개월",
      "11 개월\n수의 합을 구하시오."
    ],
    answer: "따라서 네 번째 시험에서 94 점 이상을 받아야 한다. 94 점",
    solution: ""
  },
  {
    id: 509,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어떤 자연수의 2 배에서 8 을 빼었더니 36 보다 작다고 한다.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 510,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "차가 4 인 두 정수의 합이 19 보다 크다고 한다. 두 수 중 작\n은 수를 x 라 할 때, x 의 값이 될 수 있는 가장 작은 수를 구",
    choices: [],
    answer: "98 점",
    solution: ""
  },
  {
    id: 511,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "④ 12 개월 ⑤ 13 개월\n연속하는 세 자연수의 합이 150 보다 작다고 한다. 이와 같\n은 수 중에서 가장 큰 세 자연수를 구하시오.\n. 일차부등식\nIII\n74",
    choices: [],
    answer: "따라서 여학생은 최대 10 명이다. 10 명",
    solution: ""
  },
  {
    id: 512,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "③ 연속하는 두 홀수 ( 짝수 ) x , x+2 또는 x-2 , x\n현재 민구의 통장에는 39000 원, 가은이의 통장에는\n④ 연속하는 세 홀수 ( 짝수 )\n60000 원이 예금되어 있다. 다음 달부터 민구는 매월\nx-2 , x , x+2 또는 x , x+2 , x+4\n7000 원씩, 가은이는 매월 4000 원씩 예금할 때, 민구의 예\n금액이 가은이의 예금액보다 많아지는 것은 몇 개월 후부",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 513,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "이를 만족시키는 자연수 중 가장 큰 수는?\n현재 병주의 예금액은 120000 원이다. 다음 달부터 매월\n8000 원씩 예금한다면 몇 개월 후부터 병주의 예금액이",
    choices: [
      "17",
      "18",
      "19\n300000 원보다 많아지는지 구하시오.",
      "20",
      "21\n(단, 이자는 생각하지 않는다.)\neunji010220@naver.com"
    ],
    answer: ";1 Á 0¼0; _400 É ;10*0; _(400+x)",
    solution: ""
  },
  {
    id: 514,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "하시오.\n현재 형의 예금액은 30000 원, 동생의 예금액은 10000 원이\n다. 다음 달부터 매월 형은 3000 원, 동생은 2000 원씩 예금\n한다면 형의 예금액이 동생의 예금액의 2 배보다 적어지는\n것은 몇 개월 후부터인가? (단, 이자는 생각하지 않는다.)",
    choices: [
      "9 개월",
      "10 개월",
      "11 개월"
    ],
    answer: "x ¾ 100",
    solution: ""
  },
  {
    id: 515,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0515",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 516,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "주희의 지난달 휴대 전화 요금은 40000 원, 이번 달 휴대",
    choices: [],
    answer: "16",
    solution: ""
  },
  {
    id: 517,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0517",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 518,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "유빈이는 인터넷 쇼핑몰에서 배와 사과를 합하여 15 개를\n어떤 반의 남학생 15 명의 평균 키가 170 `cm , 여학생의 평균\n사려고 한다. 배 1 개의 가격은 4000 원, 사과 1 개의 가격은\n키가 160 `cm 라 한다. 이 반 학생 전체의 평균 키가 166 `cm\n2500 원이고 배송료가 3000 원이라 한다. 이때 배송료를 포\n이상일 때, 여학생은 최대 몇 명인지 구하시오.\n함한 전체 금액이 45000 원 이하가 되게 하려면 배는 최대\n몇 개까지 살 수 있는지 구하시오.\n일차부등식의 활용\n05\n75",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 519,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "지우는 세 번의 수학 시험에서 각각 80 점, 76 점, 86 점을 받\n한 개에",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 520,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "전화 요금은 32000 원이다. 세 달에 걸친 휴대 전화 요금의\n한 번에 900 `kg 까지 운반할 수 있는 승강기가 있다. 몸무\n평균이 35000 원 이하가 되려면 다음 달 휴대 전화 요금이\n게가 90 `kg 인 한 사람이 승강기에 타고 한 개에 30 `kg 인\n얼마 이하이어야 하는지 구하시오.\n상자를 여러 개 운반하려고 한다. 이때 한 번에 최대 몇 개\n의 상자를 운반할 수 있는지 구하시오.",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 521,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "준현이는 5 회에 걸친 영어 시험에서 4 회까지의 평균이 83 어느 전시회의 1 인당 관람료가 어른은 3000 원, 어린이는\n점이었다. 총 5 회의 영어 시험 점수의 평균이 86 점 이상이",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 522,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0522",
    choices: [],
    answer: "것이 유리하다. 9 자루",
    solution: ""
  },
  {
    id: 523,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다녀오는 왕복 교통비가 6000 원일 때, 장미를 몇 송이 이\n대공원 주차장의 주차 요금은 처음 10 분까지는 2000 원이\n상 사는 경우 꽃 도매 시장에서 사는 것이 유리한지 구하시오.\n고 10 분이 지나면 1 분당 50 원의 요금이 추가된다고 한다.\n주차 요금이 5000 원을 넘지 않으려면 최대 몇 분까지 주차\n할 수 있는가?",
    choices: [
      "55 분",
      "60 분",
      "65 분"
    ],
    answer: "5 회",
    solution: ""
  },
  {
    id: 524,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어느 휴대 전화 요금제는 매달 문자 메시지 200 개가 무료\n이고 200 개를 넘으면 1 개당 20 원의 요금이 부과된다고 한\n다. 문자 메시지 사용 요금이 6000 원을 넘지 않게 하려면",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 525,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "eunji010220@naver.com\n어느 미술관의 입장료가 4 명까지는 1 인당 5000 원이고 4 명\n을 초과하면 초과된 사람은 1 인당 4000 원이라 한다.\n50000 원 이하의 금액으로 이 미술관에 입장하려고 할 때,",
    choices: [],
    answer: "다. 14 명",
    solution: ""
  },
  {
    id: 526,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "증명사진 8 장을 인화하는 데 드는 비용이 18000 원이고, 8\n이 인터넷 화장품 사이트에서 1 년에 몇 회 이상 주문하면\n장을 넘으면 한 장 추가할 때마다 900 원씩 추가 비용이 든\n회원으로 가입하는 것이 비회원인 것보다 배송료가 경제적\n다고 한다. 사진 1 장의 가격이 1500 원 이하가 되게 하려면\n인지 구하시오. (단, 배송료는 주문한 화장품의 개수나 배\n증명사진을 몇 장 이상 인화해야 하는지 구하시오.\n송 지역과는 관계없다.)\n. 일차부등식\nIII\n76",
    choices: [],
    answer: "21 명",
    solution: ""
  },
  {
    id: 527,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "기본요금\n장미를 동네 꽃집에서 사면 1 송이에 3000 원인데 꽃 도매\n시장에서 사면 1 송이에 1800 원이라 한다. 꽃 도매 시장에",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 528,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "④ 70 분 ⑤ 75 분\n동네 문구점에서 한 자루에",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 529,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "문자 메시지를 최대 몇 개까지 보낼 수 있는지 구하시오.\n집 앞 가게에서 한 개에 800 원 하는 과자를 할인 매장에서\n는 20`% 할인하여 판매하고 있다. 할인 매장에 다녀오는\n왕복 교통비가 1600 원일 때, 과자를 몇 개 이상 사는 경우\n할인 매장에서 사는 것이 유리한지 구하시오.",
    choices: [],
    answer: "3 개",
    solution: ""
  },
  {
    id: 530,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형",
      "표"
    ],
    wide: false,
    content: "최대 몇 명까지 입장할 수 있는지 구하시오.\n어떤 인터넷 화장품 사이트에서는 다음 표와 같이 배송료\n를 받고 있다.\n비회원 회원\n연회비 (원) 없음 11500\n1 회 주문 시 배송료 (원) 3500",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 531,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "= ;2!; _{ ( 윗변의 길이 ) + ( 아랫변의 길이 ) }_ ( 높이 )\n어느 박물관의 입장료는 한 사람당 7000 원이고, 50 명 이상\n의 단체인 경우 입장료의 30`% 를 할인해 준다고 한다. 50",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 532,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0532",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 533,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0533",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 534,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "입장료가 한 사람당 8000 원이고 단체 입장 시 할인율이 다",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 535,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "명 미만의 단체가 입장하려고 할 때, 몇 명 이상부터 50 명\n삼각형의 세 변의 길이가 x+1 , x+6 , x+10 일 때, 다음\n의 단체 입장권을 사는 것이 유리한가?\n중 x 의 값이 될 수 없는 것은?\n(단, 50 명 미만이어도 50 명의 단체 입장권을 살 수 있다.)",
    choices: [
      "3",
      "4",
      "5",
      "32 명",
      "33 명"
    ],
    answer: "따라서 원가는 7500 원 이상이다. 7500 원",
    solution: ""
  },
  {
    id: 536,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "어느 과학 체험전의 입장료는 한 사람당 3000 원이고, 20 명\n이상의 단체인 경우 입장료는 한 사람당 2000 원이라 한다. 가로의 길이가 10 `cm 인 직사각형이 있다. 이 직사각형의\n20 명 미만의 단체가 입장하려고 할 때, 몇 명 이상부터 20 둘레의 길이가 28 `cm 이상이 되게 하려면 세로의 길이는\n명의 단체 입장권을 사는 것이 유리한지 구하시오. 몇 cm 이상이어야 하는지 구하시오.\n(단, 20 명 미만이어도 20 명의 단체 입장권을 살 수 있다.)\neunji0102",
    choices: [],
    answer: "따라서 세로의 길이는 4 `cm 이상이어야 한다. 4 `cm",
    solution: ""
  },
  {
    id: 537,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "어느 공원의 입장료는 한 사람당 5000 원이고, 25 명 이상의\n오른쪽 그림과 같이 밑면인 원의 반지름의\n단체인 경우 입장료의 20`% 를 할인해 준다고 한다. 25 명\n길이가 3 `cm 인 원뿔이 있다. 이 원뿔의 부\n미만의 단체가 입장하려고 할 때, 몇 명 이상부터 25 명의\n피가 42 p `cm Ü ` 이상일 때, 원뿔의 높이는\n단체 입장권을 사는 것이 유리한지 구하시오.\n몇 cm 이상이어야 하는지 구하시오.\n(단, 25 명 미만이어도 25 명의 단체 입장권을 살 수 있다.)\n\u0014ADN",
    choices: [],
    answer: "14 `cm 2단계",
    solution: ""
  },
  {
    id: 538,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형",
      "표"
    ],
    wide: false,
    content: "음 표와 같은 미술관이 있다. 20 명 이상 30 명 미만의 단체\n\u0019ADN\n오른쪽 그림과 같이 윗변의 길이\n가 입장하려고 할 때, 몇 명 이상부터 30 명의 단체 입장권\n가 8 `cm , 높이가 4 `cm 인 사다리 \u0015ADN\n을 사는 것이 유리한지 구하시오.\n꼴이 있다. 이 사다리꼴의 넓이가\n(단, 30 명 미만이어도 30 명의 단체 입장권을 살 수 있다.)\n40 `cm ` Û 이하일 때, 아랫변의 길이는 몇 cm 이하이어야 하\n인원 단체 입장권 할인율\n는지 구하시오.\n20 명 이상 30 명 미만 10`%\n명 이상\n30 20`%\n일차부등식의 활용\n05\n77",
    choices: [],
    answer: "12 `cm",
    solution: ""
  },
  {
    id: 539,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "은 길을 시속 4 `km 로 걸어서 4 시간 40 분 이내에 등산을\n원가가 6000 원인 물건을 정가의 10`% 를 할인하여 팔아서\n마치려고 한다. 이때 최대 몇 km 떨어진 지점까지 올라갔\n원가의 20`% 이상의 이익을 얻으려고 할 때, 정가는 얼마\n다 내려올 수 있는지 구하시오.\n이상으로 정하면 되는가?",
    choices: [
      "7000 원",
      "7500 원",
      "8000 원",
      "8500 원",
      "9000 원"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 540,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "km 인지 구하시오.\n원가가 15000 원인 신발이 있다. 이 신발을 정가의 40`% 를\n할인하여 팔아서 3000 원 이상의 이익을 얻으려고 할 때,\n정가는 얼마 이상으로 정해야 하는지 구하시오.",
    choices: [],
    answer: "30000 원",
    solution: ""
  },
  {
    id: 541,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "걸린다고 할 때, 터미널에서 몇 km 이내에 있는 상점을 이\n어느 상품에 원가의 30`% 의 이익을 붙여 정가를 정하였\n용해야 하는가?\n다. 세일 기간 중에 1500 원을 할인하여 판매하였더니 원가\n의 10`% 이상의 이익을 얻었을 때, 이 상품의 원가는 얼마",
    choices: [
      ";3@; `km",
      ";4#; `km",
      "1`km\n이상인지 구하시오.",
      ";4%; `km",
      ";2#; `km\n. 일차부등식\nIII\n78"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 542,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "등산을 하는데 올라갈 때는 시속 3 `km 로, 내려올 때는 같",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 543,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "동원이는 아버지와 함께 올레길을 산책하였다. 갈 때는 시\n속 4 `km 로 걸었고, 올 때는 갈 때보다 1 `km 더 먼 길을\n시속 5 `km 로 걸었다. 산책하는 데 걸린 시간이 2 시간 이\n내였다면 동원이와 아버지가 갈 때 걸은 거리는 최대 몇",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 544,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "터미널에서 버스를 기다리는데 출발하기 전까지 1 시간의\n여유가 있어서 그 사이에 상점에 가서 물건을 사오려고 한\n다. 시속 3 `km 로 걷고, 상점에서 물건을 사는 데 10 분이",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 545,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0545",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 546,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "7`% 의 소금물 300` g 이 있다. 이 소금물에 물을 더 넣어 농\n집에서 2 `km 떨어진 도서관까지 가는데 처음에는 분속\n도가 5`% 이하가 되게 하려고 할 때, 물을 몇 g 이상 더 넣\n60 `m 로 걷다가 늦을 것 같아 도중에 분속 180 `m 로 뛰었\n어야 하는지 구하시오.\n더니 20 분 이내에 도착하였다. 이때 몇 m 이상을 분속\n180 `m 로 뛰어야 하는가?",
    choices: [
      "800 `m",
      "900 `m"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 547,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "는가?\nA 지점에서 16 `km 떨어진 B 지점까지 가는데 처음에는\n시속 9 `km 로 자전거를 타고 달리다가 도중에 자전거가 고",
    choices: [
      "20 `g",
      "25 `g",
      "30 `g\n장 나서 시속 3 `km 로 걸었다. B 지점에 2 시간 40 분 이내",
      "35 `g",
      "40 `g\n에 도착하였을 때, 시속 3 `km 로 걸은 거리는 최대 몇 km\n인지 구하시오.\n일차부등식의 활용\n05\n79"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 548,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "A 지점에서 10 `km 떨어진 B 지점까지 가는데 처음에는\n10`% 의 소금물 600 `g 이 있다. 이 소금물에서 물을 증발시\n시속 5 `km 로 걷다가 도중에 시속 3 `km 로 걸어서 3 시간\n켜 농도가 15`% 이상이 되게 하려고 할 때, 최소 몇 g 의\n이내에 B 지점에 도착하려고 한다. 이때 몇 km 이상을 시\neunji010220@naver.c\n물을 증발시켜야 하는지 구하시오.\n속 5 `km 로 걸어야 하는가?",
    choices: [
      "2 `km",
      "2.5 `km",
      "3 `km",
      "3.5 `km",
      "4 `km"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 549,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0549",
    choices: [],
    answer: "300` g",
    solution: ""
  },
  {
    id: 550,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "8`% 의 소금물 200 `g 에 소금을 더 넣어 20`% 이상의 소금\n물을 만들려고 한다. 이때 소금을 몇 g 이상 더 넣어야 하",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 551,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "B 가 있다. 두 합금 A , B 를 녹여서 구리를 130 `g 이상 포\n14`% 의 소금물 300 `g 과 9`% 의 소금물을 섞어서 12`% 이\n함하는 합금 500 `g 을 만들려고 할 때, 합금 B 는 최소 몇 g\n하의 소금물을 만들려고 한다. 9`% 의 소금물을 몇 g 이상\n이 필요한지 구하시오.\n섞어야 하는가?",
    choices: [
      "150 `g",
      "180 `g",
      "200 `g",
      "230 `g",
      "250 `g"
    ],
    answer: "∴ x ¾",
    solution: ""
  },
  {
    id: 552,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "가?\n4`% 의 소금물 400 `g 과 8`% 의 소금물을 섞어서 7`% 이하",
    choices: [
      "80 `g",
      "100 `g",
      "120 `g\n의 소금물을 만들려고 한다. 8`% 의 소금물을 몇 g 이하 섞",
      "140 `g",
      "160 `g\n어야 하는지 구하시오."
    ],
    answer: "",
    solution: ""
  },
  {
    id: 553,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 100 `g 당 열량을 나타낸 A 150\n12`% 의 설탕물과 20`% 의 설탕물을 섞어서 14`% 이상의\nB 350\n것이다. 두 식품 A , B 를 합\n설탕물 600 `g 을 만들려고 한다. 20`% 의 설탕물을 몇 g 이\n하여 400 `g 을 섭취하여 열\n상 섞어야 하는지 구하시오.\n량 700` kcal 이상을 얻으려고 할 때, 식품 B 는 최소 몇 g\n을 섭취해야 하는지 구하시오.\n. 일차부등식\nIII\n80",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 554,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "구리를 20`% 포함한 합금 A 와 구리를 30`% 포함한 합금",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 555,
    level: "",
    category: "일차부등식",
    originalCategory: "일차부등식",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "금이 40`% 포함된 합금 A 와 금이 70`% 포함된 합금 B 가\n있다. 두 합금 A , B 를 녹여서 금이 180 `g 이상 포함된 합\n금 300 `g 을 만들려고 할 때, 합금 A 는 최대 몇 g 이 필요한",
    choices: [],
    answer: "120` g",
    solution: ""
  }
];
