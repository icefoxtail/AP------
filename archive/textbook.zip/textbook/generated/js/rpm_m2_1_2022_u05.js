window.examTitle = "22개정 RPM 중학수학 2-1 | 5단원 일차부등식의 활용";

window.questionBank = [
  {
    id: 556,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "오른쪽 표는 두 식품 A , B\n식품 열량 `( kcal )",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 557,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0557",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 558,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "형은 21 개의 구슬을 가지고 있고, 동생은 6 개의 구슬을 가\n지고 있다. 형이 동생에게 몇 개의 구슬을 주면 형이 가지\n고 있는 구슬의 개수는 동생이 가지고 있는 구슬의 개수의",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 559,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "현재 지유와 태호의 통장 잔액은 각각 35000 원, 20000 원\n이다. 다음 달부터 지유는 매달 8000 원씩, 태호는 매달",
    choices: [],
    answer: "7 `cm",
    solution: ""
  },
  {
    id: 560,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연속하는 세 짝수의 합이 57 보다 크다고 한다. 이와 같은 서윤이의 4 회까지의 50 `m 달리기 대회 기록의 평균이 8.6\n수 중에서 가장 작은 세 짝수를 구하시오. 초이었다. 5 회까지의 대회 기록의 평균이 8.8 초 이내가 되\n려면 5 회째 대회에서 몇 초 이내로 들어와야 하는가?",
    choices: [
      "9.2 초",
      "9.4 초",
      "9.6 초",
      "9.8 초",
      "10 초"
    ],
    answer: "É 8.8 , 34.4+x É 44 따라서 원가는 4500 원 이하이어야 한다. ②",
    solution: ""
  },
  {
    id: 561,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "2 배보다 적어진다고 한다. 이때 형이 동생에게 준 구슬은\n몇 개 이상이어야 하는가? 한 권에 800 원인 공책과 한 자루에 500 원인 볼펜 2 자루를\n구입하려고 한다. 전체 금액이 9000 원 이하가 되게 하려면",
    choices: [
      "2 개",
      "3 개",
      "4 개\n공책을 최대 몇 권까지 살 수 있는가?",
      "5 개",
      "6 개"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 562,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "2000 원씩 예금한다고 할 때, 지유의 예금액이 태호의 예금\n어느 음악 사이트에서는 음악 4 곡을 내려받는 데 2000 원\n액의 3 배보다 많아지는 것은 몇 개월 후부터인가?\n이고 4 곡을 넘으면 한 곡 추가할 때마다 300 원이 추가된다\n(단, 이자는 생각하지 않는다.)\n고 한다. 음악 한 곡을 내려받는 데 400 원 이하가 되게 하",
    choices: [
      "9 개월",
      "10 개월",
      "11 개월\n려면 최소 몇 곡을 내려받으면 되는지 구하시오.",
      "12 개월",
      "13 개월\n일차부등식의 활용\n05\n81"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 563,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0563",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 564,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "4 `km 로 걷고, 정윤이는 시속 2 `km 로 걸을 때, 민성이와\n10`cm\n오른쪽 그림과 같은 직사각형\nA D\n정윤이가 2 `km 이상 떨어지려면 몇 분 이상 걸어야 하는\nABCD 에서 변 CD 의 중점을 M\n가?\n8`cm\nM\n이라 하자. s APM 의 넓이가\n26 `cm ` Û 이하가 되도록 변 BC 위",
    choices: [
      "10 분",
      "15 분",
      "20 분\nB C\nP\n에 점 P 를 정하려고 할 때, 점 B",
      "25 분",
      "30 분\n에서 몇 cm 이상 떨어진 곳에 점 P 를 정하면 되는지 구하\n시오."
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 565,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "4`% 의 설탕물과 9`% 의 설탕물을 섞어서 7`% 이상의 설\n정가가 9000 원인 모자를 40`% 할인하여 팔아서 원가의 탕물 700 `g 을 만들려고 할 때, 4`% 의 설탕물을 몇 g 이하\n20`% 이상의 이익을 얻으려고 할 때, 원가는 얼마 이하이 섞어야 하는가?\n어야 하는가?",
    choices: [
      "200 `g",
      "230 `g",
      "250 `g",
      "4000 원",
      "4500 원"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 566,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어느 놀이공원의 입장료는 1 인당 20000 원인데 40 명 이상 A 지점에서 12 `km 떨어진 B 지점까지 가는데 처음에는\n의 단체에 대해서는 입장료의 25`% 를 할인해 준다고 한 시속 2 `km 로 걷다가 도중에 시속 6 `km 로 뛰어서 4 시간\n다. 40 명 미만의 단체가 입장하려고 할 때, 몇 명 이상부터 이내에 B 지점에 도착하려고 한다. 이때 몇 km 이상을 시\n40 명의 단체 입장권을 사는 것이 유리한가? 속 6 `km 로 뛰어야 하는지 구하시오.\n(단, 40 명 미만이어도 40 명의 단체 입장권을 살 수 있다.)",
    choices: [
      "30 명",
      "31 명",
      "32 명",
      "33 명",
      "34 명"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 567,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "민성이와 정윤이가 같은 지점에서 동시에 출발하여 서로\n반대 방향으로 직선 도로를 따라 걷고 있다. 민성이는 시속",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 568,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0568",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 569,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0569",
    choices: [],
    answer: "5 명",
    solution: ""
  },
  {
    id: 570,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형",
      "표"
    ],
    wide: false,
    content: "5`% 의 소금물 200` g 이 있다. 이 소금물에서 물을 증발시\n다음은 A 회사와 B 회사의 무선인터넷 사용 요금 안내표\n킨 후 증발시킨 물의 양만큼 소금을 넣어 농도가 8`% 이상\n이다. 한 달 사용 시간이 몇 시간 초과일 때, B 회사를 이용\n이 되게 하려고 한다. 이때 물을 몇 g 이상 증발시켜야 하\n하는 것이 유리한지 구하시오.\n는지 구하시오.\nA 회사 B 회사\n기본요금 시간당 요금 기본요금 시간당 요금\n6000 원 400 원 30000 원 없음",
    choices: [],
    answer: "따라서 물을 6` g 이상 증발시켜야 한다. 6` g",
    solution: ""
  },
  {
    id: 571,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 100 `g 당 단백질의 양을\nA 15\n역에서 기차를 기다리는데 출발하기 전까지 1 시간 15 분의\nB 20\n나타낸 것이다. 두 식품 A ,\n여유가 있어서 이 시간을 이용하여 상점에 가서 물건을 사\nB 를 합하여 300 `g 을 섭취\n오려고 한다. 시속 4 `km 로 걷고, 상점에서 물건을 사는 데\n하여 단백질 56 `g 이상을 얻으려고 할 때, 식품 A 는 몇 g\n15 분이 걸린다고 할 때, 역에서 몇 km 이내에 있는 상점\n이하 섭취해야 하는지 구하시오.\n을 이용하면 되는지 구하시오.\n일차부등식의 활용\n05\n83",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 572,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "한 개에 2000 원인 광어 초밥과 한 개에 3000 원인 소고기 어떤 일을 끝내는 데 남자 한 명은 10 일, 여자 한 명은 12\n초밥을 합하여 12 개를 주문하려고 한다. 배달비 2000 원을 일이 걸린다고 한다. 남녀를 합하여 11 명이 하루에 일을 끝\n포함한 전체 금액이 30000 원 이하가 되도록 하려면 소고 내려고 한다면 남자는 최소 몇 명이 필요한지 구하시오.\n기 초밥을 최대 몇 개까지 주문할 수 있는지 구하시오.\neunji010220@naver.c",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 573,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0573",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 574,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "오른쪽 표는 두 식품 A , B\n식품 단백질 `( g )",
    choices: [],
    answer: "60 시간",
    solution: ""
  },
  {
    id: 575,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "일차방정식 x+y=5 에 대하여 표를 완성한 후",
    choices: [],
    answer: "(4 , 4)",
    solution: ""
  },
  {
    id: 576,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(x , y) 로 나타내시오.\nx 1 2 3 4 5\n;[@; -y=1 ( )",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 577,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "y\nx+3y=2x+3y+2 ( )\n일차방정식 x+2y=7 에 대하여 표를 완성한 후",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 578,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0578",
    choices: [],
    answer: "_",
    solution: ""
  },
  {
    id: 579,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "내시오.\n(0 , -4) ( )",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 580,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y=8\n(1 , -1) ( )\n[",
    choices: [],
    answer: "따라서 x=1 , y=-2 는 주어진 연립방정식의 해가 아니다.",
    solution: ""
  },
  {
    id: 581,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 가 자연수일 때, 연립방정식 의",
    choices: [],
    answer: "_",
    solution: ""
  },
  {
    id: 582,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "다음 연립방정식 중 x=1 , y=-2 가 해인 것은\n[0589~0592]\n◯ , 해가 아닌 것은 ×를 ( ) 안에 써넣으시오 .\n[0583~0584] 다음 일차방정식에 대하여 표를 완성한 후 이를\n이용하여 x , y 가 자연수일 때 , 일차방정식의 모든 해를 x , y 의\n2x+y=0\n[\n( )",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 583,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y=-1\n[\n( )",
    choices: [],
    answer: "(1 , 14) , (2 , 10) , (3 , 6) , (4 , 2) 풀이 참조",
    solution: ""
  },
  {
    id: 584,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x\n-7x+2y=-11\n[\n( )",
    choices: [],
    answer: "(12 , 1) , (7 , 2) , (2 , 3) 풀이 참조",
    solution: ""
  },
  {
    id: 585,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "이를 이용하여 일차방정식의 모든 해를 x , y 의 순서쌍\n-3x+ ;4}; =5x ( )",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 586,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "이를 이용하여 일차방정식의 모든 해를 x , y 의 순서쌍\n(x , y) 로 나타내시오.\nx\ny 1 2 3 4\n다음 x , y 의 순서쌍 중 일차방정식 3x-y=4\n[0579~0582]\n의 해인 것은 ◯ , 해가 아닌 것은 ×를 ( ) 안에 써넣으시오 .\n연립방정식의 해를 x , y 의 순서쌍 (x , y) 로 나타",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 587,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-1 , 1) ( )",
    choices: [],
    answer: "x=-3 , y=-8",
    solution: ""
  },
  {
    id: 588,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x+y=16\n해를 x , y 의 순서쌍 (x , y) 로 나타내시오.\n(3 , 5) ( )",
    choices: [],
    answer: "y 의 차수가 2 이므로 일차방정식이 아니다. _",
    solution: ""
  },
  {
    id: 589,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "순서쌍 (x , y) 로 나타내시오 .\nx-y=3\n4x+y=18",
    choices: [],
    answer: "x 가 분모에 있으므로 일차방정식이 아니다. _",
    solution: ""
  },
  {
    id: 590,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x 1 2 3 4 5 4x-y=5\ny\nx=2y+6\n[\n( )",
    choices: [],
    answer: "3_0-(-4)=4 ◯ 식",
    solution: ""
  },
  {
    id: 591,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x=-2y-3\nx+5y=17",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 592,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y 1 2 3 4\n3x-8y=19\n연립일차방정식\n06\n87",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 593,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x+4y=13 yy ㉡\n3x-5y=7\n입법으로 푸는 과정이다.  안에 알맞은 것을 써넣으시오.\n[",
    choices: [],
    answer: "(1 , 4) , (2 , 3) , (3 , 2) , (4 , 1) 풀이 참조 10y= 10 ∴ y= 1",
    solution: ""
  },
  {
    id: 594,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x-y=-4\n[0603~0604] 다음 연립방정식을 푸시오 .\n3x+y=11\n[",
    choices: [],
    answer: "(5 , 1) , (3 , 2) , (1 , 3) 풀이 참조",
    solution: ""
  },
  {
    id: 595,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(\n3x+4y=-1\n;2{; ;4};\n+ =1\n{",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 596,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5x+3y=1 yy ㉡\n감법으로 푸는 과정이다.  안에 알맞은 수를 써넣으시오.\neunji010220@naver.com\n다음 방정식을 푸시오 .\n[0605~0606]\ny 를 없애기 위해 ㉠ _3+ ㉡을 하면\n2x+y=x+2y=-3",
    choices: [],
    answer: "∴ y=2 답 x=1 , y=2",
    solution: ""
  },
  {
    id: 597,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[\n-x+2y=3",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 598,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0598",
    choices: [],
    answer: "x=-2 , y=8",
    solution: ""
  },
  {
    id: 599,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x-3(x-2y)=10\n㉠에서 x 를 y 에 대한 식으로 나타내면\n2(x-4)+y=-4\n[\nx= yy ㉢",
    choices: [],
    answer: "x=4 , y=1",
    solution: ""
  },
  {
    id: 600,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5x-(y-1)=18\n㉢을 ㉡에 대입하면 3( )+4y=13\n10y= ∴ y=\n다음 연립방정식을 푸시오 .\n[0601~0602]\ny= 을 ㉢에 대입하면 x=\nx+0.4y=1.2\n[",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 601,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "0.2x-0.3y=1\n[0594~0595] 다음 연립방정식을 대입법으로 푸시오 .\n1.3x-y=-0.7\n[",
    choices: [],
    answer: "x=5 , y=-4 y=-2 를 ㉣에 대입하면",
    solution: ""
  },
  {
    id: 602,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y=x-5\n0.03x-0.1y=-0.17\n[",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 603,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: ";3{; - ;4}; =- ;3*;\n¥ 9\n(\n;3!; x- ;2!; y=2\n연립방정식의 풀이 ; 가감법\n06 - 4\n{",
    choices: [],
    answer: "x=3 , y=3",
    solution: ""
  },
  {
    id: 604,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6x-y=-8 yy ㉠\n;5!; x- ;1¦0; y=- ;5@;\n[ ¥ 9\n다음은 연립방정식 을 가",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 605,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "23x= ∴ x=\nx= 을 ㉠에 대입하면 6_( )-y=-8\n4x+y=6x-2y=x+11",
    choices: [],
    answer: "x=3 , y=-2 ∴ x=-1 답 x=-1 , y=-1",
    solution: ""
  },
  {
    id: 606,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "∴ y=\n- 해가 특수한 연립방정식\n06 6\n다음 연립방정식을 가감법으로 푸시오 .\n[0597~0598]\n[0607~0608] 다음 연립방정식을 푸시오 .\nx-4y=-9\n3x+6y=8\n[",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 607,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6x+12y=10\n7x-3y=2 2x+y=4\n[ [",
    choices: [],
    answer: "해가 없다.",
    solution: ""
  },
  {
    id: 608,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-4x+y=-4 4x+2y=8\n연립일차방정식\n06\n89",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 609,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 보기 중 미지수가 2 개인 일차방정식인 것을 모두 고른",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 610,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 미지수가 2 개인 일차방정식은?",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 611,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "가로의 길이가 x `cm , 세로의 길이가 y `cm 인 직사각형의\n둘레의 길이가 49 `cm 일 때, x , y 에 대한 일차방정식으로\n나타내시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 612,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0612\n③ x-2y+4=0 ④ x+5y-1=0\n다음 중 ax-3y=4x+5y-1 이 미지수가 2 개인 일차방\n⑤ 4x-3y+11=0\n정식이 되도록 하는 상수 a 의 값이 아닌 것은?\n① 0 ② 1 ③ 2\n④ 3 ⑤ 4\n. 연립일차방정식\nIV\n90",
    choices: [
      "x-2y+4=0",
      "x+5y-1=0\n다음 중 ax-3y=4x+5y-1 이 미지수가 2 개인 일차방",
      "4x-3y+11=0\n정식이 되도록 하는 상수 a 의 값이 아닌 것은?",
      "0",
      "1"
    ],
    answer: "이 아닌 것은 ⑤ 이다. 답 ⑤",
    solution: ""
  },
  {
    id: 613,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "것은?\n다음 중 주어진 x , y 의 순서쌍이 미지수가 2 개인 일차방정\n보기\n식의 해인 것은?\nㄱ. 3x-y=2 ㄴ. 2x+3y-1",
    choices: [
      "5x+y=-2 (-1 , 6)\n;5!; ;3!;\nㄷ. x+ y=1 ㄹ. 3x+y=3(x-y+1)",
      "-x+2y=8 (1 , 4)\nㅁ. xy+3x+y=5 ㅂ. x+1=-4y",
      "3x-y=0 (1 , 0)",
      "-4x+7y=5 (-4 , -3)",
      "ㄱ, ㄷ"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 614,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0614\n① xÛ`+y+1=0 ② x+6y=x-y-2\nx , y 가 자연수일 때, 일차방정식 2x+3y=26 을 만족시키\n③ 2y-(x-y) ④ x=4y-3\n는 x , y 의 순서쌍 (x , y) 는 모두 몇 개인가?\n⑤ xy+x=7\n① 3 개 ② 4 개 ③ 5 개\n④ 6 개 ⑤ 7 개",
    choices: [
      "xÛ`+y+1=0",
      "x+6y=x-y-2\nx , y 가 자연수일 때, 일차방정식 2x+3y=26 을 만족시키",
      "2y-(x-y)",
      "x=4y-3\n는 x , y 의 순서쌍 (x , y) 는 모두 몇 개인가?",
      "xy+x=7"
    ],
    answer: "해가 무수히 많다.",
    solution: ""
  },
  {
    id: 615,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 방정식 중 x=-2 , y=1 을 해로 갖는 것을 모두 고\n르면? (정답 2 개)\n① x-y+1=0 ② x+y+3=0",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 616,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "게 하는 x , y 의 값\n일차방정식 ax+3y=6 의 한 해가 x=-3 , y=1 일 때,\n상수 a 의 값은?",
    choices: [],
    answer: "이상에서 미지수가 2 개인 일차방정식은 ㄱ, ㄷ, ㅂ이다. ③",
    solution: ""
  },
  {
    id: 617,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 의 순서쌍 (-4 , k) 가 일차방정식 x-5y=16 의 한",
    choices: [
      "ㄱ, ㄴ",
      "ㄱ, ㄷ",
      "ㄴ, ㄷ\n해일 때, k 의 값은?",
      "ㄴ, ㄹ",
      "ㄷ, ㄹ"
    ],
    answer: "∴ k=-4 ①",
    solution: ""
  },
  {
    id: 618,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "명이 받도록 모두 나누어 주었다.\n일차방정식 ax-y-3=0 의 한 해가 x=2 , y=7 이다.\ny=-13 일 때, x 의 값은? (단, a 는 상수이다.)\nx-y=11 x-y=11",
    choices: [
      "[",
      "[\n4x-5y=50 4x+5y=50",
      "-2",
      "-1",
      "0"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 619,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 의 순서쌍 (4 , a) , (b+1 , 3) 이 모두 일차방정식",
    choices: [],
    answer: "2x+2y=49 2_4-a=4 ∴ a=4 … 1단계",
    solution: ""
  },
  {
    id: 620,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0620\n① -2 ② -1 ③ 1\n보기\n다음 의 연립방정식 중 x=1 , y=2 를 해로 갖는 것을\neunji010220@naver.c\n④ 2 ⑤ 3\n모두 고른 것은?\n보기\nx+y=3 x+2y=5\nㄱ. [ ㄴ. [\nx-y=1 2x+3y=8\n2x-y=-1 4x+y=6\nㄷ. [ ㄹ. [\n6x+5y=16 3x-2y=-1",
    choices: [
      "-2",
      "-1",
      "1\n보기\n다음 의 연립방정식 중 x=1 , y=2 를 해로 갖는 것을\neunji010220@naver.c",
      "2",
      "3\n모두 고른 것은?\n보기\nx+y=3 x+2y=5\nㄱ. [ ㄴ. [\nx-y=1 2x+3y=8\n2x-y=-1 4x+y=6\nㄷ. [ ㄹ. [\n6x+5y=16 3x-2y=-1"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 621,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 문장을 미지수가 2 개인 연립방정식으로 나타내면?\n초콜릿 50 개를 전체 학생 11 명에게 4 개씩 x 명, 5 개씩 y",
    choices: [],
    answer: "따라서 p=-2 , q=2 이므로 p+q=-2+2=0 ③",
    solution: ""
  },
  {
    id: 622,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-y=4 의 해일 때, a+6b 의 값을 구하시오.\n2x+3y=19\n[\nx , y 가 자연수일 때, 연립방정식 의 해는\n4x+y=13\nx=a , y=b 이다. ab 의 값을 구하시오.\n연립일차방정식\n06\n91",
    choices: [],
    answer: "다음 표에서 4x+y=13 의 해는 (1 , 9) , (2 , 5) , (3 , 1) 2",
    solution: ""
  },
  {
    id: 623,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0623",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 624,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-9y=3\n[\n연립방정식 를 만족시키는 y 의 값이 -1\nax+5y=-14\n일 때, 상수 a 의 값을 구하시오.",
    choices: [],
    answer: "3",
    solution: ""
  },
  {
    id: 625,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-x+3y=-11\nx , y 의 순서쌍 (2 , b) 가 연립방정식 [ 의\n3x+ay=9\n해일 때, b-a 의 값을 구하시오. (단, a 는 상수이다.)\neunji010220@naver.com",
    choices: [],
    answer: "∴ b-a=-3-(-1)=-2 -2",
    solution: ""
  },
  {
    id: 626,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y=4x-8\n[\n연립방정식 의 해가 일차방정식\nx+2y=4\ny=-6x+22\n[\n연립방정식 의 해가 x=b+2 , y=b-2 일\nax+y=16\nax+y-10=0 을 만족시킬 때, 상수 a 의 값을 구하시오.\n때, a+b 의 값은? (단, a 는 상수이다.)",
    choices: [
      "6",
      "9",
      "12",
      "15",
      "18\n. 연립일차방정식\nIV\n92"
    ],
    answer: "∴ a+b=4+2=6 ①",
    solution: ""
  },
  {
    id: 627,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y=a 2x-y=-6\n[ [\n연립방정식 의 해가 x=4 , y=-2 일 때, 상 연립방정식 의 해가 x=p , y=q 일 때,\nbx-y=10 x=-3y+4\n수 a , b 에 대하여 ab 의 값을 구하시오. p+q 의 값은?",
    choices: [
      "-4",
      "-2",
      "0",
      "2",
      "4"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 628,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y=7-5x yy` ㉠\n연립방정식 [ 에서 ㉠을 ㉡에 대입하\n3x-2y=12 yy` ㉡\n여 y 를 없애면 kx=26 이다. 이때 상수 k 의 값을 구하시오.",
    choices: [],
    answer: "따라서 연립방정식으로 나타내면 13x=26 ∴ k=13 13",
    solution: ""
  },
  {
    id: 629,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0629",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 630,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0630\n① -2 ② -1 ③ 0\nx-5y=14\n[\n연립방정식 을 만족시키는 x , y 에 대하여\n④ 1 ⑤ 2\n2x-y=10\nx-y 의 값을 구하시오.",
    choices: [
      "-2",
      "-1",
      "0\nx-5y=14\n[\n연립방정식 을 만족시키는 x , y 에 대하여",
      "1",
      "2\n2x-y=10\nx-y 의 값을 구하시오."
    ],
    answer: "",
    solution: ""
  },
  {
    id: 631,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0631",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 632,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x-y=9",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 633,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 연립방정식의 해가 나머지 넷과 다른 하나는?\nx+y=-1 x+2y=-4\n① [ ② [",
    choices: [],
    answer: "-6+2y=14, 2y=20 ∴ y=10 ②",
    solution: ""
  },
  {
    id: 634,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "❷ 계수의 부호가 같으면 변끼리 빼고 , 계수의 부호가 다르면 변\n3x+4(y-1)=-3\n끼리 더하여 해를 구한다 .\n[\n연립방정식 의 해가 x=a , y=b 일\n2(x-y)-12=y\n때, a+b 의 값은?",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 635,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x-3y=6 yy` ㉠\n3(x+2y)-4y=2\n[\n연립방정식 에서 가감법을 이용하\n[\n연립방정식 를 풀면?\n3x+2y=13 yy` ㉡\n7x-2(3x-y)=14\n여 y 를 없애려고 한다. 이때 필요한 식은?",
    choices: [
      "x=-6 , y=-10",
      "x=-6 , y=10",
      "㉠ _3+ ㉡ _2",
      "㉠ _3- ㉡ _2",
      "x=-6 , y=15"
    ],
    answer: "5a+b=5_1+(-7)=-2 -2",
    solution: ""
  },
  {
    id: 636,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "연립방정식 [ 의 해가 x=a , y=b 일 때,\n10x+3y=-11\n4(x+y)-3y=-7\n[\n연립방정식 의 해가 일차방정식\n5a+b 의 값을 구하시오.\n3x-2(x+y)=5\n3x-2y=a 를 만족시킬 때, 상수 a 의 값을 구하시오.",
    choices: [],
    answer: "a=3_(-1)-2_(-3)=3 3",
    solution: ""
  },
  {
    id: 637,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x-y=5 4x-y=11\n5(x+2y)=7y-1\n연립방정식 [ 의 해가 x=a ,\n3x+4y=-6 6x+y=9\n3(x-4)=4(x+y)-5",
    choices: [
      "[",
      "[\n5x-y=13 x+6y=-16\ny=b 일 때, 일차방정식 bx=a 의 해를 구하시오.\n2x+3y=-2",
      "[\n3x-5y=16\n연립일차방정식\n06\n93"
    ],
    answer: "x=- ;2!;",
    solution: ""
  },
  {
    id: 638,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0638",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 639,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "0.01x+0.07y=2\n[\n연립방정식 에서 각각의 방정식의 계\n0.4x-0.3y=-18\n수를 정수로 고치려고 한다. 다음 중 바르게 고친 것은?\nx+7y=2 x+7y=20\n[ [\n① ②",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 640,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y x+y\n(\n-  =1\n4 6\n연립방정식 { 을 푸시오.\nx-y 2x+y\n-  =-6\n¥ 9 2 3",
    choices: [],
    answer: ";5$;",
    solution: ""
  },
  {
    id: 641,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6x-ky=8 k\n을 만족시킬 때, 상수 의 값을 구하시오.\nx , y 의 순서쌍 (a , b) 가 연립방정식\n(\n0.01x+0.02y=0.07\n{ 의 해일 때, ab 의 값을 구하시오.\n;3!; x- ;2#; y=-2\n¥ 9\n. 연립일차방정식\nIV\n94",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 642,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 의 순서쌍 (a , b) 가 연립방정식\n(\n;5!; x+ ;2!; y=- ;2!;\n연립방정식 { 의 해가 x=a , y=b 일 (x+1)` : `3y=3` : `2\n[ 의 해일 때, a+b 의 값은?\n0.03x-0.01y=0.18\n¥ 9\n2(x-3)+3(2y-x)=-2\n때, a-b 의 값을 구하시오.",
    choices: [
      "-10",
      "-6",
      "-4",
      "6",
      "10"
    ],
    answer: "∴ x=-4 ②",
    solution: ""
  },
  {
    id: 643,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4x-3y=-18 4x-3y=-18\n3 `:` (x+4y)=2 `:` (3x-2)\n[\nx+7y=20 x+7y=200 연립방정식 을 만족시키는\n[ [",
    choices: [
      "0.1x+0.4y=0.6\n4x-3y=-180 4x-3y=-18 eunji0102\nx , y 에 대하여 x-y 의 값은?\nx+7y=200\n[",
      "1",
      "2",
      "3\n4x-3y=-180",
      "4"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 644,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(\n1` : `(y-3)=4` : `(x+6)\n{\n연립방정식 y 의 해가 일차방정식\n3x+2\n-  =-1\n5  4\n¥ 9",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 645,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0645",
    choices: [],
    answer: "따라서 a=3 , b=2 이므로 ab=3_2=6 6",
    solution: ""
  },
  {
    id: 646,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 방정식을 만족시키는 x , y 에 대하여 y-x 의 값을 구",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 647,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0647",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 648,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "방정식 ax-3by+8=3ax+by-6=x+5y 의 해가\nx-3y+1 y-1 x=5 , y=1 일 때, 상수 a , b 에 대하여 a-2b 의 값을 구하\n방정식 x+2y=  =2x-  의 해가 x=a ,\n2 3\n시오.\ny=b 일 때, 2a+7b 의 값을 구하시오.\n연립일차방정식\n06\n95",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 649,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "ax+by=9\n방정식 x-2y+7=2x+3y+6=-5x-y-18 을 풀면?\n[\nx , y 의 순서쌍 (5 , -1) 이 연립방정식 의 해\nbx-ay=7",
    choices: [
      "x=-4 , y=-1",
      "x=-4 , y=1\n일 때, 상수 a , b 에 대하여 a+b 의 값은?",
      "x=4 , y=-1",
      "x=4 , y=1",
      "-2"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 650,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "하시오.\nax+by=13\n[\n연립방정식 의 해가 x=2 , y=-1 일 때,\nax-2by=-2\n5x-2y=3x+y-10=8\n상수 a , b 에 대하여 ab 의 값을 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 651,
    level: "",
    category: "일차부등식의 활용",
    originalCategory: "일차부등식의 활용",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-02",
    standardUnit: "일차부등식",
    standardUnitOrder: 2,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x , y 의 순서쌍 (a , b) 가 방정식\n4x+7y+a=0\neunji010220@naver.com\n4(x-2)=2x+2y-4=3x-3y+18 [\n연립방정식 의 해가 x=3 , y=b 일 때,\nax-9y=24\n의 해일 때, a Û `+b Û ` 의 값은?\na+b 의 값을 구하시오. (단, a 는 상수이다.)",
    choices: [
      "20",
      "45",
      "61",
      "85",
      "100"
    ],
    answer: "",
    solution: ""
  }
];
