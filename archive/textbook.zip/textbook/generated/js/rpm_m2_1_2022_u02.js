window.examTitle = "22개정 RPM 중학수학 2-1 | 2단원 단항식의 계산";

window.questionBank = [
  {
    id: 157,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0157",
    choices: [],
    answer: "=-25a¡` -25a¡`",
    solution: ""
  },
  {
    id: 158,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(2Ý`)Ü` y",
    choices: [],
    answer: "2x",
    solution: ""
  },
  {
    id: 159,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0159",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 160,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "xÜ`\n(xÛ`)ß`_(xÜ`)Þ`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 161,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0161",
    choices: [],
    answer: "-5x Û `y",
    solution: ""
  },
  {
    id: 162,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3 2a\naÞ`_(aÜ`)Ü`_(aÞ`)Û``",
    choices: [],
    answer: "(x y Û `) Ý `=x Ú ` Û `y 3 , 8",
    solution: ""
  },
  {
    id: 163,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "\n(aÜ`) =aÛ`Ú`",
    choices: [],
    answer: "8a Ü `",
    solution: ""
  },
  {
    id: 164,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "\n(x )Û`_xÜ`=xÚ`Ü` x\nx",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 165,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5x\n(-15xÜ`y)Ö  `",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 166,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: ";2!; xß`yÝ`Ö { - ;8!; xÛ`yÛ` }",
    choices: [],
    answer: "=-4x Ý `y Û ` -4x Ý `y Û `",
    solution: ""
  },
  {
    id: 167,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "{ - ;2!; xÜ`y } _(-10xyÛ`)",
    choices: [],
    answer: "2ab",
    solution: ""
  },
  {
    id: 168,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[0182~0185] 다음 식을 계산하시오 .\n(-4ab)Û`Ö8ab",
    choices: [],
    answer: "6x",
    solution: ""
  },
  {
    id: 169,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-3x)Ü`Ö { - ;2(; xÛ` }",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 170,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "b\n(2aÛ`bÜ`)Û`Ö(-ab)Ü`Ö",
    choices: [],
    answer: "=a Ü ` Ö a Ý `= = ;a!; ;a!;",
    solution: ""
  },
  {
    id: 171,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "18xÛ`y_ {;3!; xy } 2 `",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 172,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-xyÛ`)Û`_(2xÜ`y)Ü`",
    choices: [],
    answer: "10",
    solution: ""
  },
  {
    id: 173,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "단항식의 곱셈과 나눗셈의 혼합 계산\n-\n02 7\n5a\n{ }\n(-aÛ`b)Ü`_ 2` _b",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 174,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[0186~0192] 다음 식을 계산하시오 .\nbÛ`\neunji010220@naver.com\n3xÛ`_4xÜ`Ö2x",
    choices: [],
    answer: "(ab Û `) Û `=a Û `_(b Û `) Û `=a Û `b Ý ` a Û `b Ý `",
    solution: ""
  },
  {
    id: 175,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-2a)Ü`_5aÛ`Ö(-4aÝ`)",
    choices: [],
    answer: "-8a Ú ` Û `",
    solution: ""
  },
  {
    id: 176,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "xyÛ`_ { - ;[$; } 2` Ö8xÛ`y",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 177,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "bÞ`\n(-aÛ`bÜ`)Ü`Ö  _(-5a)Û`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 178,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "단항식의 계산\n02\n31",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 179,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 식을 계산하시오 .\n[0165~0169]\n3a_2aÛ`",
    choices: [],
    answer: "=",
    solution: ""
  },
  {
    id: 180,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "yÛ`\n9xÛ`_4xÛ`y",
    choices: [],
    answer: "-3x Û `y Ü `",
    solution: ""
  },
  {
    id: 181,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "15aÝ`b_ { - ;5!; ab }",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 182,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-aÛ`b)_4a_2abÞ`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 183,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "xyÜ`\n[0170~0174] 다음 식을 계산하시오 .\nÖ { - ;5@; xÛ`y } 2`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 184,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5\n(-x)Ü`_3xÛ`",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 185,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2a\n7ab_(-2b)Û`",
    choices: [],
    answer: "-8a Û `b Û `",
    solution: ""
  },
  {
    id: 186,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6abÛ`_(-2aÛ`b)Ö4ab",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 187,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4xÜ`\n8xÛ`yÖ  _2yÜ`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 188,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "yÜ`\n단항식의 나눗셈\n02 - 6\n다음 식을 계산하시오 .\n[0175~0178] 4xÝ`yÛ`Ö { - ;3$; xÛ`y } _(-xyÜ`)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 189,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "10xÛ`Ö5x",
    choices: [],
    answer: "=4xÝ`yÛ`_ { - } _(-xyÜ`)=3xÜ`yÝ` 3xÜ`yÝ`",
    solution: ""
  },
  {
    id: 190,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "6abÖbÛ`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 191,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "35xÞ`yÜ`Ö(-7xÜ`yÛ`)",
    choices: [],
    answer: "따라서 가장 큰 수는 ③ 이다. ③",
    solution: ""
  },
  {
    id: 192,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-56aÜ`bÝ`)Ö(-8aÞ`bÝ`)\naÛ`",
    choices: [],
    answer: "-25a Ú `â`b Ý `",
    solution: ""
  },
  {
    id: 193,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0193",
    choices: [],
    answer: "즉 5+a=8 이므로 a=3 ③",
    solution: ""
  },
  {
    id: 194,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "aÜ`_bÛ`_a_bÜ` 을 간단히 하면?",
    choices: [
      "xÞ`yÚ`â`",
      "xß`yÚ`Û`",
      "xß`yÚ`Ü`",
      "xà`yÚ`Û`",
      "xà`yÚ`Ü`"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 195,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "27Û`Å` ÑÚ`=3Ú`Ú`ÑÅ` 일 때, 자연수 x 의 값을 구하시오.\n자연수 x , y 에 대하여 x+y=4 이고 a=3Å` , b=3´` 일 때,\nab 의 값을 구하시오.",
    choices: [],
    answer: "81 따라서 계산 결과가 나머지 넷과 다른 하나는 ⑤ 이다. 답 ⑤",
    solution: ""
  },
  {
    id: 196,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 가장 큰 수는?\n2_4_6_8_10_12_14=2`_3º`_5`_7¶` 일 때, 자연\n수 a , b , c , d 에 대하여 a+b+c+d 의 값은? 30",
    choices: [
      "2Ý`â`",
      "3",
      "4Û`Þ`",
      "5Û`â`",
      "18Ú`â`"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 197,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Û`_2Ü`_2`=256 일 때, 자연수 a 의 값은? 5Ý`_(5ÅÅ`)Ü`=5Ú`ß` 일 때, 자연수 x 의 값을 구하시오.\neunji010220@naver.c",
    choices: [
      "1",
      "2",
      "3",
      "4",
      "5"
    ],
    answer: "4",
    solution: ""
  },
  {
    id: 198,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(xÜ`)Û`_yÜ`_x_(yÛ`)Þ` 을 간단히 하면?",
    choices: [],
    answer: "=-3a Û `b Û ` -3a Û `b Û `",
    solution: ""
  },
  {
    id: 199,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0199",
    choices: [],
    answer: "x",
    solution: ""
  },
  {
    id: 200,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0200",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 201,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0201\n① 8 ② 9 ③ 10\n다음 중 옳은 것은?\n④ 11 ⑤ 12\n① aá`ÖaÜ`=aÜ` ② aÞ`ÖaÞ`=0\n1\n③ (aÜ`)Û`ÖaÜ`=aÛ` ④ aÛ`ÖaÖaÜ`=\naÛ`\n⑤ aÞ`ÖaÝ`Öa=a",
    choices: [
      "8",
      "9",
      "10\n다음 중 옳은 것은?",
      "11",
      "12"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 202,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 계산 결과가 나머지 넷과 다른 하나는?",
    choices: [
      "{;5!; xyÛ` } 3` = ;1Á5; xÜ`yß`",
      "xÜ`_xÛ`",
      "xà`ÖxÝ`_xÛ`",
      "(xÛ`)Ý`ÖxÜ`",
      "xÚ`â`ÖxÝ`Öx"
    ],
    answer: "④",
    solution: ""
  },
  {
    id: 203,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "\nxÚ`â`Öx Ö(xÛ`)Ü`=x 일 때,  안에 알맞은 수를 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 204,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "y-x 의 값을 구하시오.\n8Ü`_2`Ö16Û`=2Ú`Þ` 일 때, 자연수 a 의 값을 구하시오.\n단항식의 계산\n02\n33",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 205,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "1 1\n예 xß`ÖxÛ`=xß`ÑÛ`=xÝ` , xß`Öxß`=1 , xÛ`Öxß`= =\nxß`ÑÛ`  xÝ` (-3xÜ`y`)º`=-27x`yá` 일 때, 자연수 a , b , c 에 대하여\na-b+c 의 값은?",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 206,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 옳지 않은 것은?",
    choices: [
      "(-xÛ`yÜ`)Ý`=x¡`yÚ`Û`",
      "(-2aÛ`)Ü`=-8aß`",
      "(3aÛ`bÜ`)Û`=9aÝ`bß`",
      "(-xÛ`yzÜ`)Þ`=-xÚ`â`yÞ`zÚ`Þ`"
    ],
    answer: "⑤",
    solution: ""
  },
  {
    id: 207,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(AxÝ`yõ``zÜ`)Þ`=-32x``yÚ`â`zë 일 때, 상수 A , B , C , D 에 대\n하여 A+B+C+D 의 값을 구하시오.",
    choices: [],
    answer: "35",
    solution: ""
  },
  {
    id: 208,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "216 Ü `=(2 Ü `_3Å`) Ü `=2á`_3´` 일 때, 자연수 x , y 에 대하여",
    choices: [],
    answer: "6",
    solution: ""
  },
  {
    id: 209,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Û`â`+2Û`â`+2Û`â`+2Û`â` 을 간단히 하면?\n2x` bx¡`\n{ } 4` =  일 때, 자연수 a , b , c 에 대하여 a+b-c 의\nyÛ` y`",
    choices: [
      "2Û`Ú`",
      "2Û`Û`",
      "2¡`â`\n값은?",
      "4Û`â`",
      "8Û`â`\neunji010220@naver.c"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 210,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0210\n① 3Ý`_3Ý`_3Ý` ② (3ß`)Û`\n다음 중 옳은 것은?\n③ 3Ú`Ú`+3Ú`Ú`+3Ú`Ú` ④ 9Ü`_9Ü`\n① (abÛ`)Ü`=abß` ② (-10a)Û`=20aÛ\n⑤ 9¡`Ö9Ü`\nbÜ` bß` aÜ`\n2`\n③ { } =  ④ { - ;2A; } 3` =-\n6\naÛ` aÛ`\nb bÝ`\n⑤ {- } 4` = `\n3a\n81aÝ`",
    choices: [
      "3Ý`_3Ý`_3Ý`",
      "(3ß`)Û`\n다음 중 옳은 것은?",
      "3Ú`Ú`+3Ú`Ú`+3Ú`Ú`",
      "9Ü`_9Ü`",
      "(abÛ`)Ü`=abß`"
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 211,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "azÛ` 64zß`\n{ } 3` =-  일 때, 상수 a , b , c 에 대하여 ab+c 의\nxÜ`yº` x`yá`\n값을 구하시오.",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 212,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "1 1 1",
    choices: [
      "2Ü` 2Ý` 2Þ`\nyÝ` yÛ`â`\n5`\n(xÞ`y`)Û`=xÚ`â`yß` , { } =  일 때, 자연수 a , b 에 대하여\n1 1\nx` xº`",
      "2ß` 2à`\nb-a 의 값을 구하시오.\n. 식의 계산\nII\n34"
    ],
    answer: "즉 4-  =1 이므로  =3 3 Þ ` Þ `",
    solution: ""
  },
  {
    id: 213,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0213",
    choices: [],
    answer: "즉 1+a=15 이므로 a=14 14",
    solution: ""
  },
  {
    id: 214,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 계산 결과가 나머지 넷과 다른 하나는?",
    choices: [],
    answer: "a-b+c=3-3+9=9 ②",
    solution: ""
  },
  {
    id: 215,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "7Û`_7Û`_7Û`_7Û`=7` , 5Ý`+5Ý`+5Ý`+5Ý`+5Ý`=5º` 일 때, 자연\n수 a , b 에 대하여 ab 의 값을 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 216,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3ß`+3ß`+3ß` 2ß`+2ß`\n_  을 간단히 하면?\n4ß`+4ß`+4ß`+4ß`  3à`",
    choices: [],
    answer: "= =",
    solution: ""
  },
  {
    id: 217,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "8 개\nx+1\n따라서 2¡`_5á` 은 9 자리 자연수이다 .\nA=3 일 때, 81Å` 을 A 를 사용하여 나타내면?",
    choices: [
      "AÝ`",
      "27AÜ`",
      "81AÝ`"
    ],
    answer: "∴ 81Å`=(3 Ý `)Å`=3 Ý `Å`=(3Å`) Ý `= { } 4 `=",
    solution: ""
  },
  {
    id: 218,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "1\n2Ý`=A 라 할 때, 을 A 를 사용하여 나타내시오.\n32Ý`",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 219,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Ü`=A , 3Û`=B 라 할 때, 72Û` 을 A , B 를 사용하여 나타내면?",
    choices: [
      "AÛ`B",
      "3AÛ`B",
      "AÛ`BÛ`",
      "2AÛ`BÛ`",
      "3AÜ`BÜ`"
    ],
    answer: "따라서 옳은 것은 ⑤ 이다. ⑤",
    solution: ""
  },
  {
    id: 220,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x-1 x+1\nA=3 , B=5 일 때, 15Å` 을 A , B 를 사용하여 나타내\n면?",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 221,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "AÜ` AÝ`",
    choices: [
      "27 81\n2à`_5Ú`â` 이 n 자리 자연수일 때, n 의 값은?",
      "7",
      "8",
      "9",
      "10"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 222,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2ß`_4à`_25¡` 은 몇 자리 자연수인지 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 223,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Ú`ß`_3Ü`_5Ú`Ý` 은 n 자리 자연수이다. 각 자리의 숫자의 합을\np 라 할 때, n+p 의 값을 구하시오.",
    choices: [],
    answer: "-3",
    solution: ""
  },
  {
    id: 224,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "AB",
    choices: [
      ";5#; AB`",
      ";2#; AB\n15\n2Ú`â`_15¡`\n이 n 자리 자연수일 때, n 의 값을 구하시오.\n18Ü`\nAÛ`B",
      ";5#; AÛ`B\n15\n단항식의 계산\n02\n35"
    ],
    answer: "∴ A+B+C=2+3+25=30 30",
    solution: ""
  },
  {
    id: 225,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "예 ( -3abÛ`)_2aÛ`bÜ`=-6aÜ`bÞ`\n어떤 박테리아는 1 시간마다 그 수가 3 배씩 증가한다. 이 박\n문자의 곱\n테리아 9 마리가 7 시간 후에 3` 마리가 된다고 할 때, 자연수\na 의 값은?",
    choices: [],
    answer: "∴ a=9 ③ (-32aà`b Þ `) Ö { - ;;ªb;; } =(-32aà`b Þ `) Ö { -",
    solution: ""
  },
  {
    id: 226,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "종이 한 장을 반으로 접으면 그 두께는 처음의 2 배가 된다.",
    choices: [],
    answer: "=4a Ý `b¡` 4a Ý `b¡`",
    solution: ""
  },
  {
    id: 227,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0227",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 228,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0228\n① 7 ② 8 ③ 9\n(4xÞ`y)Ü`_ { - ;4#; xyÜ` } 2` _(-xÛ`y)Ý` 을 계산하면?\n④ 10 ⑤ 11\n① -36xÛ`Þ`yÚ`Ü` ② -27xÛ`Ü`yÚ`Ü` ③ 16xÛ`Þ`yÚ`Ú`\n④ 27xÛ`Ü`yÚ`Ü` ⑤ 36xÛ`Þ`yÚ`Ü`",
    choices: [
      "7",
      "8",
      "9\n(4xÞ`y)Ü`_ { - ;4#; xyÜ` } 2` _(-xÛ`y)Ý` 을 계산하면?",
      "10",
      "11"
    ],
    answer: "=64xÚ` Þ `yÜ`_ xÛ`yß`_x¡`yÝ`=36x Û ` Þ `y Ú ` Ü ` ⑤",
    solution: ""
  },
  {
    id: 229,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "두께가 0.4 `mm 인 종이 한 장을 반으로 6 번 접었을 때 종\n2\n(-3aÛ`b)Ü ` _ { b } 2` 을 계산하면?\n이의 두께는 (0.4_2`) `mm 이다. 이때 자연수 a 의 값을\n3\n구하시오.",
    choices: [
      "-12aÞ`bß`",
      "-12aß`bÞ`",
      "-6aÞ`bß`\neunji0102",
      "6aß`bÞ`",
      "12aß`bÞ`"
    ],
    answer: "=-12aß`b Þ ` ②",
    solution: ""
  },
  {
    id: 230,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "표"
    ],
    wide: false,
    content: "저장 매체의 저장 용량을 나타낼 때 다음 표와 같은 단위를\n1\n9xÝ`yÛ`_(-2xyÛ`)Ü`_ { -  xÛ`yÛ` } ` 2 =axº`y` 일 때, 상수 a , b ,\n사용한다. 용량이 16` GB 인 메모리 카드에 용량이 8` MB 인\n6\n사진을 최대 몇 장까지 저장할 수 있는가?\nc 에 대하여 a+b-c 의 값을 구하시오.\n단위 용량\n10\nKB (킬로바이트) 2 ` B\n20\nMB (메가바이트)\n2 ` B\n30\nGB (기가바이트) 2 ` B",
    choices: [
      "2à` 장",
      "2á` 장",
      "2Ú`Ú` 장"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 231,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "A\n④ 2Ú`Ü` 장 ⑤ 2Ú`Þ` 장\n(-5xyÜ`) _xÞ`yõ``=Cxà`yá` 일 때, 자연수 A , B , C 에 대하\n여 A+B+C 의 값을 구하시오.\n. 식의 계산\nII\n36",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 232,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-abÛ`)Ü`_ { -  } 2` Ö(-aÛ`b) 를 계산하면?\nbÛ`\n12x¡`yÜ`Ö(-2xÜ`yÛ`)Û`Ö {-;5!; xÛ`yÝ` } 을 계산하면?\naÜ`",
    choices: [
      "-aÛ`bÜ`",
      "-aÜ`b",
      "-\nbÛ`\n15 5 3x\naÜ`",
      "-",
      "-"
    ],
    answer: "9",
    solution: ""
  },
  {
    id: 233,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 옳지 않은 것은?\n2a\n(-32aà`bÞ`)Ö {- } 3 ` 을 계산하시오.\nb",
    choices: [
      "2a_(-3bÛ`)Û`=18abÝ`\n8a",
      "(-16ab)Ö2bÛ`=-\nb",
      "6xÜ`yÜ`Ö(-2xÛ`y)Û`_8xÛ`y=12xyÛ`",
      "xÛ`yÞ`_(-3x)Ü`Ö9xÜ`yÛ`=-3xÛ`yÜ`",
      "(-3xÛ`)Ö { - ;4!; xÛ` } 2` _xÞ`=-48xÛ``"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 234,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-xÛ`yÜ`)Þ`Ö {-;3@; xÜ`y } 2 ` Ö ;8#; yÝ`=axº`y` 일 때, 상수 a , b , c\n에 대하여 a-b+c 의 값을 구하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 235,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0235\n① 24 ② 28 ` ③ 32\n2\n(4xÛ`y`)º`Ö(2x`yÜ`)Ü`= 일 때, 자연수 a , b , c 에 대하\n④ 36` ⑤ 40\nx¡`yÜ`\n여 a+bc 의 값을 구하시오.\n단항식의 계산\n02\n37",
    choices: [
      "24",
      "28 `",
      "32\n2\n(4xÛ`y`)º`Ö(2x`yÜ`)Ü`= 일 때, 자연수 a , b , c 에 대하",
      "36`",
      "40\nx¡`yÜ`\n여 a+bc 의 값을 구하시오.\n단항식의 계산\n02\n37"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 236,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "a",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 237,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0237",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 238,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-2xÜ`y)``Ö4xõ`y_2xÞ`yÛ`=CxÛ`yÜ` 일 때, 자연수 A , B ,\nC 에 대하여 ABC 의 값은?",
    choices: [],
    answer: "4a Û `b",
    solution: ""
  },
  {
    id: 239,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(-8xÜ`y)Û`Ö(4xÛ`y)Û`_ =-20xÜ`yÛ` 일 때,  안에",
    choices: [],
    answer: "③",
    solution: ""
  },
  {
    id: 240,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0240",
    choices: [],
    answer: "11",
    solution: ""
  },
  {
    id: 241,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "\u0016BC\n7y 오른쪽 그림과 같이 가로의 길이가 5ab 이\n어떤 식에 -  를 곱했더니 14xÜ`yÝ` 이 되었다. 이때 어떤\nxÛ`\n고 넓이가 20aÜ`bÛ` 인 직사각형의 세로의\neunji010220@naver.com\n식을 구하시오.\n\u0013\u0011BACA\n길이를 구하시오.",
    choices: [],
    answer: "-2x Þ `y Ü `",
    solution: ""
  },
  {
    id: 242,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "오른쪽 그림과 같이 밑면인 원의 지름의 길\n1\n{ -  xÛ`yÜ` } 3` Ö Ö { - ;3!; xÛ`yÜ` } 2` =-xÛ`y 일 때,  안에 이가 6a 인 원뿔의 부피가 24 p aÜ` 일 때, 이\n2\n원뿔의 높이를 구하시오.\n알맞은 식을 구하시오.\n\u0017B\u0003\n. 식의 계산\nII\n38",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 243,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "알맞은 식은?\n오른쪽 그림과 같이 밑면인 원의 반지",
    choices: [
      "-10xÛ`y",
      "-5xÛ`y",
      "-5xyÛ`\n6xÜ`\n름의 길이가 2xyÞ` , 높이가 인 원기\n\u0017YA",
      "5xyÛ`",
      "10xyÛ` y\nZ\n둥의 부피를 구하시오.\n\u0013YZA"
    ],
    answer: "= 24 p x Þ `yá` 24 p x Þ `yá`",
    solution: ""
  },
  {
    id: 244,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "9xÝ`yÛ`_(-2xyÛ`)Ü`Ö =12xÛ`y 일 때,  안에 알맞은\n밑변의 길이가 4a Û `b 이고 높이가 3ab 인 삼각형의 넓이는?\n식을 구하시오.",
    choices: [
      "3a Û `b",
      "a Ü `b Û `",
      "4a Ü `b Û `",
      "6a Ü `b Û `",
      "12a Ü `b Ü `"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 245,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0245",
    choices: [],
    answer: "따라서 옳지 않은 것은 ⑤ 이다. ⑤",
    solution: ""
  },
  {
    id: 246,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0246",
    choices: [],
    answer: "A+1=3 에서 A=2 8a",
    solution: ""
  },
  {
    id: 247,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3Û`â`_9Û`â` 의 일의 자리의 숫자는?\n3Å` ±Û`+3Å` ±Ú`+3Å`=351 일 때, 자연수 x 의 값은?",
    choices: [
      "1",
      "3",
      "5",
      "1",
      "2"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 248,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0248",
    choices: [],
    answer: "④",
    solution: ""
  },
  {
    id: 249,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0249",
    choices: [],
    answer: "1 x ∴ A<C<B ②",
    solution: ""
  },
  {
    id: 250,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0250",
    choices: [],
    answer: "⑤",
    solution: ""
  },
  {
    id: 251,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Å` ±Ú`+2Å`=192 일 때, 자연수 x 의 값은?\n(7Ü`)Þ`_49¡` 의 일의 자리의 숫자를 구하시오.",
    choices: [
      "3",
      "4",
      "5",
      "6",
      "7\neunji010220@naver.com"
    ],
    answer: "12",
    solution: ""
  },
  {
    id: 252,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음을 만족시키는 자연수 x 의 값을 구하시오. (단, x>1)\n4Û`á`+2Þ`¡`\n의 일의 자리의 숫자를 구하시오.\n16Ü`+8Ý`\nx+1 x x-1\n7 +7 +7 =20Û`-1\n단항식의 계산\n02\n39",
    choices: [],
    answer: "2_2 ③",
    solution: ""
  },
  {
    id: 253,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0253",
    choices: [],
    answer: "따라서 3 =27=3 Ü ` 이므로 x=3 ③",
    solution: ""
  },
  {
    id: 254,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "A=2Û`Ý` , B=3Ú`¡` , C=5Ú`Û` 일 때, 다음 중 A , B , C 의 대소",
    choices: [],
    answer: "따라서 2Å`=64=2ß` 이므로 x=6 ④ 를 비교한다 .",
    solution: ""
  },
  {
    id: 255,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0255",
    choices: [],
    answer: "2",
    solution: ""
  },
  {
    id: 256,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3Å`_27=3Ú`â` 일 때, 자연수 x 의 값은? 다음 두 식을 만족시키는 자연수 m , n 에 대하여 mn 의 값\n을 구하시오.",
    choices: [
      "4",
      "5",
      "6",
      "7",
      "8\n(aÝ`)Û`_(aÛ`)μ``=aÛ`â` , (bÇ`)Ý`ÖbÞ`=bÜ`\neunji010220@naver.c"
    ],
    answer: "①",
    solution: ""
  },
  {
    id: 257,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "관계로 옳은 것은?\n다음 중  안에 알맞은 수가 나머지 넷과 다른 하나는?\n ",
    choices: [
      "A<B<C",
      "A<C<B",
      "a _aÝ`=aà`",
      "(aß`) =aÚ`¡`\n ",
      "B<A<C"
    ],
    answer: "3",
    solution: ""
  },
  {
    id: 258,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 옳지 않은 것은?\n48Ý`=(2Å`_3)Ý`=2´`_3Ý` 일 때, 자연수 x , y 에 대하여 x+y",
    choices: [
      "x¡`ÖxÛ`=xß`",
      "xÚ`Ú`ÖxÝ`Öxà`=1\n의 값은?\n1",
      "xÞ`Ö(xÛ`)Ý`=",
      "(xÜ`)Ü`Öx=x¡`\nx Ü `",
      "8"
    ],
    answer: "4 따라서 x=4 , y=16 이므로 x+y=4+16=20 답 ④",
    solution: ""
  },
  {
    id: 259,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0259",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 260,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "n\n테리아 4 마리가 5 시간 후에 2 마리가 될 때, 자연수 n 의 값\n9Þ`+9Þ`+9Þ`=3Å` , 2Ü`_2Ü`_2Ü`=2´` , {(5Û`)Ü`}Ý`=5½` 일 때, 자\n을 구하시오.\n연수 x , y , z 에 대하여 x-y+z 의 값을 구하시오.",
    choices: [],
    answer: "26",
    solution: ""
  },
  {
    id: 261,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "{ } {- }\nxÛ`y 2 ` _ 3 ` =axº`y` 일 때, 상수 a , b , c 에 대하\n4  x\na=2Å` ÑÚ` 일 때, 8Å` 을 a 를 사용하여 나타내면?\n여 abc 의 값은?",
    choices: [
      "4aÛ`",
      "4aÜ`",
      "8aÛ`",
      "-8",
      "-4"
    ],
    answer: "∴ 8 =(2 Ü `) =2 =(2 ) Ü `=(2a) Ü `=8a Ü ` ④",
    solution: ""
  },
  {
    id: 262,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2y`z cyÚ`â`zÞ`\n2ß`_15Ú`Ü`\n{ } ` 5 =  일 때, 자연수 a , b , c 에 대하여 a+b-c 이 n 자리 자연수일 때, n 의 값은?\nxÜ` xº` 45ß`\n의 값은?",
    choices: [
      "6",
      "7",
      "8",
      "-15",
      "-10"
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 263,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "어떤 박테리아는 30 분마다 그 수가 2 배씩 증가한다. 이 박",
    choices: [],
    answer: "3",
    solution: ""
  },
  {
    id: 264,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2yÛ`\n1",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 265,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0265",
    choices: [],
    answer: "=64xÚ`â`yÝ`_ _ { - } =-",
    solution: ""
  },
  {
    id: 266,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 중 옳지 않은 것은?",
    choices: [
      "8xÛ`_(-3xÜ`)Ö6xÝ`=-4x",
      "(-4xÞ`)Ö2xÝ`_3xÜ`=-6xÝ`\nxÛ`\n{ }",
      "(-2xÜ`y)Ü`Ö4xÛ`yÜ`Ö -  2` =-2xÛ`yÛ`\ny",
      "(-4aÛ`b)Û`_ { - ;2%; abÝ` } Ö(-2ab)Ü`=5aÛ`bÜ`"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 267,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "8x\nÖ(-5xÜ`yÝ`)_(-2xy)Û`=  일 때,  안에 알맞은\ny\n식은?",
    choices: [],
    answer: "②",
    solution: ""
  },
  {
    id: 268,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4 다음 계산 과정을 만족시키는 식 A , B , C 를 구하시오.\n64xÚ`â`yÝ`Ö(-3xy)Û`Ö { -  xÛ`y } 3` 을 계산하면?\n3\nÖ(-4xÝ`yÛ`) _(-2xÛ`y)Ü` Ö6xÜ`yÛ`\nA B C -x\n3xÛ` xÛ` xÛ`",
    choices: [
      "-",
      "-",
      "-\ny 3y y\n3xÛ` xÛ`",
      "y 3y"
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 269,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2\n어떤 식에 -  aÛ`b 를 곱해야 하는데 잘못하여 나누었더니\n3\n9aÝ`bÜ` 이 되었다. 이때 바르게 계산한 식을 구하시오.",
    choices: [],
    answer: "(-6aß`bÝ`)_ { - ;3@; aÛ`b } =4a¡`b Þ ` 답 4a¡`b Þ `",
    solution: ""
  },
  {
    id: 270,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "⑤ {;2!; xÛ`y } 3` _8xyÛ`Ö6xÝ`yÜ`= ;6!; xÜ`yÛ`\n오른쪽 그림과 같이 밑면은 한 변의 길\n이가 2aÛ`b 인 정사각형이고, 부피가\n8aÞ`bÜ` 인 정사각뿔이 있다. 이 정사각뿔\n의 높이를 구하시오.\n2aÛ`b",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 271,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2Å` ±Û`+2Å` ±Ú`+2Å`=224 일 때, 자연수 x 의 값은?",
    choices: [
      "-10xy",
      "-10xÛ`y",
      "-5xÛ`y",
      "5xÛ`y",
      "10xÜ`yÛ`"
    ],
    answer: "③",
    solution: ""
  },
  {
    id: 272,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0272",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 273,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5Þ`+5Þ`+5Þ`+5Þ` 2Þ`+2Þ`+2Þ` a\nm`\n{ }\n_ = 일 때,\nAB\n4Þ`+4Þ`+4Þ` 3Þ`+3Þ`+3Þ`+3Þ`  b\n(-3xÜ`yÛ`)` Ö6xõ` y_8xÞ`yÜ`=CxÛ`y¡` 일 때, 의 값을\nC\nm-a+b 의 값을 구하시오.\n구하시오. (단, A , B 는 자연수, C 는 정수이다.)\n(단, m + 1 인 자연수이고, a , b 는 서로소인 자연수이다.)",
    choices: [],
    answer: "m-a+b=5-5+6=6 6",
    solution: ""
  },
  {
    id: 274,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재",
      "도형"
    ],
    wide: false,
    content: "다음 그림과 같이 반지름의 길이가 2ab 인 구와 밑면의 반\n지름의 길이가 2a 이고 높이가 abÜ` 인 원뿔이 있다. 이때 구",
    choices: [],
    answer: "6ab",
    solution: ""
  },
  {
    id: 275,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 조건을 만족시키는 자연수 x , y 에 대하여 y-x 의 값 (x`yº`z`)¶`=xÜ`â`yÚ`Û`zÛ`Ý` 을 만족시키는 가장 큰 자연수 d 에 대\n을 구하시오. 하여 a+b-c-d 의 값을 구하시오.\n(단, a , b , c 는 자연수이다.)\n2x-1\n㈎ 49Å`_7 =7Ú`Þ`\n㈏ 2Ú`Þ`_5Ú`Ü` 은 y 자리 자연수이다.\neunji010220@naver.c",
    choices: [],
    answer: "10",
    solution: ""
  },
  {
    id: 276,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0276",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 277,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "의 부피는 원뿔의 부피의 몇 배인지 구하시오.\n<12>=2 , <5_7>=5 , <6+7>=3 과 같이 자연수\nA 의 일의 자리의 숫자를 <A> 라 하자. 이때\nBCA\n<(3à`)Ú`â`_81Þ`> 의 값을 구하시오.\n\u0013BC\n\u0013B\n단항식의 계산\n02\n43",
    choices: [],
    answer: "-1 ∴ <(3à`)Ú`â`_81Þ`>=9 답 9",
    solution: ""
  },
  {
    id: 278,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(21a Û `-14ab+35a) Ö (-7a)\n(2x-5y+7)-(4x-y-2)",
    choices: [],
    answer: "=4a-b 4a-b",
    solution: ""
  },
  {
    id: 279,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(8x Û `-6x) Ö ;3@; x",
    choices: [],
    answer: "3a(4a-3)=12a Û `-9a 12a Û `-9a",
    solution: ""
  },
  {
    id: 280,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x+y 3x-2y { ;2!; }\n(2aÛ`b+3abÛ`-ab)Ö - ab",
    choices: [],
    answer: "-8x Û `+4xy+12x",
    solution: ""
  },
  {
    id: 281,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2 5\n다음 식을 계산하시오 .\n다음 식을 계산하시오 . [0296~0299]\n[0282~0285]\nx(-x+1)+3x(x-4)\n(-3aÛ`+2a-1)+(aÛ`-a+7)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 282,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "8xÛ`+6x 15xÛ`y-9xy\n(xÛ`-x-5)-(-2xÛ`+x-1)",
    choices: [],
    answer: "=-2a Û `+a+6 -2a Û `+a+6",
    solution: ""
  },
  {
    id: 283,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-",
    choices: [],
    answer: "=-4a-6b+2 -4a-6b+2",
    solution: ""
  },
  {
    id: 284,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "xÜ`y-2xÛ`yÛ`\n-xy(x-y)",
    choices: [],
    answer: "2x Û `-11x",
    solution: ""
  },
  {
    id: 285,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x(x+2y)+(x Ü `-4x Û `y) Ö ;3{;",
    choices: [],
    answer: "답",
    solution: ""
  },
  {
    id: 286,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "- 식의 대입\n03 4\n4xÛ`+x-{7xÛ`-(2xÛ`+5x)}",
    choices: [],
    answer: "2a+3b",
    solution: ""
  },
  {
    id: 287,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[0300~0301] y=x-3 일 때 , 다음 식을 x 에 대한 식으로 나\n타내시오 .\n( 단항식 )_( 다항식 ) 의 계산\n-\n03 2\n2x+3y",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 288,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-4x(2x-y-3)\nA=x+2y , B=4x-y 일 때 , 다음 식을 x , y",
    choices: [],
    answer: "-2x-4y+9",
    solution: ""
  },
  {
    id: 289,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[0302~0303]\n에 대한 식으로 나타내시오 .\n(xÛ`-3x+1)_5x",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 290,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-A+2B",
    choices: [],
    answer: "= ;3$; a+ ;6!; b ;3$; a+ ;6!; b",
    solution: ""
  },
  {
    id: 291,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "4A-3B",
    choices: [],
    answer: "-ab-2b Û `+3ab Û `",
    solution: ""
  },
  {
    id: 292,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0292",
    choices: [],
    answer: "- ;1Á0; x+ ;1»0; y",
    solution: ""
  },
  {
    id: 293,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0293",
    choices: [],
    answer: "=-3a+2b-5 -3a+2b-5",
    solution: ""
  },
  {
    id: 294,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "{ a- ;3!; b } + {;3!; a+ ;2!; b }",
    choices: [],
    answer: "12x-9",
    solution: ""
  },
  {
    id: 295,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 296,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0296",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 297,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "2x 3xy\n2(aÛ`+a)+3(aÛ`-a-1)",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 298,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "x\n(2xÛ`-3x+7)-2(3xÛ`-5x+1)",
    choices: [],
    answer: "-xy Û `",
    solution: ""
  },
  {
    id: 299,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 식을 계산하시오 .\n[0286~0287]\n5a+{2b-(3a-b)}",
    choices: [],
    answer: "=2x(x+2y)+(x Ü `-4x Û `y)_ ;[#;",
    solution: ""
  },
  {
    id: 300,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다음 식을 전개하시오 .\n[0288~0291]\nx-4y-7",
    choices: [],
    answer: "5+(-2)=3 ③",
    solution: ""
  },
  {
    id: 301,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3a(4a-3)",
    choices: [],
    answer: "-3x+5",
    solution: ""
  },
  {
    id: 302,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "{ }\n(2a+4b-6ab)_ - ;2B;",
    choices: [],
    answer: "①",
    solution: ""
  },
  {
    id: 303,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "다항식의 계산\n03\n45",
    choices: [],
    answer: "=2x Û `+13x-4 2x Û `+13x-4",
    solution: ""
  },
  {
    id: 304,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "1",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 305,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "-2(3a-b+3)+3(2a-3b+4) 를 계산하면?",
    choices: [],
    answer: "=3x-4x-8y+6",
    solution: ""
  },
  {
    id: 306,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "(x-4y-5)-3(-3x+4y+1) 을 계산했을 때, x 의 계",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 307,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0307",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 308,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "{ ;3@; } {;4#; ;6!; }\nx- y - x- y =ax+by 일 때, 상수 a , b 에\n2\n(xÛ`-6x+5)-(-4xÛ`-x+7) 을 계산했을 때, xÛ` 의 계\n대하여 bÖa 의 값을 구하시오.\n수와 상수항의 합은?",
    choices: [
      "-5",
      "-2",
      "3",
      "5",
      "7"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 309,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "[원문 PDF 추출 검수 필요] 0309\n① -7b-6 ② -7b+6\n다음 중 이차식인 것을 모두 고르면? (정답 2 개)\n③ 7b+6 ④ -12a-7b+6\n① -4x Û `+2x ② 5x-4y+1\n⑤ 12a+7b-6\neunji0102\n1\n③ -3 ④ xÛ`+7x-xÛ`\nxÛ`\n⑤ (x Û `+2x)-(x+1)",
    choices: [
      "-7b-6",
      "-7b+6\n다음 중 이차식인 것을 모두 고르면? (정답 2 개)",
      "7b+6",
      "-12a-7b+6",
      "-4x Û `+2x"
    ],
    answer: "",
    solution: ""
  },
  {
    id: 310,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "수와 y 의 계수의 합을 구하시오.\n-5(2x Û `-x-4)+4(3x Û `+2x-6) 을 계산하시오.",
    choices: [],
    answer: "",
    solution: ""
  },
  {
    id: 311,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "5x-3y x-2y\n(x Û `+x-3)-2 {;2%; x Û `- ;2&; x+1 } =ax Û `+bx+c 일 때,\n-  +x 를 계산하시오.\n3 2\n상수 a , b , c 에 대하여 a+b+c 의 값을 구하시오.\n. 식의 계산\nII\n46",
    choices: [],
    answer: "-1",
    solution: ""
  },
  {
    id: 312,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "객관식",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "3x- [ 2y-x-{4y-5(x+2y)}-6 ] 을 계산하면?",
    choices: [
      "-x-8y+6",
      "-x+8y-6",
      "3x-8y+6",
      "3x+8y-6",
      "4x-8y+6"
    ],
    answer: "bÖa=- ;2!; Ö { - ;4!;} =- ;2!; _(-4)=2 2",
    solution: ""
  },
  {
    id: 313,
    level: "",
    category: "단항식의 계산",
    originalCategory: "단항식의 계산",
    standardCourse: "중2 수학",
    standardUnitKey: "M2-01",
    standardUnit: "수와 식",
    standardUnitOrder: 1,
    questionType: "단답형",
    layoutTag: "grid",
    tags: [
      "RPM",
      "교재"
    ],
    wide: false,
    content: "a+4b-{6a-(a-b)} 를 계산하시오.",
    choices: [],
    answer: "답",
    solution: ""
  }
];
