# AP Math Past Exam PDF Pipeline

This pipeline converts selected school past-exam PDFs into reviewable JS Archive
candidates. It is intentionally separate from the textbook pipeline.

## Role Boundary

This is an extraction pipeline, not a solution-writing pipeline.

Codex owns the repeatable file and image work:

- PDF page rendering.
- Full-page image creation for every exam page.
- Ordered question registration in one JS file per exam.
- Question crop creation and quality review.
- Visual asset crop creation for diagrams, graphs, tables, coordinate planes,
  and other problem-internal figures.
- Candidate JS structure and safe path wiring.
- Official answer-table mapping when answer evidence exists.
- Packaging unresolved OCR/content/answer work with the smallest sufficient
  image evidence for GPT/Gemini.

GPT/Gemini owns the mathematical language and reasoning work:

- OCR cleanup from crop/full-page evidence.
- Student-facing solution writing.
- Direct solving when no official answer evidence exists.
- Classification fields such as `level`, `standardUnitKey`, and related unit
  metadata, unless a separate deterministic tag enrichment pass is requested.

Do not treat missing or weak `solution` as a Codex extraction failure. Treat weak
question crops, missing full-page fallback, broken image paths, question-number
misalignment, or incomplete JS registration as Codex extraction failures.

## Safety Rules

- Inventory may scan the whole source folder.
- JS generation requires an explicit selected manifest or one-exam manifest.
- Generated files stay under `archive/_generated/past-exams`.
- The pipeline must not stop because OCR, content, answer, or solution evidence
  is missing. It must emit the safest candidate JS, write a queue/report for the
  unresolved part, package the necessary image evidence, and continue to the next
  selected PDF.
- Before any GPT/Gemini solution or classification work starts, the candidate JS
  must have 100% of the expected questions registered with stable numbering,
  source full-page references, readable question crops or explicit fallback
  pages, and complete objective choices when Codex can verify them from source
  images. Missing content is an extraction/content-stage blocker, not a
  solution-stage excuse.
- Each exam must be completed as one ordered JS file first. The manager verifies
  `displayNo` order and continuity from full-page images before using question
  crops. Crops are close-up evidence, not the primary source for deciding whether
  a question exists or where it belongs.
- The live archive is protected:
  - `archive/exams/**/*.js`
  - `archive/db.js`
  - `archive/engine.html`
  - `archive/mixed_engine.html`
  - `archive/mixer.html`

## Naming

- `examId` is the canonical title.
- `window.examTitle` equals `examId`.
- Candidate filenames may include a work suffix such as `.candidate.js`.
- Work suffixes must not be included in `window.examTitle`.

Example:

```js
window.examTitle = "25_제일고_1학기_기말_고2_대수";
```

## First Commands

From `C:/Users/USER/Desktop/AP------`:

```powershell
node archive/tools/past-exam-pipeline/run-batch.mjs --config archive/tools/past-exam-pipeline/pipeline.config.example.json --inventory
```

Create a selected manifest without running conversion:

```powershell
node archive/tools/past-exam-pipeline/run-batch.mjs --config archive/tools/past-exam-pipeline/pipeline.config.example.json --create-selected --recent-years 3 --grade 고1 --exam-type 중간
```

Run only the selected manifest:

```powershell
node archive/tools/past-exam-pipeline/run-batch.mjs --config archive/tools/past-exam-pipeline/pipeline.config.example.json --selected-manifest archive/_generated/past-exams/_batch/selected_manifest.json --run-selected
```

## Current Stage Contract

The current scaffold implements:

1. PDF inventory.
2. Filename/folder metadata parsing.
3. Selected manifest creation.
4. Per-exam generated folder creation.
5. Problem PDF page rendering.
6. Solution PDF page rendering when a solution source exists.
7. 4-page two-column 20-objective + 4-essay scanned exam crop seeding.
8. Question crop quality audit and optional recrop/tightening.
   - This mirrors the textbook pipeline's `06B-review-crop-quality` family.
   - The generated reports flag blank, tiny, oversized, boundary-tight, or
     missing question crops before visual assets are trusted.
9. Visual asset crop for figure/graph/table questions.
   - Question crops are source evidence; visual assets are the smaller figure,
     graph, table, or coordinate-plane regions inside those question crops.
   - Auto-crop may first write isolated working files under the generated exam
     folder, but candidate JS that will be reviewed or promoted must use the
     archive runtime path `assets/images/{examTitle}/q{id}.png`.
   - The physical file must exist at
     `archive/assets/images/{examTitle}/q{id}.png`. Do not leave JS `image`
     pointing at `_generated/.../assets`, `pages/`, or `crops/questions/`.
   - This mirrors the textbook pipeline's `07-visual-asset-crop` stage and
     prevents answer/solution agents from inferring missing diagrams from text
     alone.
10. Missing full-page/question-crop recovery for visual assets.
   - If a visual-needed question has no question crop, recover the full-page
     evidence first. Treat `pageNo = 0` as an unmapped/zero-based value and
     infer the page from `sourcePageEvidencePaths`, existing `pages/page_p*.png`,
     question id, and total question count before declaring the crop missing.
   - Rebuild `crops/questions/q{id}.png` from the recovered full-page image,
     then rerun the visual asset crop stage.
11. Manual fallback visual asset crop for auto-detection failures.
   - If component detection cannot isolate the diagram/graph/table from an
     existing question crop, create a conservative reviewed fallback crop from
     likely lower/right/body regions.
   - Last-resort crops may include more of the question body, but they must
     still be saved under `archive/assets/images/{examTitle}/q{id}.png` and
     marked for contact-sheet review.
12. Visual asset tightening, archive asset promotion, and link audit.
   - Tightening trims whitespace around generated visual assets.
   - Link audit mirrors textbook `07A-visual-asset-link-audit`: JS `image` must
     point to visual assets, not page or full-question crops, when a diagram,
     graph, table, or coordinate plane is required.
   - Archive asset promotion copies generated visual assets to
     `archive/assets/images/{examTitle}/q{id}.png` and rewrites candidate JS
     `image` / `visualAsset` to the same relative path.
13. Extended base-schema JS candidate generation.
14. `image_fallback` candidate JS when text transcription is not available.
15. Extraction-readiness validation for GPT/Gemini handoff.
16. Required validation reports.
17. Continuity queues and compact evidence packs for the next stages.

OCR cleanup, formula repair, solution writing, direct solving, classification,
and final archive promotion are later stages against the same manifest/output
contract. They are not required for the Codex extraction pipeline to finish.

Extraction completion is the hard gate:

- `expectedQuestionCount` must match the number of generated JS question records.
- Every expected `displayNo` must exist exactly once.
- Question records must be ordered by `displayNo` inside each exam JS file.
- Full-page images must be checked first for page spread, question order, and
  missing-question diagnosis.
- Question crops are used only when full-page evidence is too small or a
  formula/figure/choice needs close inspection.
- `crop missing` is not a terminal blocker when the full-page image exists.
- Every question must have a usable `content`/`choices` structure when Codex can
  extract it, or an explicit source-backed image fallback sufficient for
  GPT/Gemini transcription.
- Objective questions must have complete choices when they are visible in the
  crop/full-page source. If choices are unreadable, the item must be queued with
  crop/full-page evidence instead of being filled with placeholders.
- Every question must have `fullPageImagePath` or an equivalent source page
  reference. If the field is missing but a page exists, add the field before
  handoff.
- Visual-needed questions must use `image: "assets/images/{examTitle}/q{id}.png"`
  and the physical file must exist at
  `archive/assets/images/{examTitle}/q{id}.png`.
- Non-visual questions may keep `image` as a question crop or page fallback, but
  all referenced files must exist.
- `solution` may remain empty. `solutionStatus` should indicate external
  solution generation, for example `external_solution_pending`.
- `answer` is filled only from official answer/solution evidence or a validated
  mapping table. Codex does not directly solve by default in this extraction
  pipeline. If answer evidence is missing, keep `answer` empty or explicitly
  mark it in `answer_mapping_queue.json` for GPT/Gemini.

If this gate fails, the next stage is always an extraction repair queue:
`question_order_repair`, `crop_quality_repair`, `visual_asset_repair`, or
`content_choices_transcription_queue`. Do not dispatch solution-writing agents
for that candidate file yet.

Codex extraction is complete when the candidate is `EXTRACTION_READY_FOR_GPT`:

- JS parses with `node --check`.
- All expected questions are registered in display order.
- Full-page images exist for every referenced page.
- Question crops are present and readable, or the full-page fallback is recorded.
- Visual assets are cropped and linked for true figure/graph/table questions.
- No Windows absolute paths leak into `content`, `choices`, `answer`,
  `solution`, or image fields.
- No generated-local visual asset paths remain in JS.
- Handoff reports and compact GPT/Gemini packs are created.

Deprecated answer/solution note: direct solving and student-facing solution
writing are not part of the default Codex extraction completion gate.

Updated rule: package unresolved answers and solutions for GPT/Gemini after
extraction. Official answer/solution files are mapping evidence, not a reason to
delay PDF rendering, crop generation, or JS registration.

- If answer evidence is not available, keep the item in the handoff queue with
  verified content, choices, full-page images, and question crops when needed.
- If a solution is missing, include the solution protocol, candidate JS, and
  solution stage must read `rules/해설프로토콜.md` plus the 발문·보기 extraction
  required crop/full-page/visual assets in the GPT/Gemini handoff pack.
- If the source is unreadable or internally inconsistent, record the unresolved
  status, include the best evidence image, and continue to the next question/PDF.

The rule above supersedes any older direct-solve wording: Codex extraction
handoff packages evidence; GPT/Gemini writes or repairs solutions.

## Non-Stop Status Model

`partial` is not a failed stop. It means the current job produced a safe candidate
and wrote queue files for unresolved work.

Required continuation files:

- `reports/pipeline_continuity_report.json`
- `reports/NEXT_ACTIONS.md`
- `reports/content_transcription_queue.json`
- `reports/answer_mapping_queue.json`
- `reports/extraction_readiness_report.json`
- `reports/gpt_gemini_handoff_manifest.json`

Batch-level continuation files:

- `_batch/batch_progress.json`
- `_batch/subagent_worklist.json`
- `_batch/batch_validation_summary.json`

Current fallback chain:

```text
no text layer / OCR unavailable
→ render PDF pages
→ crop questions
→ review question crop quality and tighten/recrop when possible
→ crop visual assets from figure/graph/table question crops
→ copy visual assets to archive/assets/images/{examTitle}/q{id}.png
→ audit visual asset links
→ create candidate JS with image fallback
→ write content_transcription_queue.json
→ continue batch
```

```text
answer not confidently mapped
→ render answer/solution pages if available
→ keep answerStatus: "missing_answer"
→ write answer_mapping_queue.json
→ continue batch
```

GPT/Gemini handoff fallback:

```text
content, answer, or solution still missing after extraction
??do not direct-solve inside Codex by default
??package candidate JS + referenced question crops + required full-page images
??write solution from 해설프로토콜 when answer is known
??include visual assets from archive/assets/images/{examTitle}/q{id}.png
??write gpt_gemini_handoff_manifest.json
??continue batch
```

Current chain for new exam runs:

```text
problem extracted
??candidate JS registers 100% of expected questions
??full-page fallback exists for every referenced page
??question crops are readable or queued for recrop
??visual assets are cropped and linked where needed
??content/choices extraction gate passes or unresolved items are evidence-packed
??official answers are mapped when evidence exists
??write extraction_readiness_report.json
??write GPT/Gemini handoff pack
??continue batch
```

## Final Review Pipeline

Promotion is blocked until candidates pass the review gates in order. These
review gates run after the GPT/Gemini solution/classification round, not as part
of the Codex extraction completion gate:

```text
1차 구조·무결성 검수
??2차 수학·정오답 검수
??3차 분류·메타·난이도 태그 검수
??최종 무결성 검수
??promotion report
```

Important 2차 rule: objective questions with zero or multiple correct candidates
fail only when the prompt does not explicitly allow multiple answers. If the
prompt says `모두 고르시오`, `옳은 것을 모두`, `정답 2개`, or an equivalent phrase,
multiple correct choices are allowed and the answer must list every correct
choice clearly.

## Batch Continuation Rule

`run-batch.mjs --run-selected` catches each job exception, writes that job as
`fail` or `partial`, updates `_batch/batch_progress.json`, and continues to the
next selected PDF.

This means a selected batch can safely include multiple PDFs. One difficult
exam must not block the rest of the queue.

Subagents should start from `_batch/subagent_worklist.json`. Each item points to:

- the candidate JS;
- `content_transcription_queue.json`;
- `answer_mapping_queue.json`;
- `NEXT_ACTIONS.md`.

Parallel agents must not edit the same candidate JS at the same time. A safe
split is one agent per `examId`, or one content agent and one answer agent only
after their allowed fields are enforced by the queue.

For GPT/Gemini solution agents, allowed edits are limited to `content` minimal
OCR cleanup when image evidence is provided, `choices` minimal OCR cleanup,
`answer` when official evidence or direct solving supports it, `solution`,
solution status, and classification fields allowed by the archive schema. They
must not change `id`, `displayNo`, `cropPath`, `fullPageImagePath`, `image`,
`layoutTag`, or `wide`. If solving reveals a crop/OCR conflict, they should
report it back to the extraction queue instead of inventing problem text.
