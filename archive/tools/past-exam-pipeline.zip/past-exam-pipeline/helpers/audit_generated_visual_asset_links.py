import argparse
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


VISUAL_TERMS = [
    "그림",
    "그래프",
    "도형",
    "표",
    "좌표평면",
    "좌표축",
    "다음 그림",
    "아래 그림",
    "오른쪽 그림",
    "洹몃┝",
    "洹몃옒",
    "醫뚰몴",
    "醫뚰몴?됰㈃",
    "吏곸꽑",
    "?꾪삎",
    "figure",
    "graph",
    "diagram",
    "table",
    "coordinate",
]
VISUAL_RE = re.compile("|".join(re.escape(term) for term in VISUAL_TERMS), re.I)


def now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def extract_question_bank(text):
    match = re.search(r"window\.questionBank\s*=\s*(\[.*?\]);?\s*$", text, re.S)
    if not match:
        raise ValueError("window.questionBank array not found")
    return json.loads(match.group(1))


def visual_needed(question):
    if "no_visual_asset_required" in str(question.get("visualAssetStatus") or ""):
        return False
    combined = "\n".join(
        [
            str(question.get("content") or ""),
            " ".join(str(x) for x in question.get("tags") or []),
            *[str(x) for x in question.get("choices") or []],
        ]
    )
    return bool(VISUAL_RE.search(combined))


def resolve_asset(candidate, rel):
    if not rel:
        return None
    path = Path(str(rel))
    if path.is_absolute():
        return path
    text = str(rel).replace("/", "\\")
    if text.startswith("assets\\images\\"):
        archive_root = candidate.parents[6]
        return archive_root / text
    return candidate.parent.parent / text


def bad_image_path(value):
    text = str(value or "")
    normalized = text.replace("\\", "/")
    if normalized.startswith("assets/images/"):
        return False
    return bool(re.search(r"(pages[/\\]|crops[/\\]questions|page_p\d+|q\d+(?:_figure1)?\.(?:png|jpe?g|webp)$)", text, re.I))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    out = Path(args.out).resolve()
    items = []
    parse_errors = []
    scanned = 0
    for candidate in sorted(root.rglob("*.candidate.js")):
        term = candidate.relative_to(root).parts[0]
        exam_id = candidate.parent.parent.name
        try:
            questions = extract_question_bank(candidate.read_text(encoding="utf-8"))
        except Exception as exc:
            parse_errors.append({"candidateFile": str(candidate), "error": str(exc)})
            continue
        for question in questions:
            scanned += 1
            need = visual_needed(question)
            visual_asset = question.get("visualAsset") or ""
            image = question.get("image") or ""
            statuses = []
            asset_path = resolve_asset(candidate, visual_asset)
            if need and not visual_asset:
                statuses.append("visual_asset_required_missing")
            if visual_asset and (not asset_path or not asset_path.exists()):
                statuses.append("visual_asset_file_missing")
            if need and image and bad_image_path(image):
                statuses.append("image_points_to_page_or_question_crop")
            if visual_asset and image and image != visual_asset:
                statuses.append("image_not_visual_asset")
            if not statuses:
                continue
            items.append(
                {
                    "term": term,
                    "examId": exam_id,
                    "candidateFile": str(candidate),
                    "id": question.get("id"),
                    "displayNo": question.get("displayNo"),
                    "needsVisual": need,
                    "image": image,
                    "visualAsset": visual_asset,
                    "resolvedVisualAsset": str(asset_path) if asset_path else "",
                    "statuses": statuses,
                    "status": statuses[0],
                }
            )
    counts = Counter()
    by_term = defaultdict(Counter)
    for item in items:
        for status in item["statuses"]:
            counts[status] += 1
            by_term[item["term"]][status] += 1
    report = {
        "stage": "past-exam-visual-asset-link-audit",
        "generatedAt": now_iso(),
        "root": str(root),
        "scannedQuestions": scanned,
        "parseErrors": parse_errors,
        "itemCount": len(items),
        "byStatus": dict(counts),
        "byTerm": {term: dict(counts) for term, counts in sorted(by_term.items())},
        "items": items,
        "status": "ok" if not items and not parse_errors else "manual_review",
    }
    write_json(out, report)
    print(json.dumps({k: report[k] for k in ["scannedQuestions", "itemCount", "byStatus", "byTerm", "status"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
