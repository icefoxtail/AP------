/**
 * AP Math OS 1.0 [js/dashboard.js]
 * 운영센터 및 선생님별 대시보드 엔진
 * [Dashboard Polish]: 52px 카드 높이 통일, 상단 바로가기 탭형 배치, 오늘일지 제목 외부 배치
 * [Schedule/Memo]: 오늘일정·주간일정 관리 버튼 제거, 일정 행 52px 규격 통일
 * [Class Filter]: 학급관리 전체/중등/고등 탭 필터 유지
 * [Stability]: 공휴일/휴무일 감지, Safari 안전 날짜 파싱, 교사별 표시 범위 유지
 */

function copyPhoneNumber(text) {
    const value = String(text || '').trim();
    if (!value) return;

    const showCopied = () => toast('전화번호가 복사되었습니다.', 'info');
    const showCopyFailed = (err) => {
        console.warn('[AP Math OS] phone copy failed:', err);
        toast('복사 실패', 'warn');
    };
    const fallbackCopy = () => {
        const textarea = document.createElement('textarea');
        textarea.value = value;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '0';
        document.body.appendChild(textarea);
        textarea.select();

        let copied = false;
        try {
            copied = document.execCommand('copy');
        } catch (err) {
            document.body.removeChild(textarea);
            showCopyFailed(err);
            return;
        }

        document.body.removeChild(textarea);
        if (copied) showCopied();
        else showCopyFailed(new Error('fallback copy returned false'));
    };

    if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(value).then(showCopied).catch(fallbackCopy);
    } else {
        fallbackCopy();
    }
}

function apEscapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function apParseLocalDateTime(value) {
    const str = String(value || '').trim();
    if (!str) return null;

    const datePart = str.split('T')[0].split(' ')[0];
    const parts = datePart.split('-').map(Number);

    if (parts.length !== 3) return null;

    const [y, m, d] = parts;
    if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;

    const time = new Date(y, m - 1, d).getTime();
    return Number.isFinite(time) ? time : null;
}

function apFormatMonthDay(value) {
    const str = String(value || '').trim();
    const datePart = str.split('T')[0].split(' ')[0];
    const parts = datePart.split('-').map(Number);

    if (parts.length !== 3) return '';

    const [, m, d] = parts;
    if (!Number.isFinite(m) || !Number.isFinite(d)) return '';

    return `${m}월 ${d}일`;
}

const DASH_HOLIDAYS = [
    '2026-01-01', '2026-02-16', '2026-02-17', '2026-02-18', '2026-03-01', '2026-03-02',
    '2026-05-01', '2026-05-05', '2026-05-24', '2026-05-25', '2026-06-06', '2026-07-17',
    '2026-08-15', '2026-08-17', '2026-09-24', '2026-09-25', '2026-09-26', '2026-10-03',
    '2026-10-05', '2026-10-09', '2026-12-25'
];

function isDashboardHoliday(dateStr) {
    if (DASH_HOLIDAYS.includes(dateStr)) return true;
    if (state.db.academy_schedules) {
        return state.db.academy_schedules.some(s =>
            String(s.is_deleted || 0) !== '1' &&
            s.schedule_date === dateStr &&
            s.schedule_type === 'closed' &&
            s.target_scope !== 'student'
        );
    }
    return false;
}

function isClassScheduledTodayForDashboard(cid) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const cls = state.db.classes.find(c => String(c.id) === String(cid));
    if (!cls) return false;

    const cIds = state.db.class_students
        .filter(m => String(m.class_id) === String(cid))
        .map(m => String(m.student_id));
    const hasActiveAttendance = state.db.attendance.some(
        a => a.date === todayStr && cIds.includes(String(a.student_id)) && a.status === '등원'
    );
    if (hasActiveAttendance) return true;

    if (isDashboardHoliday(todayStr)) return false;

    if (!cls.schedule_days) return true;
    const today = new Date().getDay();
    return String(cls.schedule_days).split(',').map(d => d.trim()).includes(String(today));
}

function isMiddleSchoolClass(c) {
    const gradeText = String(c?.grade || '');
    const nameText = String(c?.name || '');

    if (
        gradeText.startsWith('고') ||
        nameText.startsWith('고') ||
        nameText.includes('고1') ||
        nameText.includes('고2') ||
        nameText.includes('고3') ||
        nameText.includes('고등')
    ) return false;

    return true;
}

function isClassVisibleForCurrentTeacher(c) {
    if (!c) return false;

    if (state?.auth?.role === 'admin') return true;
    if (state?.ui?.viewScope === 'all') return true;

    const currentTeacher = typeof getTeacherNameForUI === 'function'
        ? getTeacherNameForUI()
        : (state?.ui?.userName || state?.auth?.name || '');

    const normalizedCurrent = String(currentTeacher || '')
        .replace(/\s*선생님\s*$/g, '')
        .trim();

    const normalizedClassTeacher = String(c.teacher_name || '')
        .replace(/\s*선생님\s*$/g, '')
        .trim();

    if (!normalizedClassTeacher) return true;

    return normalizedClassTeacher === normalizedCurrent;
}

// [5G] 관리필요(구 위험학생) 판정 알고리즘

// [Dashboard Ops] 일지 대상일·퇴근 마감·집중케어 공통 유틸
const DASHBOARD_JOURNAL_BASE_DAYS = ['wed', 'thu'];
const DASHBOARD_DAY_ORDER = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const DASHBOARD_DAY_LABELS = { sun: '일', mon: '월', tue: '화', wed: '수', thu: '목', fri: '금', sat: '토' };
const DASHBOARD_DAY_INDEX_TO_KEY = { 0: 'sun', 1: 'mon', 2: 'tue', 3: 'wed', 4: 'thu', 5: 'fri', 6: 'sat', 7: 'sun' };

function dashboardEscapeAttr(value) {
    const jsSafe = String(value || '')
        .replace(/\\/g, '\\\\')
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n')
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')
        .replace(/'/g, "\\'");
    return jsSafe
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function dashboardDateFromLocalString(dateStr) {
    const parts = String(dateStr || '').split('-').map(Number);
    if (parts.length !== 3 || parts.some(v => !Number.isFinite(v))) return null;
    return new Date(parts[0], parts[1] - 1, parts[2]);
}

function dashboardDateStringFromDate(date) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    return date.toLocaleDateString('sv-SE');
}

function dashboardGetWeekDates(baseDateStr) {
    const base = dashboardDateFromLocalString(baseDateStr || new Date().toLocaleDateString('sv-SE')) || new Date();
    const start = new Date(base.getFullYear(), base.getMonth(), base.getDate());
    start.setDate(start.getDate() - start.getDay());
    return DASHBOARD_DAY_ORDER.map((key, idx) => {
        const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + idx);
        return { key, label: DASHBOARD_DAY_LABELS[key], date: dashboardDateStringFromDate(d), dayIndex: idx };
    });
}

function dashboardNormalizeTeacherName(name) {
    return String(name || '').replace(/\s*선생님\s*$/g, '').trim();
}

function dashboardAddDayKey(list, key) {
    const normalized = String(key || '').trim();
    if (DASHBOARD_DAY_ORDER.includes(normalized) && !list.includes(normalized)) list.push(normalized);
}

function dashboardParseDayKeysFromText(value) {
    const source = String(value || '').trim();
    const days = [];
    if (!source) return days;

    const tokenMap = {
        '0': 'sun', '1': 'mon', '2': 'tue', '3': 'wed', '4': 'thu', '5': 'fri', '6': 'sat', '7': 'sun',
        sun: 'sun', sunday: 'sun', su: 'sun', 일: 'sun', 일요일: 'sun',
        mon: 'mon', monday: 'mon', m: 'mon', 월: 'mon', 월요일: 'mon',
        tue: 'tue', tuesday: 'tue', tu: 'tue', 화: 'tue', 화요일: 'tue',
        wed: 'wed', wednesday: 'wed', w: 'wed', 수: 'wed', 수요일: 'wed',
        thu: 'thu', thursday: 'thu', th: 'thu', 목: 'thu', 목요일: 'thu',
        fri: 'fri', friday: 'fri', f: 'fri', 금: 'fri', 금요일: 'fri',
        sat: 'sat', saturday: 'sat', sa: 'sat', 토: 'sat', 토요일: 'sat'
    };

    const groupMap = {
        mwf: ['mon', 'wed', 'fri'],
        mtwthf: ['mon', 'tue', 'wed', 'thu', 'fri'],
        weekday: ['mon', 'tue', 'wed', 'thu', 'fri'],
        weekdays: ['mon', 'tue', 'wed', 'thu', 'fri'],
        ttf: ['tue', 'thu', 'fri'],
        tt: ['tue', 'thu'],
        weekend: ['sat', 'sun']
    };

    const compact = source.toLowerCase().replace(/\s+/g, '');
    if (groupMap[compact]) return [...groupMap[compact]];

    source.split(/[,/|·\s]+/).map(v => v.trim()).filter(Boolean).forEach(token => {
        const lower = token.toLowerCase();
        if (groupMap[lower]) groupMap[lower].forEach(day => dashboardAddDayKey(days, day));
        else dashboardAddDayKey(days, tokenMap[lower] || tokenMap[token]);
    });

    for (const ch of source) dashboardAddDayKey(days, tokenMap[ch]);
    return days;
}

function dashboardGetClassDayKeys(cls) {
    const days = [];
    dashboardParseDayKeysFromText(cls?.schedule_days).forEach(day => dashboardAddDayKey(days, day));
    dashboardParseDayKeysFromText(cls?.day_group).forEach(day => dashboardAddDayKey(days, day));
    dashboardParseDayKeysFromText(cls?.time_label).forEach(day => dashboardAddDayKey(days, day));
    return DASHBOARD_DAY_ORDER.filter(day => days.includes(day));
}

function dashboardGetTeacherClasses(teacherName = '') {
    const classes = state?.db?.classes || [];
    const target = dashboardNormalizeTeacherName(teacherName || state?.ui?.userName || state?.auth?.name || '');
    return classes.filter(c => {
        if (Number(c?.is_active) === 0) return false;
        if (!target) return isClassVisibleForCurrentTeacher(c);
        const classTeacher = dashboardNormalizeTeacherName(c?.teacher_name || '');
        return classTeacher === target;
    });
}

function dashboardGetJournalTargetDayKeys(teacherName = '', classRows = null) {
    // AP Math 운영 기준: 대시보드 일지 확인은 수/목 2일만 본다.
    // 실제 수업 요일 예외를 섞으면 선생님 현황 카드가 다시 경고판처럼 복잡해지므로 추가하지 않는다.
    return DASHBOARD_DAY_ORDER.filter(day => DASHBOARD_JOURNAL_BASE_DAYS.includes(day));
}

function dashboardFindJournal(dateStr, teacherName = '') {
    const targetTeacher = dashboardNormalizeTeacherName(teacherName || state?.ui?.userName || state?.auth?.name || '');
    return (state?.db?.journals || []).find(j => {
        const sameDate = String(j?.date || '') === String(dateStr || '');
        if (!sameDate) return false;
        if (!targetTeacher) return true;
        return dashboardNormalizeTeacherName(j?.teacher_name || '') === targetTeacher;
    });
}

function dashboardIsJournalDone(journal) {
    const status = String(journal?.status || '').trim();
    if (!journal) return false;
    return status === '제출완료' || status === '결재완료' || !!String(journal?.content || '').trim();
}

function openDashboardArchiveWindow(event) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
    const url = '../archive/index';
    window.open(url, '_blank', 'noopener');
}

function renderDashboardJournalWeekMatrix(teacherName = '', baseDateStr = null, classRows = null) {
    injectDashboardOpsStyles();
    const week = dashboardGetWeekDates(baseDateStr || new Date().toLocaleDateString('sv-SE'));
    const targetDays = dashboardGetJournalTargetDayKeys(teacherName, classRows);
    const safeTeacher = dashboardEscapeAttr(teacherName || state?.ui?.userName || '');
    const cells = week
        .filter(day => targetDays.includes(day.key))
        .filter(day => !isDashboardHoliday(day.date))
        .map(day => {
            const journal = dashboardFindJournal(day.date, teacherName);
            const done = dashboardIsJournalDone(journal);
            const statusText = done ? '제출완료' : '미작성';
            const click = teacherName
                ? `renderAdminJournalList('${day.date}', '${safeTeacher}')`
                : `openDailyJournalModal('${day.date}')`;
            const labelText = `${day.label} ${apFormatMonthDay(day.date) || day.date}`;
            const ariaText = `${labelText} ${statusText} 일지 열기`;
            return `
                <button class="journal-day-cell journal-day-cell--${done ? 'done' : 'missing'}" onclick="event.stopPropagation(); ${click}" type="button" aria-label="${apEscapeHtml(ariaText)}">
                    <span class="journal-day-cell__label">${apEscapeHtml(labelText)}</span>
                    <span class="journal-day-cell__spacer" aria-hidden="true"></span>
                    <span class="journal-day-cell__status">${apEscapeHtml(statusText)}</span>
                    <span class="journal-day-cell__chevron" aria-hidden="true">›</span>
                </button>
            `;
        }).join('');

    if (!cells.trim()) {
        return `<div class="journal-matrix journal-matrix--empty"><span class="journal-matrix__empty">이번 주 작성 대상일이 없습니다.</span></div>`;
    }
    return `<div class="journal-matrix" data-teacher="${apEscapeHtml(teacherName || '')}">${cells}</div>`;
}

function dashboardGetStudentClassInfo(studentId) {
    const classStudents = state?.db?.class_students || [];
    const classes = state?.db?.classes || [];
    const map = classStudents.find(m => String(m?.student_id) === String(studentId));
    const cls = classes.find(c => String(c?.id) === String(map?.class_id || '')) || null;
    return { classId: map?.class_id || '', className: cls?.name || '미배정', cls };
}

function dashboardGroupByClass(items) {
    return (items || []).reduce((acc, item) => {
        const key = item?.className || '미배정';
        if (!acc[key]) acc[key] = [];
        acc[key].push(item);
        return acc;
    }, {});
}

function dashboardHasMakeupAfter(studentId, dateStr) {
    const sid = String(studentId || '');
    const start = String(dateStr || '').slice(0, 10);
    if (!sid || !start) return false;

    const hasAttendanceMakeup = (state?.db?.attendance_history || state?.db?.attendance || []).some(a => {
        if (String(a?.student_id || '') !== sid) return false;
        const date = String(a?.date || '').slice(0, 10);
        if (!date || date < start) return false;
        const hay = `${a?.status || ''} ${a?.tags || ''} ${a?.memo || ''}`;
        return hay.includes('보강');
    });
    if (hasAttendanceMakeup) return true;

    return (state?.db?.academy_schedules || []).some(s => {
        if (String(s?.is_deleted || 0) === '1') return false;
        if (String(s?.student_id || '') !== sid) return false;
        const date = String(s?.schedule_date || '').slice(0, 10);
        if (!date || date < start) return false;
        const hay = `${s?.schedule_type || ''} ${s?.title || ''} ${s?.memo || ''}`;
        return hay.includes('보강') || /makeup/i.test(hay);
    });
}

function dashboardHasConsultationAfter(studentId, dateStr) {
    const sid = String(studentId || '');
    const start = String(dateStr || '').slice(0, 10);
    if (!sid || !start) return false;
    return (state?.db?.consultations || []).some(c => {
        if (String(c?.student_id || '') !== sid) return false;
        const date = String(c?.date || c?.consultation_date || c?.created_at || '').slice(0, 10);
        return !!date && date >= start;
    });
}

function dashboardGetClassProgressRecord(classId, dateStr) {
    return (state?.db?.class_daily_records || []).find(r => String(r?.class_id || '') === String(classId) && String(r?.date || '') === String(dateStr));
}

function dashboardGetScheduledClassesForDate(dateStr, teacherName = '') {
    const dateObj = dashboardDateFromLocalString(dateStr);
    const dayKey = dateObj ? DASHBOARD_DAY_INDEX_TO_KEY[dateObj.getDay()] : '';
    const dayIdx = dateObj ? String(dateObj.getDay()) : '';
    const targetTeacher = dashboardNormalizeTeacherName(teacherName || state?.ui?.userName || state?.auth?.name || '');
    return (state?.db?.classes || []).filter(cls => {
        if (Number(cls?.is_active) === 0) return false;
        if (!isClassVisibleForCurrentTeacher(cls) && !targetTeacher) return false;
        if (targetTeacher && dashboardNormalizeTeacherName(cls?.teacher_name || '') !== targetTeacher) return false;
        const keys = dashboardGetClassDayKeys(cls);
        if (keys.length) return keys.includes(dayKey);
        if (cls?.schedule_days) return String(cls.schedule_days).split(',').map(v => v.trim()).includes(dayIdx);
        return false;
    });
}

function renderJournalDraftPreview(dateStr) {
    return `
        <div class="journal-draft journal-draft--simple">
            <pre class="journal-draft__plain">${apEscapeHtml(buildJournalContent(dateStr))}</pre>
        </div>
    `;
}

function injectDashboardOpsStyles() {
    if (typeof document === 'undefined') return;
    if (document.getElementById('dashboard-foundation-css')) return;
    if (document.querySelector('link[href$="dashboard-foundation.css"]')) return;

    const link = document.createElement('link');
    link.id = 'dashboard-foundation-css';
    link.rel = 'stylesheet';
    link.href = './css/dashboard-foundation.css';
    document.head.appendChild(link);
}

function computeRiskStudents() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr);
    if (todayTime === null) return [];

    const active = (state?.db?.students || []).filter(s => String(s?.status || '') === '재원');
    const attendanceHistory = state?.db?.attendance_history || [];
    const homeworkHistory = state?.db?.homework_history || [];
    const consultations = state?.db?.consultations || [];
    const classStudents = state?.db?.class_students || [];
    const classes = state?.db?.classes || [];

    const classById = typeof apmsGetDataIndexes === 'function'
        ? apmsGetDataIndexes().classesById
        : new Map(classes.map(c => [String(c.id), c]));
    const classMapByStudentId = typeof apmsGetDataIndexes === 'function'
        ? apmsGetDataIndexes().classStudentByStudentId
        : new Map(classStudents.map(m => [String(m.student_id), m]));

    const LOOKBACK_DAYS = 14;
    const cutoffTime = todayTime - (LOOKBACK_DAYS - 1) * 24 * 60 * 60 * 1000;
    const recentAlertCutoff = todayTime - 3 * 24 * 60 * 60 * 1000;

    const countMapByStudent = (rows, matcher) => {
        const map = new Map();
        rows.forEach(row => {
            const sid = String(row?.student_id || '');
            if (!sid || !matcher(row)) return;
            const t = apParseLocalDateTime(row.date || row.created_at || row.updated_at);
            if (t === null || t < cutoffTime || t > todayTime) return;
            const cur = map.get(sid) || { count: 0, recent: 0 };
            cur.count += 1;
            if (t >= recentAlertCutoff) cur.recent += 1;
            map.set(sid, cur);
        });
        return map;
    };

    const absenceMap = countMapByStudent(attendanceHistory, row => String(row?.status || '').trim() === '결석');
    const homeworkMissMap = countMapByStudent(homeworkHistory, row => String(row?.status || '').trim() === '미완료');
    const makeupMap = countMapByStudent(attendanceHistory, row => {
        const hay = `${row?.status || ''} ${row?.tags || ''} ${row?.memo || ''}`;
        return hay.includes('보강');
    });

    const consultationMap = new Map();
    consultations.forEach(row => {
        const sid = String(row?.student_id || '');
        if (!sid) return;
        const dateText = String(row?.date || row?.consultation_date || row?.created_at || '').slice(0, 10);
        const t = apParseLocalDateTime(dateText);
        if (t === null || t < cutoffTime || t > todayTime) return;
        const cur = consultationMap.get(sid) || { count: 0, recent: 0 };
        cur.count += 1;
        if (t >= recentAlertCutoff) cur.recent += 1;
        consultationMap.set(sid, cur);
    });

    const risks = [];
    const clearedCareLogs = [];

    active.forEach(s => {
        const sid = String(s?.id || '');
        if (!sid) return;

        const absences = absenceMap.get(sid) || { count: 0, recent: 0 };
        const hwMisses = homeworkMissMap.get(sid) || { count: 0, recent: 0 };
        const makeups = makeupMap.get(sid) || { count: 0, recent: 0 };
        const studentConsults = consultationMap.get(sid) || { count: 0, recent: 0 };

        const baseReasons = [];
        const offsetReasons = [];
        let internalScore = 50;

        if (absences.count > 0) {
            internalScore += absences.count * 20;
            baseReasons.push(`최근 14일 결석 ${absences.count}회`);
        }
        if (hwMisses.count > 0) {
            internalScore += hwMisses.count * 10;
            baseReasons.push(`최근 14일 숙제 미완료 ${hwMisses.count}회`);
        }

        const beforeOffsetScore = internalScore;

        if (makeups.count > 0) {
            internalScore -= makeups.count * 20;
            offsetReasons.push(`보강 ${makeups.count}회`);
        }
        if (studentConsults.count > 0) {
            internalScore -= studentConsults.count * 30;
            offsetReasons.push(`상담 ${studentConsults.count}회`);
        }

        internalScore = Math.max(50, Math.min(150, internalScore));
        const displayScore = internalScore - 50;

        if (!baseReasons.length) return;

        const cId = classMapByStudentId.get(sid)?.class_id;
        const cName = classById.get(String(cId || ''))?.name || '미배정';
        const recentNegative = absences.recent + hwMisses.recent;
        const recentPositive = makeups.recent + studentConsults.recent;
        let trend = '▬';
        if (recentNegative > recentPositive) trend = '▲';
        else if (recentPositive > recentNegative) trend = '▼';

        if (displayScore <= 0) {
            clearedCareLogs.push({
                student_id: sid,
                student_name: s.name || '',
                class_name: cName,
                base_reasons: baseReasons,
                offset_reasons: offsetReasons,
                internal_score_before_offset: beforeOffsetScore,
                internal_score_after_offset: internalScore,
                display_score_after_offset: displayScore,
                cleared_at: new Date().toISOString(),
                summary: `${s.name || '학생'}: ${baseReasons.join(' · ')} → ${offsetReasons.join(' · ') || '후속 조치'}로 해소`
            });
            return;
        }

        const riskTypes = ['집중케어'];
        if (absences.count > 0) riskTypes.push('출결주의');
        if (hwMisses.count > 0) riskTypes.push('숙제주의');

        risks.push({
            student: s,
            className: cName,
            riskTypes: [...new Set(riskTypes)],
            reasons: [`${baseReasons.join(' · ')}${offsetReasons.length ? ` / 상쇄: ${offsetReasons.join(' · ')}` : ''} (위험지수: ${displayScore}점)`],
            scoreSummary: '',
            absenceCount: absences.count,
            hwMissCount: hwMisses.count,
            riskScore: displayScore,
            trend,
            offsetReasons
        });
    });

    if (!state.dashboard) state.dashboard = {};
    state.dashboard.clearedCareLogs = clearedCareLogs;
    state.dashboardClearedCareLogs = clearedCareLogs;

    return risks.sort((a, b) => Number(b.riskScore || 0) - Number(a.riskScore || 0));
}


// [Final Fix] 관리 메뉴 퇴원생 버튼과 연동
function openDischargedStudents() {
    openAdminStudentList('discharged');
}

function openRiskStudentReport(studentId) {
    const risks = typeof computeRiskStudents === 'function' ? computeRiskStudents() : [];
    const risk = risks.find(r => String(r.student?.id) === String(studentId));
    if (typeof openStudentReportModal === 'function') {
        openStudentReportModal(studentId, { riskInfo: risk || null, title: '관리필요 학생 문구 생성' });
        return;
    }
    toast('보고 문구 모듈을 불러오지 못했습니다.', 'warn');
}

async function restoreDischargedStudent(sid) {
    if (!confirm('이 학생을 재원으로 복구하시겠습니까?')) return;
    const r = await api.patch(`students/${sid}/restore`, {});
    if (r?.success) { await loadData(); openAdminStudentList('discharged'); }
    else toast(r?.message || r?.error || '복구에 실패했습니다.', 'error');
}

async function hideDischargedStudent(sid) {
    if (!confirm('퇴원생 목록에서 숨길까요?')) return;
    const r = await api.patch(`students/${sid}/hide`, {});
    if (r?.success) { await loadData(); openAdminStudentList('discharged'); }
    else toast(r?.message || r?.error || '목록숨김 처리에 실패했습니다.', 'error');
}

async function purgeHiddenStudent(sid) {
    if (!sid) return;
    const first = confirm('이 숨김 학생을 DB에서 완전 삭제할까요?');
    if (!first) return;
    const second = confirm('완전 삭제는 중복 생성된 학생 정리용입니다. 삭제 후 복구할 수 없습니다. 계속할까요?');
    if (!second) return;
    const r = await api.delete('students', `${sid}/purge`);
    if (r?.success) {
        toast('숨김 학생이 완전 삭제되었습니다.', 'info');
        await loadData();
        openAdminStudentList('hidden');
        return;
    }
    toast(r?.message || r?.error || '완전 삭제에 실패했습니다.', 'error');
}

function openAdminStudentList(type) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr);
    let list = [], title = "";

    if (type === 'active') { 
        list = state.db.students.filter(s => adminNormalizeStatus(s.status) === '재원'); 
        title = "재원생 목록"; 
    } else if (type === 'new') { 
        list = state.db.students.filter(s => { 
            if (adminNormalizeStatus(s.status) !== '재원' || !s.created_at || todayTime === null) return false; 
            const createdTime = apParseLocalDateTime(s.created_at);
            if (createdTime === null) return false;
            return (todayTime - createdTime) / (1000*3600*24) <= 14;
        }); 
        title = "최근 등록 원생"; 
    } else if (type === 'discharged') { 
        list = state.db.students.filter(s => adminNormalizeStatus(s.status) === '제적'); 
        title = "퇴원생 목록"; 
    } else if (type === 'hidden') {
        list = state.db.students.filter(s => adminNormalizeStatus(s.status) === '숨김');
        title = "숨김 학생";
    } else if (type === 'risk') { 
        list = computeRiskStudents().map(r => ({ ...r.student, riskInfo: r })); 
        title = "관리필요 학생"; 
    }

    const rows = list.map(s => {
        const cId = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const cName = state.db.classes.find(c => c.id === cId)?.name || '미배정';
        let riskDetails = "";
        if (s.riskInfo) { riskDetails = `<div style="font-size:11px; color:var(--error); margin-top:6px; background:rgba(var(--error-rgb),0.10); padding:6px 8px; border-radius:6px; font-weight:600;">상태: ${s.riskInfo.riskTypes.join(', ')} <span style="opacity:0.7; font-weight:normal;">(${s.riskInfo.reasons.join(' · ')})</span></div>`; }
        const actionButtons = type === 'hidden'
            ? `
                <div style="display:flex; gap:6px; justify-content:flex-end; flex-wrap:wrap;">
                    <button class="btn btn-primary" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; box-shadow:none; cursor:pointer;" onclick="restoreDischargedStudent('${s.id}')">복구</button>
                    <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; color:var(--error); background:rgba(var(--error-rgb),0.08); border:1px solid rgba(var(--error-rgb),0.16); cursor:pointer;" onclick="purgeHiddenStudent('${s.id}')">완전 삭제</button>
                </div>
            `
            : type === 'discharged'
            ? `
                <div style="display:flex; gap:6px; justify-content:flex-end; flex-wrap:wrap;">
                    <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); border:none; cursor:pointer;" onclick="closeModal(); renderStudentDetail('${s.id}')">상세 보기</button>
                    <button class="btn btn-primary" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; box-shadow:none; cursor:pointer;" onclick="restoreDischargedStudent('${s.id}')">복구</button>
                    <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); color:var(--secondary); border:1px solid var(--border); cursor:pointer;" onclick="hideDischargedStudent('${s.id}')">목록숨김</button>
                </div>
            `
            : `<button class="btn" style="padding:8px 12px; font-size:12px; font-weight:500; border-radius:8px; background:var(--surface-2); border:none;" onclick="closeModal(); renderStudentDetail('${s.id}')">상세 보기</button>`;
        return `
            <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--surface);">
                <div style="flex:1; padding-right:12px;">
                    <div style="font-weight:500; font-size:14px; color:var(--text);">${apEscapeHtml(s.name)} <span style="font-size:12px; color:var(--secondary); font-weight:400; margin-left:4px;">${apEscapeHtml(s.school_name || '')} ${apEscapeHtml(s.grade || '')}</span></div>
                    <div style="font-size:12px; color:var(--primary); font-weight:500; margin-top:4px;">${apEscapeHtml(cName)} <span style="color:var(--secondary); font-weight:500;">| ${apEscapeHtml(s.status)} ${s.created_at ? `| 등록: ${s.created_at.split(' ')[0]}` : ''}</span></div>
                    ${riskDetails}
                </div>
                ${actionButtons}
            </div>
        `;
    }).join('');

    const hiddenSwitch = (type === 'discharged' || type === 'hidden') ? `
        <div style="display:flex; gap:8px; margin:-4px -4px 12px;">
            <button class="btn ${type === 'discharged' ? 'btn-primary' : ''}" style="flex:1; min-height:38px; font-size:12px; font-weight:500; border-radius:12px;" onclick="openAdminStudentList('discharged')">퇴원생</button>
            <button class="btn ${type === 'hidden' ? 'btn-primary' : ''}" style="flex:1; min-height:38px; font-size:12px; font-weight:500; border-radius:12px;" onclick="openAdminStudentList('hidden')">숨김 학생</button>
        </div>
    ` : '';
    const gradeSummary = (type === 'discharged' || type === 'active' || type === 'new') ? adminRenderStudentGradeSummary(list) : '';
    showModal(`${title} (${list.length}명)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${hiddenSwitch}${gradeSummary}${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:400;">조회 대상이 없습니다.</div>`}</div>`);
}


function openAdminOperationMenu() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const isAdmin = String(state?.auth?.role || '') === 'admin';
    const showBillingAccountingFoundationEntry = false;
    const cardStyle = 'padding:16px; border:1px solid var(--border); border-radius:16px; background:var(--surface); text-align:left; cursor:pointer; box-shadow:none; min-height:92px; align-items:flex-start; justify-content:flex-start; flex-direction:column; gap:6px;';
    const titleStyle = 'font-size:14px; font-weight:500; color:var(--text); line-height:1.35;';
    const descStyle = 'font-size:12px; font-weight:500; color:var(--secondary); line-height:1.5; margin-top:4px;';

    showModal('관리', `
        <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
            <button class="btn" style="${cardStyle}" onclick="openAdminTeacherAccountManage()">
                <div style="${titleStyle}">선생님 계정</div>
                <div style="${descStyle}">선생님 계정 생성, 권한 수정, 비밀번호 초기화</div>
            </button>
            <button class="btn" style="${cardStyle}" onclick="renderAdminJournalList('${todayStr}')">
                <div style="${titleStyle}">일지 확인</div>
                <div style="${descStyle}">제출된 일지를 날짜별로 확인하고 피드백 작성</div>
            </button>
            <button class="btn" style="${cardStyle}" onclick="openAdminStudentList('discharged')">
                <div style="${titleStyle}">퇴원생 관리</div>
                <div style="${descStyle}">퇴원/숨김 학생 조회, 복구, 중복 생성 정리</div>
            </button>
            ${isAdmin && showBillingAccountingFoundationEntry ? `
            <button class="btn" style="${cardStyle}" onclick="if(typeof openBillingAccountingFoundationModal==='function') openBillingAccountingFoundationModal(); else toast('수납·출납 foundation 화면을 불러오지 못했습니다.', 'warn');">
                <div style="${titleStyle}">수납·출납 foundation</div>
                <div style="${descStyle}">결제수단, 수납 정책, 요약, 조회 목록 확인</div>
            </button>
            ` : ''}
        </div>
        <div class="ap-soft-note" style="margin-top:14px; padding:12px 14px;">
            반 담당 변경과 담임 일괄 변경은 Worker 구조분리 이후 별도 연결합니다.
        </div>
    `);
}

function openAdminPinBatchModal() {
    const activeStudents = (state.db.students || []).filter(s => String(s.status || '재원') === '재원');
    const missingPins = activeStudents.filter(s => !String(s.student_pin || '').trim());

    const gradeOrder = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const gradeCounts = gradeOrder
        .map(grade => {
            const total = activeStudents.filter(s => String(s.grade || '').includes(grade)).length;
            const missing = missingPins.filter(s => String(s.grade || '').includes(grade)).length;
            return { grade, total, missing };
        })
        .filter(row => row.total > 0 || row.missing > 0);

    const gradeHtml = gradeCounts.map(row => `
        <div style="display:flex; justify-content:space-between; align-items:center; min-height:32px; padding:6px 0; border-bottom:1px solid var(--border);">
            <span style="font-size:13px; font-weight:500; color:var(--text);">${apEscapeHtml(row.grade)}</span>
            <span style="font-size:12px; font-weight:500; color:var(--secondary);">미발급 ${row.missing}명 / 재원 ${row.total}명</span>
        </div>
    `).join('');

    showModal('PIN 생성', `
        <div style="display:flex; flex-direction:column; gap:14px;">
            <div class="ap-soft-note" style="padding:12px 14px;">
                PIN 없는 재원생에게만 학년 규칙에 맞춰 번호를 부여합니다. 기존 PIN은 바뀌지 않습니다.
            </div>

            <div style="border:1px solid var(--border); border-radius:16px; background:var(--surface); padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-end; gap:10px; margin-bottom:10px;">
                    <div>
                        <div style="font-size:13px; font-weight:500; color:var(--text); line-height:1.35;">미발급 PIN</div>
                        <div style="font-size:12px; font-weight:500; color:var(--secondary); line-height:1.45; margin-top:2px;">대상 ${missingPins.length}명 / 재원 ${activeStudents.length}명</div>
                    </div>
                    <div style="font-size:20px; font-weight:500; color:var(--primary); line-height:1;">${missingPins.length}</div>
                </div>
                <button class="btn btn-primary" style="width:100%; min-height:52px; border-radius:14px; font-size:14px; font-weight:500; box-shadow:none;" onclick="handleAdminBatchGeneratePins()" ${missingPins.length ? '' : 'disabled'}>
                    미발급 PIN 생성
                </button>
            </div>

            <div style="border:1px solid var(--border); border-radius:16px; background:var(--surface); padding:12px 14px;">
                <div style="font-size:12px; font-weight:500; color:var(--secondary); margin-bottom:6px;">학년별 현황</div>
                ${gradeHtml || `<div style="font-size:13px; color:var(--secondary); font-weight:500; text-align:center; padding:16px 0;">재원생 정보가 없습니다.</div>`}
            </div>
        </div>
    `);
}

function getAdminClassGradeRank(cls) {
    const text = `${cls?.grade || ''} ${cls?.name || ''}`;
    const order = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const idx = order.findIndex(g => text.includes(g));
    return idx === -1 ? order.length : idx;
}

async function handleAdminBatchGeneratePins() {
    const activeStudents = (state.db.students || []).filter(s => String(s.status || '재원') === '재원');
    const missingPins = activeStudents.filter(s => !String(s.student_pin || '').trim());

    if (!missingPins.length) {
        toast('PIN 미발급 학생이 없습니다.', 'info');
        return;
    }

    if (!confirm(`PIN 없는 학생 ${missingPins.length}명에게 번호를 생성할까요?\n기존 PIN은 바뀌지 않습니다.`)) return;

    try {
        const r = await api.post('students/batch-pins', {});
        if (r?.success) {
            toast(`PIN ${r.count || 0}개 생성 완료`, 'success');
            await loadData();
            openAdminPinBatchModal();
            return;
        }
        toast(r?.message || r?.error || 'PIN 생성에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminBatchGeneratePins] failed:', e);
        toast('PIN 생성 중 오류가 발생했습니다.', 'error');
    }
}

function getAdminTeacherRows() {
    return Array.isArray(state?.ui?.adminTeacherRows) ? state.ui.adminTeacherRows : [];
}

function adminTeacherRoleLabel(role) {
    return String(role || '') === 'admin' ? '원장' : '선생님';
}

async function openAdminTeacherAccountManage() {
    showModal('선생님 계정', `<div style="text-align:center; padding:36px; color:var(--secondary); font-size:13px; font-weight:500;">선생님 계정을 불러오는 중입니다.</div>`);

    try {
        const data = await api.get('teachers');
        if (data?.error) return toast(data.error || '선생님 계정을 불러오지 못했습니다.', 'error');
        if (!state.ui) state.ui = {};
        state.ui.adminTeacherRows = Array.isArray(data.teachers) ? data.teachers : [];
        renderAdminTeacherAccountManage();
    } catch (e) {
        console.error('[openAdminTeacherAccountManage] failed:', e);
        toast('선생님 계정 조회 중 오류가 발생했습니다.', 'error');
    }
}

function renderAdminTeacherAccountManage() {
    const teachers = getAdminTeacherRows().slice().sort((a, b) => {
        const ar = String(a.role || '') === 'admin' ? 0 : 1;
        const br = String(b.role || '') === 'admin' ? 0 : 1;
        if (ar !== br) return ar - br;
        return String(a.name || '').localeCompare(String(b.name || ''), 'ko');
    });

    const rows = teachers.map(t => {
        const safeId = apEscapeHtml(String(t.id || ''));
        const role = String(t.role || 'teacher');
        const roleColor = role === 'admin' ? 'var(--error)' : 'var(--primary)';
        const roleBg = role === 'admin' ? 'rgba(var(--error-rgb),0.10)' : 'var(--primary-soft)';
        return `
            <div style="padding:14px 0; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:12px;">
                <div style="min-width:0; flex:1;">
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <span style="font-size:14px; color:var(--text); line-height:1.35;; font-weight:500;">${apEscapeHtml(t.name || '')}</span>
                        <span style="font-size:11px; font-weight:500; color:${roleColor}; background:${roleBg}; padding:3px 8px; border-radius:999px;">${adminTeacherRoleLabel(role)}</span>
                    </div>
                    <div style="font-size:12px; color:var(--secondary); font-weight:500; margin-top:4px; line-height:1.4;">ID ${apEscapeHtml(t.login_id || '')}</div>
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
                    <button class="btn" style="min-height:34px; padding:6px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); border:none;" onclick="openAdminEditTeacherModal('${safeId}')">수정</button>
                    <button class="btn" style="min-height:34px; padding:6px 10px; font-size:11px; font-weight:500; border-radius:10px; background:rgba(var(--warning-rgb),0.12); color:var(--warning); border:none;" onclick="openAdminResetTeacherPasswordModal('${safeId}')">PW 초기화</button>
                </div>
            </div>
        `;
    }).join('');

    showModal('선생님 계정', `
        <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:500; margin-bottom:14px;" onclick="openAdminCreateTeacherModal()">새 선생님 계정</button>
        <div style="max-height:58vh; overflow-y:auto; padding-right:4px;">
            ${rows || `<div style="text-align:center; padding:28px; color:var(--secondary); font-size:13px; font-weight:500;">등록된 선생님 계정이 없습니다.</div>`}
        </div>
    `);
}

function openAdminCreateTeacherModal() {
    showModal('새 선생님 계정', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <input id="admin-new-teacher-name" class="btn" placeholder="이름" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <input id="admin-new-teacher-login" class="btn" placeholder="로그인 ID" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <input id="admin-new-teacher-password" type="password" class="btn" placeholder="초기 비밀번호" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <select id="admin-new-teacher-role" class="btn" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
                <option value="teacher">선생님</option>
                <option value="admin">원장</option>
            </select>
            <div style="font-size:12px; color:var(--secondary); font-weight:500; line-height:1.5; background:var(--surface-2); padding:10px 12px; border-radius:12px;">계정 생성 후 담당반 배정은 반 관리/담당 변경 메뉴에서 별도로 진행합니다.</div>
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:500;" onclick="handleAdminCreateTeacher()">생성</button>
        </div>
    `);
}

async function handleAdminCreateTeacher() {
    const name = document.getElementById('admin-new-teacher-name')?.value.trim() || '';
    const loginId = document.getElementById('admin-new-teacher-login')?.value.trim() || '';
    const password = document.getElementById('admin-new-teacher-password')?.value.trim() || '';
    const role = document.getElementById('admin-new-teacher-role')?.value || 'teacher';

    if (!name || !loginId || !password) return toast('이름, ID, 비밀번호를 모두 입력하세요.', 'warn');
    if (password.length < 4) return toast('비밀번호는 4자 이상으로 입력하세요.', 'warn');

    try {
        const r = await api.post('teachers', { name, login_id: loginId, password, role });
        if (r?.success) {
            toast('선생님 계정이 생성되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '선생님 계정 생성에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminCreateTeacher] failed:', e);
        toast('선생님 계정 생성 중 오류가 발생했습니다.', 'error');
    }
}

function openAdminEditTeacherModal(teacherId) {
    const teacher = getAdminTeacherRows().find(t => String(t.id) === String(teacherId));
    if (!teacher) return toast('선생님 계정을 찾을 수 없습니다.', 'warn');

    showModal('선생님 계정 수정', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="font-size:12px; color:var(--secondary); font-weight:500; padding:0 4px;">로그인 ID: ${apEscapeHtml(teacher.login_id || '')}</div>
            <input id="admin-edit-teacher-name" class="btn" value="${apEscapeHtml(teacher.name || '')}" placeholder="이름" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <select id="admin-edit-teacher-role" class="btn" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
                <option value="teacher" ${String(teacher.role || '') !== 'admin' ? 'selected' : ''}>선생님</option>
                <option value="admin" ${String(teacher.role || '') === 'admin' ? 'selected' : ''}>원장</option>
            </select>
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:500;" onclick="handleAdminUpdateTeacher('${apEscapeHtml(String(teacher.id || ''))}')">저장</button>
        </div>
    `);
}

async function handleAdminUpdateTeacher(teacherId) {
    const name = document.getElementById('admin-edit-teacher-name')?.value.trim() || '';
    const role = document.getElementById('admin-edit-teacher-role')?.value || 'teacher';
    if (!name) return toast('이름을 입력하세요.', 'warn');

    try {
        const r = await api.patch(`teachers/${teacherId}`, { name, role });
        if (r?.success) {
            toast('선생님 계정이 수정되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '선생님 계정 수정에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminUpdateTeacher] failed:', e);
        toast('선생님 계정 수정 중 오류가 발생했습니다.', 'error');
    }
}

function openAdminResetTeacherPasswordModal(teacherId) {
    const teacher = getAdminTeacherRows().find(t => String(t.id) === String(teacherId));
    if (!teacher) return toast('선생님 계정을 찾을 수 없습니다.', 'warn');

    showModal('비밀번호 초기화', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="font-size:13px; color:var(--text); font-weight:500; line-height:1.5; background:var(--surface-2); padding:12px; border-radius:12px;">${apEscapeHtml(teacher.name || '')} 선생님의 비밀번호를 새 값으로 초기화합니다.</div>
            <input id="admin-reset-teacher-password" type="password" class="btn" placeholder="새 비밀번호" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:500;" onclick="handleAdminResetTeacherPassword('${apEscapeHtml(String(teacher.id || ''))}')">초기화</button>
        </div>
    `);
}

async function handleAdminResetTeacherPassword(teacherId) {
    const newPassword = document.getElementById('admin-reset-teacher-password')?.value.trim() || '';
    if (!newPassword) return toast('새 비밀번호를 입력하세요.', 'warn');
    if (newPassword.length < 4) return toast('비밀번호는 4자 이상으로 입력하세요.', 'warn');
    if (!confirm('비밀번호를 초기화할까요?')) return;

    try {
        const r = await api.patch(`teachers/${teacherId}/reset-password`, { new_password: newPassword });
        if (r?.success) {
            toast('비밀번호가 초기화되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '비밀번호 초기화에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminResetTeacherPassword] failed:', e);
        toast('비밀번호 초기화 중 오류가 발생했습니다.', 'error');
    }
}

// ─────────────────────────────────────────────
// [Admin Overview] 원장모드 상시 운영 요약
// ─────────────────────────────────────────────
function adminNormalizeStatus(value) {
    return String(value || '재원').trim() || '재원';
}

function adminGetStudentClassMap(studentId) {
    if (typeof apmsGetClassStudentMap === 'function') return apmsGetClassStudentMap(studentId);
    return (state.db.class_students || []).find(m => String(m.student_id) === String(studentId)) || null;
}

function adminGetClassById(classId) {
    if (typeof apmsGetClassById === 'function') return apmsGetClassById(classId);
    return (state.db.classes || []).find(c => String(c.id) === String(classId)) || null;
}

function adminGetStudentClass(studentId) {
    const map = adminGetStudentClassMap(studentId);
    return map ? adminGetClassById(map.class_id) : null;
}

function adminGetClassStudentIds(classId) {
    if (typeof apmsGetClassStudentIds === 'function') return apmsGetClassStudentIds(classId);
    return (state.db.class_students || [])
        .filter(m => String(m.class_id) === String(classId))
        .map(m => String(m.student_id));
}

function adminGetCreatedDateText(student) {
    return String(student?.created_at || '').split('T')[0].split(' ')[0];
}

function adminGetDaysSince(dateText, todayTime) {
    const time = apParseLocalDateTime(dateText);
    if (time === null) return null;
    return Math.max(0, Math.floor((todayTime - time) / (1000 * 60 * 60 * 24)) + 1);
}

function adminIsRecentStudent(student, todayTime, days = 30) {
    const createdDate = adminGetCreatedDateText(student);
    const createdTime = apParseLocalDateTime(createdDate);
    if (createdTime === null) return false;
    const diff = (todayTime - createdTime) / (1000 * 60 * 60 * 24);
    return diff >= 0 && diff < days;
}

function adminBuildOverviewData(todayStr, todayTime) {
    const students = state.db.students || [];
    const classes = state.db.classes || [];
    const maps = state.db.class_students || [];

    const activeStudents = students.filter(s => adminNormalizeStatus(s.status) === '재원');
    const dischargedStudents = students.filter(s => adminNormalizeStatus(s.status) === '제적');
    const leaveStudents = students.filter(s => adminNormalizeStatus(s.status) === '휴원');
    const recentStudents = activeStudents
        .filter(s => adminIsRecentStudent(s, todayTime, 14))
        .sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')) || String(a.name || '').localeCompare(String(b.name || ''), 'ko'));

    const unassignedStudents = activeStudents.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return true;
        const cls = adminGetClassById(map.class_id);
        return !cls;
    });

    const teacherlessClasses = classes.filter(c => {
        if (Number(c.is_active) === 0) return false;
        const teacherName = String(c.teacher_name || '').trim();
        return !teacherName || teacherName === '담당';
    });

    const cleanupStudents = activeStudents.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return false;
        const cls = adminGetClassById(map.class_id);
        return !cls || Number(cls.is_active) === 0;
    });

    return {
        todayStr,
        todayTime,
        activeStudents,
        dischargedStudents,
        leaveStudents,
        recentStudents,
        unassignedStudents,
        teacherlessClasses,
        cleanupStudents
    };
}

function adminOpenStudentEditOrDetail(studentId) {
    if (typeof openEditStudent === 'function') {
        openEditStudent(studentId, { returnTo: { type: 'dashboard' } });
        return;
    }
    closeModal(true);
    if (typeof renderStudentDetail === 'function') renderStudentDetail(studentId);
    else toast('학생 화면을 불러오지 못했습니다.', 'warn');
}

function adminOpenDashboardStudentDetail(studentId) {
    if (typeof setModalReturnView === 'function') setModalReturnView({ type: 'dashboard' });
    if (typeof renderStudentDetail === 'function') return renderStudentDetail(studentId);
    toast('학생 화면을 불러오지 못했습니다.', 'warn');
}

function renderAdminMiniMetric(label, value, tone = 'text', onclick = '') {
    const colorMap = {
        primary: 'var(--text)',
        success: 'var(--text)',
        warning: 'var(--warning)',
        error: 'var(--error)',
        secondary: 'var(--secondary)',
        text: 'var(--text)'
    };
    const color = colorMap[tone] || colorMap.text;
    const clickAttr = onclick ? ` onclick="${onclick}"` : '';
    const cursor = onclick ? 'cursor:pointer;' : '';
    const roleAttr = onclick ? ' role="button" tabindex="0"' : '';
    return `
        <div class="ap-admin-mini-metric"${roleAttr}${clickAttr} style="${cursor} min-height:44px; padding:0 10px; border-radius:12px; background:var(--surface); border:1px solid var(--border); display:flex; flex-direction:column; align-items:center; justify-content:center; box-sizing:border-box; box-shadow:none;">
            <div style="font-size:13px; font-weight:500; color:${color}; line-height:1.25; white-space:nowrap;">${label}</div>
        </div>
    `;
}

function renderAdminStudentOverviewPanel(data) {
    return `
        <div class="ap-admin-section" style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:14px; font-weight:500; color:var(--text);">오늘 운영</h3>
            </div>
            <div class="ap-admin-overview-grid" style="display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px; padding:4px; border:1px solid var(--border); border-radius:16px; background:var(--surface-2);">
                ${renderAdminMiniMetric('재원', data.activeStudents.length, 'primary', "openAdminStudentGradeModal('active')")}
                ${renderAdminMiniMetric('최근 등록', data.recentStudents.length, 'success', "openAdminStudentGradeModal('new')")}
                ${renderAdminMiniMetric('퇴원', data.dischargedStudents.length, 'secondary', "openAdminStudentList('discharged')")}
                ${renderAdminMiniMetric('휴원', data.leaveStudents.length, 'warning', "openAdminLeaveStudentList()")}
            </div>
        </div>
    `;
}

function renderAdminNeedCheckPanel(data) {
    const items = [
        { label: '반 배정 필요', value: data.unassignedStudents.length, action: 'openAdminUnassignedStudentList()' },
        { label: '담당 선생님 미지정', value: data.teacherlessClasses.length, unit: '개', action: 'openAdminTeacherlessClassList()' },
        { label: '반 정리 필요', value: data.cleanupStudents.length, action: 'openAdminClassCleanupList()' }
    ];

    return `
        <div class="ap-admin-section" style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:14px; font-weight:500; color:var(--text);">확인 필요</h3>
            </div>
            <div class="ap-admin-check-grid" style="display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px;">
                ${items.map(item => {
                    const hasIssue = Number(item.value || 0) > 0;
                    return `
                        <button class="btn ap-admin-check-item" style="min-height:52px; padding:0 10px; border-radius:16px; border:1px solid ${hasIssue ? 'rgba(var(--error-rgb),0.20)' : 'var(--border)'}; background:${hasIssue ? 'rgba(255,71,87,0.045)' : 'var(--surface)'}; box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:8px;" onclick="${item.action}">
                            <span style="min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--text); font-size:12px; font-weight:500;">${item.label}</span>
                            <span style="flex-shrink:0; font-size:13px; font-weight:500; color:${hasIssue ? 'var(--error)' : 'var(--secondary)'};">${item.value}${item.unit || '명'}</span>
                        </button>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function renderAdminNewStudentPanel(data) {
    const list = Array.isArray(data.recentStudents) ? data.recentStudents.slice(0, 10) : [];
    const rows = list.map(s => {
        const cls = adminGetStudentClass(s.id);
        const days = adminGetDaysSince(adminGetCreatedDateText(s), data.todayTime);
        const attCount = (state.db.attendance_history || state.db.attendance || []).filter(a => String(a.student_id) === String(s.id)).length;
        const hwCount = (state.db.homework_history || state.db.homework || []).filter(h => String(h.student_id) === String(s.id)).length;
        const examCount = (state.db.exam_sessions || []).filter(e => String(e.student_id) === String(s.id)).length;
        const hasClass = !!cls;
        const recordText = examCount > 0 ? `시험 ${examCount}회` : (attCount + hwCount > 0 ? `기록 ${attCount + hwCount}회` : '기록 없음');
        return `
            <div class="ap-admin-recent-student-row" onclick="adminOpenDashboardStudentDetail('${s.id}')" style="height:46px; min-height:46px; padding:0 12px; display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; box-sizing:border-box;">
                <div style="min-width:0; display:flex; align-items:center; gap:8px;">
                    <span style="font-size:13px; color:var(--text); white-space:nowrap;; font-weight:500;">${apEscapeHtml(s.name)}</span>
                    <span style="font-size:11px; color:var(--secondary); font-weight:500; white-space:nowrap;">등록 ${days || '-'}일차</span>
                </div>
                <div style="display:flex; align-items:center; gap:5px; flex-shrink:0; min-width:0;">
                    <span style="font-size:10.5px; font-weight:500; color:${hasClass ? 'var(--primary)' : 'var(--error)'}; background:${hasClass ? 'var(--primary-soft)' : 'rgba(var(--error-rgb),0.10)'}; padding:3px 6px; border-radius:999px; white-space:nowrap;">${hasClass ? apEscapeHtml(cls.name) : '반 배정 필요'}</span>
                    <span style="font-size:10.5px; font-weight:500; color:var(--secondary); background:var(--surface-2); padding:3px 6px; border-radius:999px; white-space:nowrap;">${recordText}</span>
                </div>
            </div>
        `;
    }).join('');

    return `
        <div class="ap-admin-section" style="margin-bottom:28px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:14px; font-weight:500; color:var(--text);">최근 등록 원생</h3>
                <span style="font-size:12px; font-weight:400; color:var(--secondary);">최근 14일 ${data.recentStudents.length}명</span>
            </div>
            <div class="card ap-admin-recent-student-grid" style="padding:0; overflow:hidden; border:1px solid var(--border); border-radius:16px; background:var(--surface);">
                ${rows || `<div style="height:52px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">최근 등록 원생이 없습니다.</div>`}
            </div>
        </div>
    `;
}


function adminGetGradeLabel(student) {
    const text = String((student && (student.grade || student.school_grade || student.memo)) || '').trim();
    if (/중\s*1|중1/.test(text)) return '중1';
    if (/중\s*2|중2/.test(text)) return '중2';
    if (/중\s*3|중3/.test(text)) return '중3';
    if (/고\s*1|고1/.test(text)) return '고1';
    if (/고\s*2|고2/.test(text)) return '고2';
    if (/고\s*3|고3/.test(text)) return '고3';
    return text || '기타';
}

function adminGetGradeOrder(label) {
    const order = ['중1', '중2', '중3', '고1', '고2', '고3', '기타'];
    const idx = order.indexOf(String(label || ''));
    return idx >= 0 ? idx : 98;
}

function adminGetStudentListByType(type) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const students = state.db.students || [];
    const activeStudents = students.filter(s => adminNormalizeStatus(s.status) === '재원');
    if (type === 'new') {
        return activeStudents
            .filter(s => adminIsRecentStudent(s, todayTime, 14))
            .sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')) || String(a.name || '').localeCompare(String(b.name || ''), 'ko'));
    }
    if (type === 'leave') return students.filter(s => adminNormalizeStatus(s.status) === '휴원');
    if (type === 'discharged') return students.filter(s => adminNormalizeStatus(s.status) === '제적');
    return activeStudents.sort((a, b) => adminGetGradeOrder(adminGetGradeLabel(a)) - adminGetGradeOrder(adminGetGradeLabel(b)) || String(a.name || '').localeCompare(String(b.name || ''), 'ko'));
}

function adminRenderStudentGradeSummary(list) {
    const students = Array.isArray(list) ? list : [];
    const grades = ['중1', '중2', '중3', '고1', '고2', '고3', '기타'];
    const gradeCounts = {};
    students.forEach(s => {
        const grade = adminGetGradeLabel(s);
        gradeCounts[grade] = (gradeCounts[grade] || 0) + 1;
    });
    const chips = [
        `<span style="min-height:30px; padding:6px 10px; border-radius:999px; background:var(--primary-soft); color:var(--primary); font-size:12px; font-weight:500; display:flex; align-items:center;">총 ${students.length}명</span>`,
        ...grades.map(g => {
            const count = Number(gradeCounts[g] || 0);
            if (count === 0) return '';
            return `<span style="min-height:30px; padding:6px 10px; border-radius:999px; background:var(--surface); border:1px solid var(--border); color:var(--text); font-size:12px; font-weight:500; display:flex; align-items:center;">${apEscapeHtml(g)} ${count}명</span>`;
        })
    ].join('');
    return `<div style="display:flex; flex-wrap:wrap; gap:6px; margin:0 0 12px 0;">${chips}</div>`;
}

function adminEnsureStudentGradeModalState(type) {
    if (!state.ui) state.ui = {};
    if (!state.ui.adminStudentGradeModal || state.ui.adminStudentGradeModal.type !== type) {
        state.ui.adminStudentGradeModal = { type, grade: '전체', keyword: '' };
    }
    return state.ui.adminStudentGradeModal;
}

function openAdminStudentGradeModal(type) {
    adminEnsureStudentGradeModalState(type || 'active');
    renderAdminStudentGradeModal();
}

function adminSetStudentGradeModalGrade(grade) {
    const modal = adminEnsureStudentGradeModalState(state.ui?.adminStudentGradeModal?.type || 'active');
    modal.grade = String(grade || '전체');
    renderAdminStudentGradeModal();
}

function adminHandleStudentGradeModalSearch(value) {
    const modal = adminEnsureStudentGradeModalState(state.ui?.adminStudentGradeModal?.type || 'active');
    modal.keyword = String(value || '').trim();
    const body = document.getElementById('admin-student-grade-modal-body');
    if (body) body.innerHTML = renderAdminStudentGradeModalBody();
}

function renderAdminStudentGradeModalBody() {
    const modal = adminEnsureStudentGradeModalState(state.ui?.adminStudentGradeModal?.type || 'active');
    const list = adminGetStudentListByType(modal.type);
    const keyword = adminNormalizeSearchValue(modal.keyword || '');
    const grades = ['전체', '중1', '중2', '중3', '고1', '고2', '고3', '기타'];
    const gradeCounts = {};
    list.forEach(s => {
        const grade = adminGetGradeLabel(s);
        gradeCounts[grade] = (gradeCounts[grade] || 0) + 1;
    });
    const filtered = list.filter(s => {
        const grade = adminGetGradeLabel(s);
        const cls = adminGetStudentClass(s.id);
        if (modal.grade !== '전체' && grade !== modal.grade) return false;
        if (!keyword) return true;
        return adminSearchIncludes([s.name, s.school_name, s.grade, s.status, s.phone, cls && cls.name], modal.keyword);
    });
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const chips = grades.map(g => {
        const count = g === '전체' ? list.length : Number(gradeCounts[g] || 0);
        if (g !== '전체' && count === 0) return '';
        const active = modal.grade === g;
        return `<button class="btn" style="min-height:34px; padding:6px 10px; font-size:12px; font-weight:500; border-radius:999px; border:1px solid ${active ? 'rgba(var(--primary-rgb),0.25)' : 'var(--border)'}; background:${active ? 'var(--primary-soft)' : 'var(--surface)'}; color:${active ? 'var(--primary)' : 'var(--text)'}; box-shadow:none;" onclick="adminSetStudentGradeModalGrade('${apEscapeHtml(g)}')">${apEscapeHtml(g)} ${count}</button>`;
    }).join('');
    const rows = filtered.map(s => {
        const cls = adminGetStudentClass(s.id);
        const grade = adminGetGradeLabel(s);
        const days = adminGetDaysSince(adminGetCreatedDateText(s), todayTime);
        const subText = [cls ? cls.name : '미배정', s.school_name || '', grade].filter(Boolean).join(' · ');
        const recentText = modal.type === 'new' ? `<span style="font-size:11px; font-weight:500; color:var(--secondary); background:var(--surface-2); padding:3px 7px; border-radius:999px; white-space:nowrap;">등록 ${days || '-'}일차</span>` : '';
        return `
            <div style="padding:13px 12px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:12px; background:var(--surface);">
                <button class="btn" style="flex:1; min-width:0; padding:0; border:none; background:transparent; box-shadow:none; text-align:left; display:block;" onclick="adminOpenStudentEditOrDetail('${apEscapeHtml(String(s.id || ''))}')">
                    <div style="font-size:14px; font-weight:500; color:var(--text); line-height:1.35; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(s.name || '')}</div>
                    <div style="font-size:12px; font-weight:400; color:var(--secondary); margin-top:4px; line-height:1.35; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(subText)}</div>
                </button>
                ${recentText}
            </div>
        `;
    }).join('');
    return `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <input type="search" autocomplete="off" value="${apEscapeHtml(modal.keyword || '')}" placeholder="학생 이름 검색" oninput="adminHandleStudentGradeModalSearch(this.value)" style="width:100%; height:42px; border:1px solid var(--border); border-radius:14px; background:var(--surface); color:var(--text); padding:0 13px; font-size:13px; font-weight:500; box-sizing:border-box;">
            <div style="display:flex; flex-wrap:wrap; gap:6px;">${chips}</div>
            <div style="font-size:12px; font-weight:400; color:var(--secondary); padding:0 2px;">총 ${filtered.length}명</div>
            <div style="max-height:54vh; overflow-y:auto; border:1px solid var(--border); border-radius:16px; background:var(--surface); overflow:hidden;">
                ${rows || `<div style="height:72px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">조회 대상이 없습니다.</div>`}
            </div>
        </div>
    `;
}

function renderAdminStudentGradeModal() {
    const modal = adminEnsureStudentGradeModalState(state.ui?.adminStudentGradeModal?.type || 'active');
    const title = modal.type === 'new' ? '최근 등록' : '재원';
    showModal(title, `<div id="admin-student-grade-modal-body">${renderAdminStudentGradeModalBody()}</div>`);
}

function adminGetConsultationDate(row) {
    return String(row?.date || row?.consultation_date || row?.created_at || '').slice(0, 10);
}

function adminConsultationSortValue(row) {
    return String(row?.date || row?.consultation_date || row?.created_at || '').replace(/[^0-9]/g, '');
}

function adminGetStudentById(studentId) {
    return (state.db.students || []).find(s => String(s.id) === String(studentId)) || null;
}

function adminGetConsultationRows() {
    return (state.db.consultations || [])
        .slice()
        .sort((a, b) => String(adminConsultationSortValue(b)).localeCompare(String(adminConsultationSortValue(a))) || String(b.created_at || '').localeCompare(String(a.created_at || '')) || String(b.id || '').localeCompare(String(a.id || '')));
}

function adminGetRecentConsultationRows(days = 14) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    return adminGetConsultationRows().filter(row => {
        const date = adminGetConsultationDate(row);
        const time = apParseLocalDateTime(date);
        if (time === null) return false;
        const diff = (todayTime - time) / (1000 * 60 * 60 * 24);
        return diff >= 0 && diff <= days;
    });
}

function adminConsultationRowStudentName(row) {
    const student = adminGetStudentById(row?.student_id);
    return (student && student.name) || row?.student_name_snapshot || '학생 확인';
}

function adminRecentConsultationPreviewText(row) {
    const content = String(row?.content || '').replace(/\s+/g, ' ').trim();
    return content || '상담 내용 없음';
}

function adminRenderConsultationHistoryRows(rows) {
    const list = Array.isArray(rows) ? rows : [];
    return list.map(row => {
        const date = adminGetConsultationDate(row) || '-';
        const type = String(row?.type || '상담').trim() || '상담';
        const content = String(row?.content || '').trim();
        const nextAction = String(row?.next_action || row?.nextAction || '').trim();
        return `
            <div style="padding:14px 12px; border-bottom:1px solid var(--border); background:var(--surface);">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:8px;">
                    <div style="font-size:13px; font-weight:500; color:var(--text); line-height:1.35;">${apEscapeHtml(date)} · ${apEscapeHtml(type)}</div>
                </div>
                <div style="font-size:13px; font-weight:500; color:var(--text); line-height:1.55; white-space:pre-wrap;">${apEscapeHtml(content || '내용 없음')}</div>
                ${nextAction ? `<div style="margin-top:8px; font-size:12px; font-weight:400; color:var(--secondary); line-height:1.45; white-space:pre-wrap;">다음 조치 · ${apEscapeHtml(nextAction)}</div>` : ''}
            </div>
        `;
    }).join('') || `<div style="height:72px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">상담 기록이 없습니다.</div>`;
}

function openAdminStudentConsultationHistory(studentId) {
    const sid = String(studentId || '').trim();
    const student = adminGetStudentById(sid);
    const rows = adminGetConsultationRows().filter(row => String(row.student_id || '') === sid);
    const studentName = student ? student.name : '학생 확인';
    const detailBtn = student ? `<button class="btn" style="min-height:34px; padding:6px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); border:1px solid var(--border); box-shadow:none;" onclick="adminOpenStudentEditOrDetail('${apEscapeHtml(sid)}')">학생 상세</button>` : '';
    showModal(`상담 이력 · ${studentName}`, `
        <div style="display:flex; flex-direction:column; gap:10px; margin:-4px;">
            <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; padding:0 2px;">
                <div style="font-size:12px; font-weight:400; color:var(--secondary);">총 ${rows.length}건</div>
                ${detailBtn}
            </div>
            <div style="max-height:58vh; overflow-y:auto; border:1px solid var(--border); border-radius:16px; background:var(--surface); overflow:hidden;">
                ${adminRenderConsultationHistoryRows(rows)}
            </div>
        </div>
    `);
}

function renderAdminRecentConsultationPanel() {
    const recentRows = adminGetRecentConsultationRows(14);
    const byStudent = [];
    const seen = new Set();
    recentRows.forEach(row => {
        const sid = String(row.student_id || '').trim();
        if (!sid || seen.has(sid)) return;
        seen.add(sid);
        byStudent.push(row);
    });
    const rows = byStudent.slice(0, 8).map(row => {
        const sid = String(row.student_id || '').trim();
        const student = adminGetStudentById(sid);
        const cls = student ? adminGetStudentClass(student.id) : null;
        const type = String(row?.type || '상담').trim() || '상담';
        const nextAction = String(row?.next_action || row?.nextAction || '').trim();
        const preview = adminRecentConsultationPreviewText(row);
        const meta = [adminGetConsultationDate(row), cls && cls.name].filter(Boolean).join(' · ');
        return `
            <button class="btn" style="width:100%; min-height:68px; padding:10px 12px; border:none; border-bottom:1px solid var(--border); border-radius:0; background:var(--surface); box-shadow:none; display:grid; grid-template-columns:minmax(0, 1fr) auto; align-items:center; gap:12px; text-align:left;" onclick="openAdminStudentConsultationHistory('${apEscapeHtml(sid)}')">
                <span style="min-width:0; display:flex; flex-direction:column; gap:4px;">
                    <span style="display:flex; align-items:center; gap:7px; min-width:0;">
                        <span style="font-size:13px; font-weight:700; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(adminConsultationRowStudentName(row))}</span>
                        <span style="flex-shrink:0; font-size:10px; font-weight:700; color:var(--primary); background:var(--primary-soft); border:1px solid rgba(var(--primary-rgb),0.14); border-radius:999px; padding:2px 7px;">${apEscapeHtml(type)}</span>
                    </span>
                    <span style="font-size:12px; font-weight:500; color:var(--secondary); line-height:1.45; overflow:hidden; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical;">${apEscapeHtml(preview)}</span>
                </span>
                <span style="flex-shrink:0; display:flex; flex-direction:column; align-items:flex-end; gap:5px; max-width:210px;">
                    <span style="font-size:11px; font-weight:500; color:var(--secondary); white-space:nowrap;">${apEscapeHtml(meta)}</span>
                    ${nextAction ? `<span style="max-width:100%; font-size:11px; font-weight:700; color:var(--text); background:var(--surface-2); border:1px solid var(--border); border-radius:999px; padding:3px 8px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">다음 조치 · ${apEscapeHtml(nextAction)}</span>` : '<span style="font-size:11px; font-weight:500; color:var(--secondary);">후속 없음</span>'}
                </span>
            </button>
        `;
    }).join('');

    return `
        <div class="ap-admin-section" style="margin-bottom:28px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:14px; font-weight:500; color:var(--text);">최근 상담</h3>
                <button class="btn" style="min-height:30px; padding:5px 10px; font-size:11px; font-weight:500; border-radius:999px; background:var(--surface-2); border:1px solid var(--border); box-shadow:none;" onclick="openAdminConsultationCenter()">상담 전체 보기</button>
            </div>
            <div class="card" style="padding:0; overflow:hidden; border:1px solid var(--border); border-radius:16px; background:var(--surface);">
                ${rows || `<div style="height:54px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">최근 상담 기록이 없습니다.</div>`}
            </div>
        </div>
    `;
}

function openAdminConsultationCenter() {
    if (!state.ui) state.ui = {};
    state.ui.adminConsultationSearchKeyword = '';
    showModal('상담 전체 보기', `<div id="admin-consultation-center-body">${renderAdminConsultationCenterBody('')}</div>`);
}

function handleAdminConsultationSearchInput(value) {
    if (!state.ui) state.ui = {};
    state.ui.adminConsultationSearchKeyword = String(value || '').trim();
    const body = document.getElementById('admin-consultation-center-body');
    if (body) body.innerHTML = renderAdminConsultationCenterBody(state.ui.adminConsultationSearchKeyword);
}

function renderAdminConsultationCenterBody(keyword) {
    const key = String(keyword || '').trim();
    const baseRows = key ? adminGetConsultationRows() : adminGetRecentConsultationRows(14);
    const filtered = baseRows.filter(row => {
        if (!key) return true;
        const student = adminGetStudentById(row.student_id);
        const cls = student ? adminGetStudentClass(student.id) : null;
        return adminSearchIncludes([
            student && student.name,
            student && student.school_name,
            student && student.grade,
            cls && cls.name,
            row.type,
            row.content,
            row.next_action
        ], key);
    }).slice(0, 30);
    const rows = filtered.map(row => {
        const sid = String(row.student_id || '').trim();
        const student = adminGetStudentById(sid);
        const cls = student ? adminGetStudentClass(student.id) : null;
        const meta = [adminGetConsultationDate(row), cls && cls.name, row.type].filter(Boolean).join(' · ');
        return `
            <button class="btn" style="min-height:52px; padding:10px 12px; border:none; border-bottom:1px solid var(--border); border-radius:0; background:var(--surface); box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:12px;" onclick="openAdminStudentConsultationHistory('${apEscapeHtml(sid)}')">
                <span style="min-width:0; text-align:left;">
                    <span style="display:block; font-size:13px; font-weight:500; color:var(--text); line-height:1.35; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(adminConsultationRowStudentName(row))}</span>
                    <span style="display:block; font-size:11px; font-weight:500; color:var(--secondary); margin-top:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(meta)}</span>
                </span>
                <span style="flex-shrink:0; font-size:11px; font-weight:500; color:var(--primary); background:var(--primary-soft); padding:4px 8px; border-radius:999px;">보기</span>
            </button>
        `;
    }).join('');
    return `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <input type="search" autocomplete="off" value="${apEscapeHtml(key)}" placeholder="학생 이름 검색" oninput="handleAdminConsultationSearchInput(this.value)" style="width:100%; height:42px; border:1px solid var(--border); border-radius:14px; background:var(--surface); color:var(--text); padding:0 13px; font-size:13px; font-weight:500; box-sizing:border-box;">
            <div style="font-size:12px; font-weight:400; color:var(--secondary); padding:0 2px;">${key ? '검색 결과' : '최근 2주'} ${filtered.length}건</div>
            <div style="max-height:56vh; overflow-y:auto; border:1px solid var(--border); border-radius:16px; background:var(--surface); overflow:hidden;">
                ${rows || `<div style="height:72px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">상담 기록이 없습니다.</div>`}
            </div>
        </div>
    `;
}

function openAdminLeaveStudentList() {
    const list = (state.db.students || []).filter(s => adminNormalizeStatus(s.status) === '휴원');
    renderAdminSimpleStudentList('휴원생 목록', list, false, true);
}

function openAdminUnassignedStudentList() {
    const activeStudents = (state.db.students || []).filter(s => adminNormalizeStatus(s.status) === '재원');
    const list = activeStudents.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return true;
        return !adminGetClassById(map.class_id);
    });
    renderAdminSimpleStudentList('반 배정 필요', list, true);
}

function openAdminClassCleanupList() {
    const list = (state.db.students || []).filter(s => {
        if (adminNormalizeStatus(s.status) !== '재원') return false;
        const map = adminGetStudentClassMap(s.id);
        if (!map) return false;
        const cls = adminGetClassById(map.class_id);
        return !cls || Number(cls.is_active) === 0;
    });
    renderAdminSimpleStudentList('반 정리 필요', list, true);
}

function openAdminTeacherlessClassList() {
    const classes = (state.db.classes || []).filter(c => {
        if (Number(c.is_active) === 0) return false;
        const teacherName = String(c.teacher_name || '').trim();
        return !teacherName || teacherName === '담당';
    });

    const rows = classes.map(c => `
        <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:12px; background:var(--surface);">
            <div style="min-width:0;">
                <div style="font-size:14px; font-weight:500; color:var(--text); line-height:1.35;">${apEscapeHtml(c.name || '')}</div>
                <div style="font-size:12px; font-weight:400; color:var(--secondary); margin-top:3px;">${apEscapeHtml(c.grade || '')} · 담당 선생님 미지정</div>
            </div>
            <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); border:none;" onclick="closeModal(true); if(typeof openClassManageModal==='function') openClassManageModal(); else toast('반 관리 화면을 불러오지 못했습니다.', 'warn');">반 관리</button>
        </div>
    `).join('');

    showModal(`담당 선생님 미지정 (${classes.length}개)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:500;">확인할 반이 없습니다.</div>`}</div>`);
}

function renderAdminSimpleStudentList(title, list, editable = false, showGradeSummary = false) {
    const rows = list.map(s => {
        const cls = adminGetStudentClass(s.id);
        const classText = cls ? cls.name : '미배정';
        const status = adminNormalizeStatus(s.status);
        const action = editable
            ? `<button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--primary-soft); color:var(--primary); border:none;" onclick="adminOpenStudentEditOrDetail('${s.id}')">수정</button>`
            : `<button class="btn" style="padding:7px 10px; font-size:11px; font-weight:500; border-radius:10px; background:var(--surface-2); border:none;" onclick="closeModal(true); renderStudentDetail('${s.id}')">상세</button>`;
        return `
            <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; gap:12px; background:var(--surface);">
                <div style="min-width:0; flex:1;">
                    <div style="font-weight:500; font-size:14px; color:var(--text); line-height:1.35;">${apEscapeHtml(s.name || '')} <span style="font-size:12px; color:var(--secondary); font-weight:500; margin-left:4px;">${apEscapeHtml(s.school_name || '')} ${apEscapeHtml(s.grade || '')}</span></div>
                    <div style="font-size:12px; color:var(--primary); font-weight:500; margin-top:4px;">${apEscapeHtml(classText)} <span style="color:var(--secondary); font-weight:500;">| ${apEscapeHtml(status)}</span></div>
                </div>
                ${action}
            </div>
        `;
    }).join('');

    const gradeSummary = showGradeSummary ? adminRenderStudentGradeSummary(list) : '';
    showModal(`${title} (${list.length}명)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${gradeSummary}${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:500;">조회 대상이 없습니다.</div>`}</div>`);
}


// ─────────────────────────────────────────────
// [Admin Search] 원장모드 전체 검색
// ─────────────────────────────────────────────
function adminNormalizeSearchValue(value) {
    return String(value || '').toLowerCase().replace(/\s+/g, '');
}

function adminSearchIncludes(values, keyword) {
    const key = adminNormalizeSearchValue(keyword);
    if (!key) return false;
    return values.some(value => adminNormalizeSearchValue(value).includes(key));
}

function adminGetSearchClassNameByStudentId(studentId) {
    const cls = adminGetStudentClass(studentId);
    return cls ? String(cls.name || '') : '미배정';
}

function adminGetSearchClassNameByClassId(classId) {
    const cls = adminGetClassById(classId);
    return cls ? String(cls.name || '') : '미배정';
}

function adminGetAssignmentTypeLabel(row) {
    const sourceType = String(row?.source_type || '').trim().toLowerCase();
    const archiveFile = String(row?.archive_file || '').trim();
    if (sourceType === 'clinic') return '클리닉';
    if (sourceType === 'mixed' || archiveFile.startsWith('MIXED:')) return '믹서';
    if (archiveFile) return '아카이브';
    return '자료';
}

function adminBuildGlobalSearchResults(keyword) {
    const key = String(keyword || '').trim();
    if (!key) return [];

    const results = [];
    const students = state.db.students || [];
    const classes = state.db.classes || [];
    const examSchedules = state.db.exam_schedules || [];
    const assignments = state.db.class_exam_assignments || [];

    students.forEach(s => {
        const className = adminGetSearchClassNameByStudentId(s.id);
        if (!adminSearchIncludes([s.name, s.school_name, s.grade, s.status, s.phone, className], key)) return;
        results.push({
            type: 'student',
            label: s.name || '학생',
            meta: `${className} · ${s.school_name || ''} ${s.grade || ''}`.trim(),
            desc: adminNormalizeStatus(s.status),
            actionLabel: '학생 보기',
            studentId: s.id
        });
    });

    classes.forEach(c => {
        if (Number(c.is_active) === 0) return;
        if (!adminSearchIncludes([c.name, c.grade, c.teacher_name], key)) return;
        const count = adminGetClassStudentIds(c.id)
            .filter(id => students.some(s => String(s.id) === String(id) && adminNormalizeStatus(s.status) === '재원'))
            .length;
        results.push({
            type: 'class',
            label: c.name || '반',
            meta: `${c.grade || ''} · ${c.teacher_name || '담당 미지정'}`,
            desc: `재원 ${count}명`,
            actionLabel: '반 열기',
            classId: c.id
        });
    });

    examSchedules.forEach(e => {
        if (!adminSearchIncludes([e.school_name, e.grade, e.exam_name, e.exam_date], key)) return;
        results.push({
            type: 'exam',
            label: `${e.school_name || '학교'} ${e.exam_name || '시험'}`.trim(),
            meta: `${e.grade || '학교공통'} · ${e.exam_date || ''}`,
            desc: '시험일정',
            actionLabel: '일정 보기',
            examDate: e.exam_date
        });
    });

    assignments.forEach(row => {
        const className = adminGetSearchClassNameByClassId(row.class_id);
        if (!adminSearchIncludes([row.exam_title, row.exam_date, row.archive_file, row.source_type, className], key)) return;
        results.push({
            type: 'assignment',
            label: row.exam_title || '배정 자료',
            meta: `${className} · ${row.exam_date || ''}`,
            desc: `${adminGetAssignmentTypeLabel(row)} · ${Number(row.question_count || 0) ? `${row.question_count}문항` : '문항 수 없음'}`,
            actionLabel: '반 열기',
            classId: row.class_id
        });
    });

    const typeOrder = { student: 0, class: 1, exam: 2, assignment: 3 };
    results.sort((a, b) => {
        const ao = typeOrder[a.type] ?? 99;
        const bo = typeOrder[b.type] ?? 99;
        if (ao !== bo) return ao - bo;
        return String(a.label || '').localeCompare(String(b.label || ''), 'ko');
    });

    return results.slice(0, 18);
}

function adminSearchTypeLabel(type) {
    if (type === 'student') return '학생';
    if (type === 'class') return '반';
    if (type === 'exam') return '시험';
    if (type === 'assignment') return '자료';
    return '검색';
}

function renderAdminGlobalSearchResults(results) {
    if (!results.length) {
        return `<div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">검색 결과가 없습니다.</div>`;
    }

    return results.map((item, idx) => `
        <button class="btn ap-admin-search-row"
                style="width:100%; min-height:48px; padding:8px 10px; border-radius:12px; border:1px solid var(--border); background:var(--surface); box-shadow:none; display:flex; justify-content:space-between; align-items:center; gap:10px; text-align:left;"
                onclick="openAdminGlobalSearchResult(${idx})">
            <div style="min-width:0; flex:1;">
                <div style="display:flex; align-items:center; gap:6px; min-width:0;">
                    <span style="flex-shrink:0; font-size:10px; font-weight:500; color:var(--primary); background:var(--primary-soft); padding:2px 7px; border-radius:999px;">${adminSearchTypeLabel(item.type)}</span>
                    <span style="min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13px; color:var(--text); font-weight:500;">${apEscapeHtml(item.label)}</span>
                </div>
                <div style="margin-top:3px; font-size:11px; font-weight:500; color:var(--secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(item.meta || '')}${item.desc ? ` · ${apEscapeHtml(item.desc)}` : ''}</div>
            </div>
            <span style="flex-shrink:0; font-size:11px; font-weight:500; color:var(--secondary);">${apEscapeHtml(item.actionLabel || '열기')}</span>
        </button>
    `).join('');
}

function handleAdminGlobalSearchInput(value) {
    const area = document.getElementById('admin-global-search-results');
    if (!area) return;

    const keyword = String(value || '').trim();
    if (!state.ui) state.ui = {};
    if (!keyword) {
        state.ui.adminGlobalSearchResults = [];
        area.innerHTML = `<div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">학생, 반, 학교, 시험, 자료를 검색하세요.</div>`;
        return;
    }

    const results = adminBuildGlobalSearchResults(keyword);
    state.ui.adminGlobalSearchResults = results;
    area.innerHTML = renderAdminGlobalSearchResults(results);
}

function openAdminGlobalSearchResult(index) {
    const item = (state.ui?.adminGlobalSearchResults || [])[Number(index)];
    if (!item) return toast('검색 결과를 찾을 수 없습니다.', 'warn');

    if (item.type === 'student' && item.studentId) {
        renderStudentDetail(item.studentId);
        return;
    }

    if ((item.type === 'class' || item.type === 'assignment') && item.classId) {
        if (typeof renderClass === 'function') renderClass(String(item.classId));
        else toast('반 화면을 불러오지 못했습니다.', 'warn');
        return;
    }

    if (item.type === 'exam') {
        if (typeof openExamScheduleModal === 'function') openExamScheduleModal();
        else toast('시험일정 화면을 불러오지 못했습니다.', 'warn');
        return;
    }

    toast('이 항목은 바로 열 수 없습니다.', 'warn');
}

function renderAdminGlobalSearchPanel() {
    return `
        <div class="ap-admin-global-search">
            <div class="ap-admin-global-search__field">
                <svg class="ap-admin-global-search__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
                    <path d="M21 21L16.65 16.65M10.8 18.1C6.77 18.1 3.5 14.83 3.5 10.8C3.5 6.77 6.77 3.5 10.8 3.5C14.83 3.5 18.1 6.77 18.1 10.8C18.1 14.83 14.83 18.1 10.8 18.1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <input id="admin-global-search-input"
                       type="search"
                       autocomplete="off"
                       placeholder="학생 · 반 · 학교 · 시험 · 자료 검색"
                       oninput="handleAdminGlobalSearchInput(this.value)"
                       style="width:100%; height:42px; border:0; background:transparent; color:var(--text); padding:0 14px 0 38px; font-size:14px; font-weight:500; box-sizing:border-box;">
            </div>
            <div id="admin-global-search-results" class="ap-admin-global-search__results">
                <div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:500;">학생, 반, 학교, 시험, 자료를 검색하세요.</div>
            </div>
        </div>
    `;
}


function renderAdminControlCenter() {
    if (typeof renderAppDrawer === 'function') renderAppDrawer();
    const root = document.getElementById('app-root');
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const adminOverviewData = adminBuildOverviewData(todayStr, todayTime);
    const adminGlobalSearchPanel = typeof renderAdminGlobalSearchPanel === 'function' ? renderAdminGlobalSearchPanel() : '';
    const headerHtml = `
        <div class="ap-admin-dashboard-head" style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin:8px 0 10px; padding:0 4px;">
            <div style="min-width:0; padding-top:4px;">
                <h3 style="margin:0; font-size:14px; font-weight:500; color:var(--text);">운영센터</h3>
            </div>
            ${adminGlobalSearchPanel}
        </div>
    `;

    const adminShortcutRow = `
        <div class="ap-admin-shortcuts" style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:18px;">
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#0891b2; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openAttendanceLedger === 'function') openAttendanceLedger(); else toast('불러오기 실패', 'warn');">
                출석부
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#2563eb; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof renderTimetable === 'function') renderTimetable(); else toast('불러오기 실패', 'warn');">
                시간표
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#0f172a; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openSchoolExamLedger === 'function') openSchoolExamLedger(); else toast('불러오기 실패', 'warn');">
                성적표
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#7c3aed; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="openAdminOperationMenu()">
                관리
            </button>
        </div>
    `;

    const todayOverviewHtml = renderAdminStudentOverviewPanel(adminOverviewData);
    const needCheckHtml = renderAdminNeedCheckPanel(adminOverviewData);
    const recentStudentsHtml = renderAdminNewStudentPanel(adminOverviewData);
    const recentConsultationHtml = renderAdminRecentConsultationPanel();

    const teacherCardsHtml = `
        <div class="ap-admin-section" style="margin-bottom:28px;">
            <div style="margin-bottom:12px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:14px; font-weight:500; color:var(--text);">선생님 현황</h3>
            </div>
            <div class="ap-admin-teacher-grid" style="display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:12px; align-items:stretch;">
                ${renderAdminTeacherCards(todayStr)}
            </div>
        </div>
    `;

    const nextWeekTime = todayTime + 7 * 24 * 60 * 60 * 1000;
    const nextWeekStr = new Date(nextWeekTime).toLocaleDateString('sv-SE');
    const adminWeeklyItems = [];

    (state.db.exam_schedules || [])
        .filter(e => e.exam_date >= todayStr && e.exam_date <= nextWeekStr)
        .forEach(e => adminWeeklyItems.push({ type: 'exam', date: e.exam_date, item: e }));

    (state.db.academy_schedules || [])
        .filter(s =>
            String(s.is_deleted || 0) !== '1' &&
            String(s.target_scope || 'global') === 'global' &&
            s.schedule_date >= todayStr &&
            s.schedule_date <= nextWeekStr
        )
        .forEach(s => adminWeeklyItems.push({ type: 'academy', date: s.schedule_date, item: s }));

    adminWeeklyItems.sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));

    const adminScheduleHtml = `
        <div class="ap-admin-section" style="margin-bottom:32px;">
            <h3 class="ap-admin-section-title" style="margin:0 0 12px 0; font-size:14px; font-weight:500; color:var(--secondary);">주간일정</h3>
            <div class="card" style="padding:0; overflow:hidden; border:1px solid var(--border); border-radius:16px; background:var(--surface);">
                ${adminWeeklyItems.length > 0 ? adminWeeklyItems.map(w => {
                    const dateLabel = apFormatMonthDay(w.date) || w.date;
                    if (w.type === 'exam') {
                        const e = w.item;
                        const gradeLabel = e.grade ? `<span style="color:var(--secondary); font-weight:500;">${apEscapeHtml(e.grade)}</span> ` : '<span style="color:var(--secondary); font-weight:500;">학교공통</span> ';
                        return `<div style="display:flex; justify-content:space-between; align-items:center; min-height:52px; padding:0 16px; border-bottom:1px solid var(--border); font-size:13px; gap:10px; box-sizing:border-box;"><div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; font-weight:500; color:var(--error); background:rgba(var(--error-rgb),0.10); padding:3px 8px; border-radius:8px; margin-right:6px;">시험</span><span style="font-weight:500; color:var(--text);">${apEscapeHtml(e.school_name)}</span> ${gradeLabel}${apEscapeHtml(e.exam_name)}</div><div style="color:var(--primary); font-size:11px; font-weight:500; white-space:nowrap; background:var(--primary-soft); padding:2px 8px; border-radius:6px;">${dateLabel}</div></div>`;
                    }
                    const s = w.item;
                    const isClosed = s.schedule_type === 'closed' || s.is_closed === true || s.is_closed === 1;
                    const label = isClosed ? '휴무' : '기타';
                    const labelColor = isClosed ? 'var(--warning)' : 'var(--primary)';
                    const labelBg = isClosed ? 'rgba(var(--warning-rgb),0.12)' : 'var(--primary-soft)';
                    const title = s.title || (isClosed ? '휴무' : '일정');
                    return `<div style="display:flex; justify-content:space-between; align-items:center; min-height:52px; padding:0 16px; border-bottom:1px solid var(--border); font-size:13px; gap:10px; box-sizing:border-box;"><div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; font-weight:500; color:${labelColor}; background:${labelBg}; padding:3px 8px; border-radius:8px; margin-right:6px;">${label}</span><span style="font-weight:500; color:var(--text);">${apEscapeHtml(title)}</span>${s.memo ? ` <span style="color:var(--secondary); font-weight:500;">${apEscapeHtml(s.memo)}</span>` : ''}</div><div style="color:var(--primary); font-size:11px; font-weight:500; white-space:nowrap; background:var(--primary-soft); padding:2px 8px; border-radius:6px;">${dateLabel}</div></div>`;
                }).join('') : `<div style="text-align:center; padding:20px; color:var(--secondary); font-size:13px; font-weight:500;">이번 주 예정된 일정이 없습니다.</div>`}
            </div>
        </div>
    `;
    
    const adminUnifiedStyle = `
        <style>
            #ap-admin-dashboard { width:100%; max-width:850px; margin:0 auto; padding:0 16px 24px; box-sizing:border-box; }
            #ap-admin-dashboard .card,
            #ap-admin-dashboard .ap-admin-card,
            #ap-admin-dashboard .ap-admin-mini-metric,
            #ap-admin-dashboard .ap-admin-check-item,
            #ap-admin-dashboard .ap-admin-search-row {
                border:1px solid var(--border) !important;
                border-radius:16px !important;
                background:var(--surface) !important;
                box-shadow:none !important;
                box-sizing:border-box !important;
            }
            #ap-admin-dashboard .card[onclick],
            #ap-admin-dashboard .ap-admin-card[onclick],
            #ap-admin-dashboard button {
                -webkit-tap-highlight-color:transparent;
            }
            @media (hover:hover) {
                #ap-admin-dashboard .card[onclick]:hover,
                #ap-admin-dashboard .ap-admin-card[onclick]:hover,
                #ap-admin-dashboard .ap-admin-teacher-card:hover {
                    transform:translateY(-1px);
                    border-color:rgba(var(--primary-rgb),0.14) !important;
                }
            }
            #ap-admin-dashboard .ap-admin-section,
            #ap-admin-dashboard .ap-dashboard-section {
                border:0 !important;
                background:transparent !important;
                box-shadow:none !important;
                border-radius:0 !important;
                padding:0 !important;
            }
            #ap-admin-dashboard .ap-admin-shortcuts {
                display:grid !important;
                gap:8px !important;
                padding:4px !important;
                border:1px solid var(--border) !important;
                border-radius:16px !important;
                background:var(--surface-2) !important;
                box-shadow:none !important;
            }
            #ap-admin-dashboard .ap-admin-overview-grid {
                display:grid !important;
                gap:8px !important;
                padding:4px !important;
                border:1px solid var(--border) !important;
                border-radius:16px !important;
                background:var(--surface-2) !important;
                box-shadow:none !important;
            }
            #ap-admin-dashboard .ap-admin-shortcuts {
                grid-template-columns:repeat(4, minmax(0, 1fr));
                margin-bottom:18px !important;
            }
            #ap-admin-dashboard .ap-admin-shortcuts .btn {
                height:44px !important;
                min-height:44px !important;
                max-height:44px !important;
                padding:0 10px !important;
                border-radius:12px !important;
                border:1px solid var(--border) !important;
                background:var(--surface) !important;
                color:var(--text) !important;
                box-shadow:none !important;
                font-size:13px !important;
                font-weight:500 !important;
                line-height:1.2 !important;
            }
            #ap-admin-dashboard .ap-admin-summary-grid,
            #ap-admin-dashboard .ap-admin-teacher-grid {
                align-items:stretch !important;
            }
            #ap-admin-dashboard .ap-admin-summary-grid .card,
            #ap-admin-dashboard .ap-admin-mini-metric {
                min-height:44px !important;
                display:flex !important;
                flex-direction:column !important;
                align-items:center !important;
                justify-content:center !important;
                padding:0 10px !important;
            }
            #ap-admin-dashboard .ap-admin-teacher-grid .card {
                min-height:164px !important;
                height:100% !important;
                display:flex !important;
                flex-direction:column !important;
                justify-content:space-between !important;
                padding:16px !important;
            }
            #ap-admin-dashboard .ap-admin-teacher-card .btn {
                background:var(--surface-2) !important;
                color:var(--text) !important;
                border:1px solid var(--border) !important;
                box-shadow:none !important;
            }
            #ap-admin-dashboard .ap-admin-section { margin-bottom:28px !important; }
            #ap-admin-dashboard .ap-admin-section-title { font-size:14px !important; font-weight:500 !important; letter-spacing:0 !important; }
            #ap-admin-dashboard .ap-admin-dashboard-head {
                position:relative;
            }
            #ap-admin-dashboard .ap-admin-global-search {
                position:relative;
                width:min(420px, 48vw);
                flex:0 1 420px;
                z-index:5;
            }
            #ap-admin-dashboard .ap-admin-global-search__field {
                position:relative;
                height:42px;
                border:1px solid var(--border);
                border-radius:999px;
                background:var(--surface);
                box-shadow:none;
                overflow:hidden;
            }
            #ap-admin-dashboard .ap-admin-global-search__icon {
                position:absolute;
                left:14px;
                top:50%;
                transform:translateY(-50%);
                color:var(--secondary);
                pointer-events:none;
            }
            #ap-admin-dashboard .ap-admin-global-search__results {
                display:none;
                position:absolute;
                top:48px;
                left:0;
                right:0;
                flex-direction:column;
                gap:7px;
                padding:8px;
                border:1px solid var(--border);
                border-radius:16px;
                background:var(--surface);
                box-shadow:0 12px 28px rgba(15,23,42,0.12);
                max-height:320px;
                overflow-y:auto;
            }
            #ap-admin-dashboard .ap-admin-global-search:focus-within .ap-admin-global-search__results {
                display:flex;
            }
            #ap-admin-dashboard .ap-admin-recent-student-grid {
                display:grid !important;
                grid-template-columns:repeat(2, minmax(0, 1fr)) !important;
                gap:1px !important;
                max-height:360px !important;
                overflow:auto !important;
                background:rgba(15,23,42,0.08) !important;
            }
            #ap-admin-dashboard .ap-admin-recent-student-grid > * {
                background:var(--surface) !important;
            }
            #ap-admin-dashboard .ap-admin-recent-student-row:hover {
                background:var(--surface-2) !important;
            }

            #ap-admin-dashboard .ap-admin-overview-grid {
                grid-template-columns:repeat(4, minmax(0, 1fr)) !important;
            }
            @media (max-width:1024px) and (min-width:721px) {
                #ap-admin-dashboard .ap-admin-teacher-grid { grid-template-columns:repeat(2, minmax(0, 1fr)) !important; }
            }
            #ap-admin-dashboard .ap-admin-check-item {
                -webkit-tap-highlight-color:transparent;
            }
            #ap-admin-dashboard .ap-admin-check-grid {
                grid-template-columns:repeat(3, minmax(0, 1fr)) !important;
            }
            @media (max-width:720px) {
                #ap-admin-dashboard .ap-admin-dashboard-head { flex-direction:column !important; align-items:stretch !important; gap:10px !important; }
                #ap-admin-dashboard .ap-admin-global-search { width:100% !important; flex:0 0 auto !important; }
                #ap-admin-dashboard .ap-admin-shortcuts { grid-template-columns:repeat(2, minmax(0, 1fr)) !important; }
                #ap-admin-dashboard .ap-admin-overview-grid { grid-template-columns:repeat(2, minmax(0, 1fr)) !important; }
                #ap-admin-dashboard .ap-admin-teacher-grid { grid-template-columns:1fr !important; }
                #ap-admin-dashboard .ap-admin-recent-student-grid { grid-template-columns:1fr !important; max-height:420px !important; }
                #ap-admin-dashboard .ap-admin-check-grid { grid-template-columns:1fr !important; }
                #ap-admin-dashboard .ap-admin-check-item { min-height:50px !important; }
            }
            @media (max-width:480px) {
                #ap-admin-dashboard { padding-left:14px !important; padding-right:14px !important; }
                #ap-admin-dashboard .ap-admin-shortcuts { gap:6px !important; }
                #ap-admin-dashboard .ap-admin-shortcuts .btn { font-size:12px !important; padding:0 6px !important; }
                #ap-admin-dashboard .ap-admin-summary-grid { gap:8px !important; }
                #ap-admin-dashboard .ap-admin-summary-grid .card { min-height:78px !important; }
            }
        </style>
    `;

    root.innerHTML = `<div id="ap-admin-dashboard">
        ${adminUnifiedStyle}
        ${headerHtml}
        ${adminShortcutRow}
        ${todayOverviewHtml}
        ${teacherCardsHtml}
        ${recentConsultationHtml}
        ${recentStudentsHtml}
        ${needCheckHtml}
        ${adminScheduleHtml}
    </div>`;
}

function renderAdminStudentSearch() {
    const keyword = document.getElementById('admin-search-input').value.trim().toLowerCase();
    const resultArea = document.getElementById('admin-search-results');
    if (!keyword) { resultArea.innerHTML = `<div style="color:var(--secondary); font-size:13px; text-align:center; padding:10px;">검색어를 입력하세요.</div>`; return; }
    
    const results = state.db.students.filter(s => s.name.toLowerCase().includes(keyword));
    if (results.length === 0) { resultArea.innerHTML = `<div style="color:var(--secondary); font-size:13px; text-align:center; padding:10px;">일치하는 학생이 없습니다.</div>`; return; }
    
    resultArea.innerHTML = results.map(s => {
        const cName = state.db.classes.find(c => c.id === state.db.class_students.find(m => m.student_id === s.id)?.class_id)?.name || '미배정';
        return `
            <div style="padding:10px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
                <div><span style="font-size:13px; color:var(--text);; font-weight:500;">${apEscapeHtml(s.name)}</span> <span style="font-size:11px; color:var(--secondary); margin-left:6px;">${apEscapeHtml(cName)} | ${apEscapeHtml(s.status)}</span></div>
                <button class="btn" style="padding:6px 10px; font-size:11px;" onclick="renderStudentDetail('${s.id}')">상세 보기</button>
            </div>
        `;
    }).join('');
}


// --- Teacher Dashboard 공통 함수 ---


























// [Partner B] 필수 입력 제거: 날짜만 있으면 저장 가능




// [Phase 4/5] 글로벌 진입점
function openGlobalExamGradeView() {
    const classes = state.db.classes.filter(c => Number(c.is_active) !== 0);
    const rows = classes.map(c => `
        <button class="btn" style="width:100%; justify-content:space-between; padding:16px; margin-bottom:10px; background:var(--surface); border:1px solid var(--border);" onclick="closeModal(); if(typeof openExamGradeView==='function') openExamGradeView('${c.id}')">
            <span style="font-weight:500; font-size:15px; color:var(--text);">${apEscapeHtml(c.name)}</span>
            <span style="font-size:12px; font-weight:500; color:var(--primary); background:var(--primary-soft); padding:4px 10px; border-radius:8px;">${apEscapeHtml(c.grade)}</span>
        </button>
    `).join('');
    showModal('반별 시험성적', `
        <div style="margin-bottom:16px; font-size:13px; color:var(--secondary); font-weight:500;">조회할 반을 선택하세요.</div>
        <div style="max-height:60vh; overflow-y:auto; padding-right:4px;">${rows || `<div style="text-align:center; color:var(--secondary); padding:30px; font-size:13px; font-weight:500;">담당 반이 없습니다.</div>`}</div>
    `);
}

function openOperationMenu() {
    const isOnline = navigator.onLine;
    const qLen = typeof syncQueue !== 'undefined' ? syncQueue.length : 0;
    const syncStatusText = qLen > 0 ? `대기 ${qLen}건` : '대기 없음';
    const onlineStatusText = isOnline ? '연결됨' : '오프라인';

    showModal('시스템·동기화 상태', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="padding:16px; border-radius:14px; background:var(--surface-2); border:none;">
                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:500; margin-bottom:8px; color:var(--secondary);"><span>네트워크</span><span style="color:${isOnline ? 'var(--success)' : 'var(--error)'}; font-weight:500;">${onlineStatusText}</span></div>
                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:500; margin-bottom:16px; color:var(--secondary);"><span>미전송 데이터</span><span style="color:${qLen > 0 ? 'var(--warning)' : 'var(--success)'}; font-weight:500;">${syncStatusText}</span></div>
                <button class="btn btn-primary" style="width:100%; font-size:14px; font-weight:500; padding:12px; border-radius:10px;" onclick="if(typeof processSyncQueue==='function') processSyncQueue(); closeModal();">지금 동기화 시도</button>
            </div>
        </div>
    `);
}

function getClassGradeRank(grade) {
    const order = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const idx = order.indexOf(grade);
    return idx >= 0 ? idx : 99;
}

function sortClassesForDashboard(classes) {
    return [...classes].sort((a, b) => {
        const aToday = isClassScheduledTodayForDashboard(a.id) ? 0 : 1;
        const bToday = isClassScheduledTodayForDashboard(b.id) ? 0 : 1;
        if (aToday !== bToday) return aToday - bToday;
        const aRank = getClassGradeRank(a.grade);
        const bRank = getClassGradeRank(b.grade);
        if (aRank !== bRank) return aRank - bRank;
        return (a.name || '').localeCompare(b.name || '');
    });
}

function computeDashboardData() {
    const today = new Date().toLocaleDateString('sv-SE');
    const activeStudents = state.db.students.filter(s => s.status === '재원');
    
    const scheduledActiveStudents = activeStudents.filter(s => {
        const cid = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const cls = state.db.classes.find(c => c.id === cid);
        if (cls && Number(cls.is_active) === 0) return false;
        return isClassScheduledTodayForDashboard(cid);
    });
    
    const scheduledIds = new Set(scheduledActiveStudents.map(s => s.id));
    
    const absentCount = state.db.attendance.filter(a => a.date === today && a.status === '결석' && scheduledIds.has(a.student_id)).length;
    const presentCount = scheduledActiveStudents.length - absentCount;
    
    const hwNotDoneCount = state.db.homework.filter(h => h.date === today && h.status === '미완료' && scheduledIds.has(h.student_id)).length;

    const todoCount = state.db.operation_memos.filter(m => {
        const isDone = m.is_done == 1 || m.is_done === true;
        const isPinned = m.is_pinned == 1 || m.is_pinned === true;
        return !isDone && (isPinned || m.memo_date === today);
    }).length;

    const classSummaries = {};
    state.db.classes.filter(c => Number(c.is_active) !== 0).forEach(c => {
        const cIds = state.db.class_students.filter(m => m.class_id === c.id).map(m => m.student_id);
        const cActiveIds = activeStudents.filter(s => cIds.includes(s.id)).map(s => s.id);
        let cMiss=0, cAbs=0;
        
        cActiveIds.forEach(id => {
            const att = state.db.attendance.find(a => a.student_id===id && a.date===today);
            if (att?.status === '결석') cAbs++;
            
            const hw = state.db.homework.find(h => h.student_id===id && h.date===today);
            if (hw?.status === '미완료') cMiss++;
        });
        
        let cPre = cActiveIds.length - cAbs;
        classSummaries[c.id] = { activeCount: cActiveIds.length, present: cPre, absent: cAbs, hwNotDone: cMiss, isScheduled: isClassScheduledTodayForDashboard(c.id) };
    });

    return { 
        global: { 
            totalActive: activeStudents.length, 
            scheduledActive: scheduledActiveStudents.length, 
            presentCount, 
            absentCount, 
            hwNotDoneCount,
            todoCount
        }, 
        classSummaries 
    };
}

function openDashboardClass(cid) {
    const safeCid = String(cid || '');
    if (!safeCid) {
        toast('학급 정보를 찾을 수 없습니다.', 'warn');
        return;
    }

    if (!state.ui) state.ui = {};
    state.ui.currentClassId = safeCid;

    if (typeof renderClass === 'function') {
        renderClass(safeCid);
        return;
    }

    if (typeof window !== 'undefined' && typeof window.renderClass === 'function') {
        window.renderClass(safeCid);
        return;
    }

    console.error('[AP Math OS] renderClass is not available. classroom.js load/order check required.', safeCid);
    toast('학급 화면 모듈을 불러오지 못했습니다.', 'error');
}

// [POLISH] 학급 카드: 수평적 미니멀리즘 레이아웃
function renderClassSummaryCard(cls, data) {
    const s = data.classSummaries[cls.id];
    if (!s) return '';

    const safeCid = dashboardEscapeAttr(cls.id);
    const safeName = apEscapeHtml(cls.name || '');

    if (!s.isScheduled) {
        return `
            <div class="ap-class-row ap-class-row--empty" onclick="openDashboardClass('${safeCid}')">
                <div class="ap-class-row__name ap-class-row__name--inactive">${safeName}</div>
                <div class="ap-class-row__meta">수업 없음</div>
            </div>
        `;
    }

    return `
        <div class="ap-class-row ap-class-row--scheduled" onclick="openDashboardClass('${safeCid}')">
            <div class="ap-class-row__name">${safeName}</div>
            <div class="ap-class-row__chips" aria-label="${safeName} 출결 요약">
                <span class="ap-class-chip">재원 ${apEscapeHtml(String(s.activeCount))}</span>
                <span class="ap-class-chip">등원 ${apEscapeHtml(String(s.present))}</span>
                <span class="ap-class-chip">결석 ${apEscapeHtml(String(s.absent))}</span>
            </div>
        </div>
    `;
}

// [POLISH] 일정 섹션: 오렌지(오늘) vs 보라(주간) 은은한 컬러 분리
function renderTodoSections() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const nextWeekTime = todayTime + 7 * 24 * 60 * 60 * 1000;
    const nextWeekStr = new Date(nextWeekTime).toLocaleDateString('sv-SE');
    const getMemoDate = (m) => String(m.memo_date || m.memoDate || m.date || '').split('T')[0].split(' ')[0];
    const isMemoDone = (m) => m.is_done == 1 || m.is_done === true || m.isDone === true;
    const isMemoPinned = (m) => m.is_pinned == 1 || m.is_pinned === true || m.isPinned === true;

    const rowBase = `
        height:52px;
        min-height:52px;
        max-height:52px;
        padding:0 16px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        box-sizing:border-box;
        overflow:hidden;
    `;

    const todayMemos = state.db.operation_memos.filter(m => {
        const memoDate = getMemoDate(m);
        return !isMemoDone(m) && (isMemoPinned(m) || memoDate === todayStr);
    });
    
    const upcomingExams = state.db.exam_schedules.filter(e => e.exam_date >= todayStr && e.exam_date <= nextWeekStr);
    const upcomingAcademySchedules = (state.db.academy_schedules || []).filter(s =>
        String(s.is_deleted || 0) !== '1' &&
        String(s.target_scope || 'global') === 'global' &&
        s.schedule_date >= todayStr &&
        s.schedule_date <= nextWeekStr
    );

    const todayHtml = todayMemos.length ? todayMemos.map(m => {
        const isPinned = isMemoPinned(m);
        return `
        <div style="${rowBase} border-bottom:1px solid rgba(99,102,241,0.1); background:transparent;">
            <label onclick="event.stopPropagation()" style="display:flex; align-items:center; gap:12px; flex:1; min-width:0; cursor:pointer;">
                <input type="checkbox" onclick="event.stopPropagation()" onchange="toggleMemoDone('${m.id}', this.checked)" style="transform:scale(1.15); margin:0; accent-color:#6366f1; flex-shrink:0;">
                <span style="font-size:13px; font-weight:400; color:var(--text); ${isPinned ? 'color:var(--primary);' : ''} white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    ${isPinned ? `<span style="background:var(--primary-soft); padding:2px 6px; border-radius:10px; font-size:11px; margin-right:6px;">고정</span> ` : ''}${apEscapeHtml(m.content)}
                </span>
            </label>
        </div>
    `}).join('') : `<div style="${rowBase} justify-content:center; font-size:13px; font-weight:400; color:var(--secondary); text-align:center;">오늘 등록된 할 일이 없습니다.</div>`;

    let upcomingHtml = '';
    const upcomingItems = [];
    upcomingExams.forEach(e => upcomingItems.push({ type: 'exam', date: e.exam_date, item: e }));
    upcomingAcademySchedules.forEach(s => upcomingItems.push({ type: 'academy', date: s.schedule_date, item: s }));
    
    upcomingItems.sort((a,b) => a.date.localeCompare(b.date));

    if (upcomingItems.length) {
        upcomingHtml = upcomingItems.slice(0, 5).map(u => {
            const timeVal = apParseLocalDateTime(u.date);
            const diffTime = timeVal !== null ? (timeVal - todayTime) : 0;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const dDay = diffDays === 0 ? 'D-Day' : `D-${diffDays}`;

            if (u.type === 'exam') {
                const e = u.item;
                const displayTitle = e.exam_name ? `${apEscapeHtml(e.school_name || '일반')} ${apEscapeHtml(e.grade || '')} ${apEscapeHtml(e.exam_name)}` : `${apEscapeHtml(e.school_name || '일정 확인')}`;
                return `<div onclick="event.stopPropagation(); openExamScheduleModal()" style="${rowBase} cursor:pointer; font-size:13px; font-weight:400; color:var(--text); border-bottom:1px solid rgba(5,150,105,0.08); background:transparent;">
                    <div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${displayTitle}</div>
                    <span style="font-size:12px; color:#059669; background:rgba(5,150,105,0.08); padding:3px 8px; border-radius:10px; font-weight:400; white-space:nowrap; flex-shrink:0;">${dDay}</span>
                </div>`;
            }

            const s = u.item;
            const isClosed = s.schedule_type === 'closed' || s.is_closed === true || s.is_closed === 1;
            const label = isClosed ? '휴무' : '기타';
            const labelColor = isClosed ? 'var(--warning)' : 'var(--primary)';
            const labelBg = isClosed ? 'rgba(var(--warning-rgb),0.12)' : 'var(--primary-soft)';
            const title = s.title || (isClosed ? '휴무' : '일정');
            return `<div onclick="event.stopPropagation(); openExamScheduleModal()" style="${rowBase} cursor:pointer; font-size:13px; font-weight:400; color:var(--text); border-bottom:1px solid rgba(5,150,105,0.08); background:transparent;">
                <div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; color:${labelColor}; background:${labelBg}; padding:3px 8px; border-radius:8px; margin-right:6px;">${label}</span>${apEscapeHtml(title)}${s.memo ? ` <span style="color:var(--secondary); font-weight:400;">${apEscapeHtml(s.memo)}</span>` : ''}</div>
                <span style="font-size:12px; background:rgba(5,150,105,0.08); color:#059669; padding:3px 8px; border-radius:10px; font-weight:400; white-space:nowrap; flex-shrink:0;">${dDay}</span>
            </div>`;
        }).join('');
    }

    return `
        <div style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 style="margin:0; font-size:14px; font-weight:500; color:var(--text);">오늘일정</h3>
            </div>
            <div onclick="openTodoMemoModal()" style="cursor:pointer; margin-bottom:18px; overflow:hidden; border-radius:16px; border:1px solid rgba(99,102,241,0.2); background:rgba(99,102,241,0.04);">
                ${todayHtml}
            </div>
            
            ${upcomingHtml ? `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                    <h3 style="margin:0; font-size:14px; font-weight:500; color:var(--text);">주간일정</h3>
                </div>
                <div onclick="openExamScheduleModal()" style="cursor:pointer; overflow:hidden; border-radius:16px; border:1px solid rgba(5,150,105,0.2); background:rgba(5,150,105,0.04);">
                    ${upcomingHtml}
                </div>
            ` : ''}
        </div>
    `;
}

// [NEW] 오늘일지 카드 생성 함수 (요일 필터 정밀 적용)

function renderTodayJournalCard(data) {
    injectDashboardOpsStyles();
    const todayClasses = (state?.db?.classes || []).filter(c => {
        if (Number(c?.is_active) === 0) return false;
        if (!isMiddleSchoolClass(c)) return false;
        if (!isClassVisibleForCurrentTeacher(c)) return false;

        const summary = data?.classSummaries?.[c.id];
        if (!summary || !summary.isScheduled || summary.activeCount === 0) return false;
        return true;
    });

    const contentHtml = todayClasses.length === 0
        ? '수업 없음'
        : todayClasses.map(c => `${apEscapeHtml(c.name)} ${data.classSummaries[c.id].present}/${data.classSummaries[c.id].activeCount}`).join(' · ');

    return `
        <div class="ap-dashboard-section ap-dashboard-journal-section ap-dashboard-journal-section--teacher">
            <div class="ap-dashboard-journal-head">
                <h3 class="ap-dashboard-journal-title">오늘일지</h3>
                <span id="dashboard-journal-content" class="ap-dashboard-journal-summary">${contentHtml}</span>
            </div>
            <div id="dashboard-journal-card" class="ap-dashboard-journal-body" onclick="if(typeof openDailyJournalModal === 'function') openDailyJournalModal(); else toast('불러오기 실패', 'warn');">
                ${renderDashboardJournalWeekMatrix('', new Date().toLocaleDateString('sv-SE'))}
            </div>
        </div>
    `;
}


// [POLISH] 메인 대시보드: 제목 규격화 및 마감 배너 시각적 축소
function ensureDashboardOnboardingState() {
    if (!state.ui) state.ui = {};
    if (!state.ui.dashboardOnboardingTasks) {
        state.ui.dashboardOnboardingTasks = { loading: false, loadedAt: 0, tasks: [], inFlight: null, selectedTaskId: '', pendingSkipTaskId: '', draft: {}, error: '' };
    }
    if (!state.ui.dashboardOnboardingTasks.draft) state.ui.dashboardOnboardingTasks.draft = {};
    return state.ui.dashboardOnboardingTasks;
}

async function fetchOnboardingTasks() {
    const store = ensureDashboardOnboardingState();
    if (store.inFlight) return store.inFlight;
    store.loading = true;
    const promise = api.get('onboarding/tasks')
        .then(res => {
            store.tasks = Array.isArray(res?.tasks) ? res.tasks : [];
            store.loadedAt = Date.now();
            return store.tasks;
        })
        .catch(err => {
            console.error('[fetchOnboardingTasks] failed:', err);
            store.tasks = [];
            return [];
        })
        .finally(() => {
            store.loading = false;
            store.inFlight = null;
        });
    store.inFlight = promise;
    return promise;
}

function getOnboardingTaskLabel(task) {
    const type = String(task?.task_type || '');
    if (type === 'intro') return '담임 인사';
    if (type === 'week1') return '1주차 적응 확인';
    if (type === 'month1') return '1개월 정착 상담';
    return '';
}

function getOnboardingTaskDescription(task) {
    const type = String(task?.task_type || '');
    if (type === 'intro') return '첫 수업 전후로 학부모님께 짧게 첫인사를 건네주세요.';
    if (type === 'week1') return '첫 주 수업 태도와 숙제 흐름을 가볍게 확인해 주세요.';
    if (type === 'month1') return '한 달간의 적응 상태와 다음 달 공부 방향을 정리해 주세요.';
    return '';
}

function getOnboardingStatusLabel(status) {
    const key = String(status || '');
    if (key === 'needs_action') return '확인 전';
    if (key === 'contacted') return '연락 남김';
    if (key === 'deferred') return '나중에 다시 보기';
    return '확인 전';
}

function getOnboardingDraft(taskId) {
    const store = ensureDashboardOnboardingState();
    const key = String(taskId || '');
    if (!store.draft[key]) store.draft[key] = {};
    return store.draft[key];
}

function getSelectedOnboardingTask() {
    const store = ensureDashboardOnboardingState();
    return (store.tasks || []).find(task => String(task?.id || '') === String(store.selectedTaskId || '')) || null;
}

function openOnboardingTask(taskId) {
    const store = ensureDashboardOnboardingState();
    store.selectedTaskId = String(taskId || '');
    store.pendingSkipTaskId = '';
    store.error = '';
    getOnboardingDraft(taskId);
    updateDashboardOnboardingTasksSection();
}

function closeOnboardingTaskPanel() {
    const store = ensureDashboardOnboardingState();
    store.selectedTaskId = '';
    store.pendingSkipTaskId = '';
    store.error = '';
    updateDashboardOnboardingTasksSection();
}

function updateOnboardingDraft(taskId, key, value) {
    const draft = getOnboardingDraft(taskId);
    draft[key] = value;
    const message = document.getElementById('onboarding-parent-copy-message');
    const task = getSelectedOnboardingTask();
    if (message && task) message.textContent = buildOnboardingParentMessage(task, draft);
}

function onboardingSelectHtml(task, key, options) {
    const selected = String(getOnboardingDraft(task.id)[key] || '');
    return `<select class="std-input-base" style="min-height:40px; font-size:13px;" onchange="updateOnboardingDraft('${apEscapeHtml(String(task.id || ''))}', '${key}', this.value)"><option value=""></option>${options.map(option => `<option value="${apEscapeHtml(option)}" ${selected === option ? 'selected' : ''}>${apEscapeHtml(option)}</option>`).join('')}</select>`;
}

function onboardingTextareaHtml(task, key, placeholder = '') {
    return `<textarea class="std-input-base" style="height:74px; font-size:13px; line-height:1.5;" placeholder="${apEscapeHtml(placeholder)}" oninput="updateOnboardingDraft('${apEscapeHtml(String(task.id || ''))}', '${key}', this.value)">${apEscapeHtml(getOnboardingDraft(task.id)[key] || '')}</textarea>`;
}

function replaceOnboardingTokens(text, task, draft = {}) {
    const teacherName = state?.ui?.userName || state?.auth?.name || task?.teacher_name || '[선생님명]';
    const pairs = {
        '[반명]': task?.class_name || '[반명]',
        '[선생님명]': teacherName || '[선생님명]',
        '[학생명]': task?.student_name || '[학생명]',
        '[확인할 부분]': draft.check_point || '[확인할 부분]',
        '[좋았던 부분]': draft.good_point || '[좋았던 부분]',
        '[더 볼 부분]': draft.focus_point || '[더 볼 부분]',
        '[다음 달 공부 방향]': draft.next_month_plan || '[다음 달 공부 방향]'
    };
    let result = text;
    Object.entries(pairs).forEach(([key, value]) => { result = result.split(key).join(value); });
    return result;
}

function getOnboardingParentMessageTemplate(task) {
    const type = String(task?.task_type || '');
    if (type === 'intro') return `안녕하세요, 어머니! AP수학 [반명] 담임 [선생님명]선생님입니다.

오늘부터 [학생명] 학생 수업을 맡게 되어 반가운 마음에 먼저 인사드립니다.

처음에는 학원 시스템이나 숙제 방식에 익숙해지는 시간이 조금 필요할 수 있습니다. 첫 1~2주 동안은 아이가 낯설어하지 않고 학원 흐름에 잘 적응하는지 옆에서 세심하게 같이 살펴보겠습니다.

혹시 학원에 오기 전 수학 공부를 하면서 힘들어했던 부분이나, 담임인 제가 미리 알고 있으면 도움 될 만한 점이 있다면 편하게 말씀해 주세요. 앞으로 잘 지도하겠습니다. 감사합니다.`;
    if (type === 'week1') return `어머니, 담임 [선생님명]선생님입니다. [학생명] 학생이 AP수학에서 첫 일주일간의 수업을 무사히 마쳤습니다.

새로운 환경이라 긴장했을 텐데도 수업 참여와 숙제 흐름을 차분하게 잘 따라와 주었습니다. 이번 주 수업을 바탕으로 앞으로는 [확인할 부분] 영역을 조금 더 신경 써서 살펴볼 예정입니다.

혹시 일주일 동안 등원하면서 아이가 집에서 학원 얘기나 수학 공부에 대해 부담스러워하는 기색은 없었는지 궁금합니다. 집에서 느끼신 점이 있다면 언제든 편하게 말씀해 주세요. 다음 수업도 잘 이어가겠습니다.`;
    return `어머니, [학생명] 학생이 저희와 함께 수업을 시작한 지 벌써 한 달이 되었습니다. 학원 시스템과 학습 루틴에는 이제 제법 편안하게 적응한 모습입니다.

한 달간 지켜보니 [좋았던 부분]은 참 기특하고 긍정적입니다. 다만 [더 볼 부분]이 눈에 밟혀, 다음 달 수업에서는 이 부분을 보완하는 데 집중하려고 합니다.

앞으로는 [다음 달 공부 방향]을 중심으로 성실하게 지도하겠습니다. 한 달 동안 믿고 보내주셔서 감사드리며, 궁금한 점이 있으시면 언제든 편하게 말씀해 주세요.`;
}

function buildOnboardingParentMessage(task, draft = {}) {
    return replaceOnboardingTokens(getOnboardingParentMessageTemplate(task), task, draft);
}

async function copyOnboardingParentMessage(taskId) {
    const task = getSelectedOnboardingTask();
    if (!task) return;
    const text = buildOnboardingParentMessage(task, getOnboardingDraft(taskId));
    try {
        if (navigator?.clipboard?.writeText) await navigator.clipboard.writeText(text);
        else {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            textarea.remove();
        }
        if (typeof toast === 'function') toast('복사되었습니다.', 'success');
    } catch (err) {
        console.error('[copyOnboardingParentMessage] failed:', err);
    }
}

function onboardingPanelField(label, body) {
    return `<div style="display:flex; flex-direction:column; gap:6px;"><div style="font-size:12px; color:var(--secondary); font-weight:500; line-height:1.4;">${apEscapeHtml(label)}</div>${body}</div>`;
}

function renderOnboardingPanelFields(task) {
    const type = String(task?.task_type || '');
    if (type === 'intro') return `${onboardingPanelField('연락 방법', onboardingSelectHtml(task, 'contact_method', ['문자', '카톡', '전화', '대면']))}${onboardingPanelField('메모', onboardingTextareaHtml(task, 'notes'))}`;
    if (type === 'week1') return `${onboardingPanelField('수업 시간의 몰입도는 어땠나요?', onboardingSelectHtml(task, 'lesson_adaptation_status', ['양호', '보통', '조금 더 지켜보기']))}${onboardingPanelField('첫 주 숙제 분량은 적절히 해왔나요?', onboardingSelectHtml(task, 'homework_adaptation_status', ['잘해옴', '노력 중', '어려워함']))}${onboardingPanelField('확인할 부분', onboardingTextareaHtml(task, 'check_point'))}${onboardingPanelField('메모', onboardingTextareaHtml(task, 'notes'))}`;
    return `${onboardingPanelField('한 달간 담임 선생님이 바라본 아이의 모습', onboardingTextareaHtml(task, 'month_summary', '한 달간 수업 흐름과 칭찬할 점을 적어주세요.'))}${onboardingPanelField('다음 달에 중점적으로 신경 쓸 부분', onboardingTextareaHtml(task, 'next_month_plan', '진도 속도 조절, 오답 보완, 태도 교정 등 계획을 적어주세요.'))}`;
}

function getOnboardingPanelGuide(task) {
    const type = String(task?.task_type || '');
    if (type === 'intro') return { purpose: '신입생과 학부모님이 학원에 처음 안착하는 가장 중요한 첫 단추입니다. 가볍게 인사를 건네어 긴장감을 풀어주세요.', guide: '아이의 첫 수업 요일과 시간대를 한 번 더 확인하셨나요?\\n첫 수업에 필요한 교재나 필기구가 잘 준비되었는지 조용히 체크해 주세요.' };
    if (type === 'week1') return { purpose: '아이가 첫 주 수업을 들으며 학원 시스템과 수업 분위기에 무리 없이 적응하고 있는지 확인하는 단계입니다.', guide: '전화나 카톡으로 집에서의 아이 반응을 가볍게 물어보시면, 학부모님의 불안감을 낮추는 데 큰 도움이 됩니다.' };
    return { purpose: '한 달간 누적된 출결, 숙제, 테스트 흐름을 바탕으로 앞으로 이 아이가 우리 반에서 어떻게 공부를 이어가면 좋을지 방향을 잡아주는 시점입니다.', guide: '한 달간 수업 흐름과 칭찬할 점을 적어주세요.\\n진도 속도 조절, 오답 보완, 태도 교정 등 계획을 적어주세요.' };
}

function buildOnboardingActionPayload(task) {
    const draft = getOnboardingDraft(task.id);
    return {
        contact_method: draft.contact_method || '',
        notes: draft.notes || draft.check_point || '',
        lesson_adaptation_status: draft.lesson_adaptation_status || '',
        homework_adaptation_status: draft.homework_adaptation_status || '',
        month_summary: draft.month_summary || '',
        next_month_plan: draft.next_month_plan || '',
        good_point: draft.good_point || '',
        focus_point: draft.focus_point || ''
    };
}

async function refreshOnboardingTasksAfterAction(closePanel = false) {
    const store = ensureDashboardOnboardingState();
    store.inFlight = null;
    await fetchOnboardingTasks();
    if (closePanel) store.selectedTaskId = '';
    store.pendingSkipTaskId = '';
    updateDashboardOnboardingTasksSection();
}

function setOnboardingPanelError(message) {
    const store = ensureDashboardOnboardingState();
    store.error = message || '';
    updateDashboardOnboardingTasksSection();
}

function openOnboardingSkipConfirm(taskId) {
    const store = ensureDashboardOnboardingState();
    store.pendingSkipTaskId = String(taskId || '');
    store.error = '';
    updateDashboardOnboardingTasksSection();
}

function closeOnboardingSkipConfirm() {
    const store = ensureDashboardOnboardingState();
    store.pendingSkipTaskId = '';
    updateDashboardOnboardingTasksSection();
}

async function confirmOnboardingSkip(taskId) {
    closeOnboardingSkipConfirm();
    await handleOnboardingAction(taskId, 'skip');
}

async function handleOnboardingAction(taskId, action) {
    const task = (ensureDashboardOnboardingState().tasks || []).find(row => String(row?.id || '') === String(taskId || ''));
    if (!task) return;
    const payload = buildOnboardingActionPayload(task);
    try {
        if (action === 'patch') {
            const result = await api.patch(`onboarding/tasks/${taskId}`, payload);
            if (result?.success) await refreshOnboardingTasksAfterAction(false);
            return;
        }
        if (action === 'complete') {
            const result = await api.post(`onboarding/tasks/${taskId}/complete`, payload);
            if (result?.success) await refreshOnboardingTasksAfterAction(true);
            return;
        }
        if (action === 'contact') {
            const result = await api.post(`onboarding/tasks/${taskId}/contact`, payload);
            if (result?.success) await refreshOnboardingTasksAfterAction(false);
            return;
        }
        if (action === 'defer') {
            const result = await api.post(`onboarding/tasks/${taskId}/defer`, payload);
            if (result?.success) await refreshOnboardingTasksAfterAction(true);
            return;
        }
        if (action === 'skip') {
            const result = await api.post(`onboarding/tasks/${taskId}/skip`, payload);
            if (result?.success) await refreshOnboardingTasksAfterAction(true);
        }
    } catch (err) {
        console.error('[handleOnboardingAction] failed:', err);
    }
}

function renderOnboardingSkipConfirm() {
    const store = ensureDashboardOnboardingState();
    if (!store.pendingSkipTaskId) return '';
    const taskId = apEscapeHtml(String(store.pendingSkipTaskId || ''));
    return `<div class="ap-onboarding-confirm-backdrop" style="position:fixed; inset:0; z-index:90; background:rgba(15,23,42,0.28); display:flex; align-items:center; justify-content:center; padding:18px;"><section class="ap-onboarding-confirm" role="dialog" aria-modal="true" style="width:min(380px, 100%); background:var(--surface); border:1px solid var(--border); border-radius:14px; box-shadow:0 20px 50px rgba(15,23,42,0.2); padding:18px; display:flex; flex-direction:column; gap:12px;"><h3 style="margin:0; font-size:16px; color:var(--text); font-weight:600; line-height:1.4;">이 단계를 기록하지 않고 넘어갈까요?</h3><div style="font-size:13px; color:var(--secondary); font-weight:500; line-height:1.65; white-space:pre-wrap;">학부모님과 이미 다른 방식으로 소통하셨거나, 현재 단계의 안내가 필요 없는 경우 사용해 주세요.\n이 단계를 넘기면 적응 확인 카드에서 조용히 사라지며, 별도의 상담 기록은 남지 않습니다.</div><div style="display:flex; gap:8px; justify-content:flex-end;"><button type="button" class="btn apms-button apms-button--quiet" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="closeOnboardingSkipConfirm()">취소</button><button type="button" class="btn btn-primary apms-button apms-button--primary" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="confirmOnboardingSkip('${taskId}')">이번 단계 넘기기</button></div></section></div>`;
}

function renderOnboardingPanel() {
    const store = ensureDashboardOnboardingState();
    const task = getSelectedOnboardingTask();
    if (!task) return renderOnboardingSkipConfirm();
    const draft = getOnboardingDraft(task.id);
    const guide = getOnboardingPanelGuide(task);
    const status = getOnboardingStatusLabel(task?.effective_status || task?.status);
    const type = String(task?.task_type || '');
    const completeText = type === 'intro' ? '인사 완료하기' : type === 'week1' ? '저장하고 완료하기' : '상담 완료하기';
    const saveButton = type === 'month1' ? `<button type="button" class="btn apms-button apms-button--quiet" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="handleOnboardingAction('${apEscapeHtml(String(task.id || ''))}', 'patch')">저장하기</button>` : '';
    const contactButton = type !== 'intro' ? `<button type="button" class="btn apms-button apms-button--quiet" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="handleOnboardingAction('${apEscapeHtml(String(task.id || ''))}', 'contact')">연락만 남기기</button>` : '';
    return `<div class="ap-onboarding-panel-backdrop" style="position:fixed; inset:0; z-index:80; background:rgba(15,23,42,0.18);" onclick="closeOnboardingTaskPanel()"></div><aside class="ap-onboarding-panel" style="position:fixed; top:0; right:0; bottom:0; z-index:81; width:min(440px, 100vw); background:var(--surface); border-left:1px solid var(--border); box-shadow:-12px 0 30px rgba(15,23,42,0.14); display:flex; flex-direction:column;"><div style="padding:18px 18px 12px; border-bottom:1px solid var(--border); display:flex; gap:12px; justify-content:space-between; align-items:flex-start;"><div style="min-width:0;"><div style="font-size:15px; font-weight:500; color:var(--text); line-height:1.4; overflow-wrap:anywhere;">${apEscapeHtml(task.student_name || '')}</div><div style="font-size:12px; color:var(--secondary); font-weight:500; line-height:1.5; margin-top:3px;">${apEscapeHtml(task.class_name || '')}</div><div style="font-size:14px; color:var(--text); font-weight:500; line-height:1.4; margin-top:8px;">${apEscapeHtml(getOnboardingTaskLabel(task))}</div></div><div style="display:flex; align-items:center; gap:8px;"><span style="min-height:24px; display:inline-flex; align-items:center; padding:0 8px; border-radius:999px; background:var(--surface-2); color:var(--secondary); border:1px solid var(--border); font-size:11px; font-weight:500;">${apEscapeHtml(status)}</span><button type="button" class="btn apms-button apms-button--quiet" style="width:34px; height:34px; min-height:34px; padding:0; border-radius:10px;" onclick="closeOnboardingTaskPanel()">×</button></div></div><div style="padding:16px 18px 18px; overflow:auto; display:flex; flex-direction:column; gap:14px;">${onboardingPanelField('목적 안내', `<div style="font-size:13px; color:var(--text); font-weight:500; line-height:1.65; white-space:pre-wrap;">${apEscapeHtml(guide.purpose)}</div>`)}${onboardingPanelField('확인 가이드', `<div style="font-size:13px; color:var(--text); font-weight:500; line-height:1.65; white-space:pre-wrap;">${apEscapeHtml(guide.guide)}</div>`)}${renderOnboardingPanelFields(task)}<section style="display:flex; flex-direction:column; gap:8px;"><div style="display:flex; align-items:center; justify-content:space-between; gap:10px;"><div style="font-size:12px; color:var(--secondary); font-weight:500; line-height:1.4;">학부모 복사 문구</div><button type="button" class="btn apms-button apms-button--quiet" style="min-height:32px; padding:6px 10px; border-radius:10px; font-size:11px;" onclick="copyOnboardingParentMessage('${apEscapeHtml(String(task.id || ''))}')">복사하기</button></div><div id="onboarding-parent-copy-message" style="padding:12px; border:1px solid var(--border); border-radius:12px; background:var(--surface-2); color:var(--text); font-size:12px; font-weight:500; line-height:1.65; white-space:pre-wrap;">${apEscapeHtml(buildOnboardingParentMessage(task, draft))}</div></section>${store.error ? `<div style="font-size:12px; color:var(--primary); font-weight:500; line-height:1.5;">${apEscapeHtml(store.error)}</div>` : ''}</div><div style="padding:12px 18px 18px; border-top:1px solid var(--border); display:grid; grid-template-columns:1fr; gap:8px;"><button type="button" class="btn apms-button apms-button--quiet" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="openOnboardingSkipConfirm('${apEscapeHtml(String(task.id || ''))}')">이번 단계 넘기기</button>${contactButton}${saveButton}<button type="button" class="btn apms-button apms-button--quiet" style="min-height:38px; border-radius:10px; font-size:12px;" onclick="handleOnboardingAction('${apEscapeHtml(String(task.id || ''))}', 'defer')">나중에 다시 보기</button><button type="button" class="btn btn-primary apms-button apms-button--primary" style="min-height:42px; border-radius:10px; font-size:13px; font-weight:500;" onclick="handleOnboardingAction('${apEscapeHtml(String(task.id || ''))}', 'complete')">${apEscapeHtml(completeText)}</button></div></aside>${renderOnboardingSkipConfirm()}`;
}

function renderOnboardingTasks(tasks = []) {
    const visibleTasks = (Array.isArray(tasks) ? tasks : []).filter(task => !['completed', 'skipped'].includes(String(task?.status || ''))).sort((a, b) => String(a?.due_date || '').localeCompare(String(b?.due_date || '')) || Number(a?.task_order || 0) - Number(b?.task_order || 0) || String(a?.student_name || '').localeCompare(String(b?.student_name || ''), 'ko'));
    const cards = visibleTasks.map(task => {
        const title = getOnboardingTaskLabel(task);
        const description = getOnboardingTaskDescription(task);
        const status = getOnboardingStatusLabel(task?.effective_status || task?.status);
        return `<div class="card apms-card ap-dashboard-onboarding-card" style="padding:14px; border:1px solid var(--border); border-radius:14px; box-shadow:none; background:var(--surface); display:flex; flex-direction:column; gap:10px;"><div style="display:flex; align-items:flex-start; justify-content:space-between; gap:10px;"><div style="min-width:0;"><div style="font-size:13px; font-weight:500; color:var(--text); line-height:1.35; overflow-wrap:anywhere;">${apEscapeHtml(task?.student_name || '')}</div><div style="font-size:11px; font-weight:500; color:var(--secondary); line-height:1.45; margin-top:2px; overflow-wrap:anywhere;">${apEscapeHtml(task?.class_name || '')}</div></div><span style="flex:0 0 auto; min-height:24px; display:inline-flex; align-items:center; padding:0 8px; border-radius:999px; background:var(--surface-2); color:var(--secondary); border:1px solid var(--border); font-size:11px; font-weight:500;">${apEscapeHtml(status)}</span></div><div><div style="font-size:14px; font-weight:500; color:var(--text); line-height:1.35;">${apEscapeHtml(title)}</div><div style="font-size:12px; font-weight:500; color:var(--secondary); line-height:1.55; margin-top:4px;">${apEscapeHtml(description)}</div></div><button type="button" class="btn apms-button apms-button--quiet" style="width:100%; min-height:38px; border-radius:10px; font-size:12px; font-weight:500;" onclick="openOnboardingTask('${apEscapeHtml(String(task?.id || ''))}')">확인하기</button></div>`;
    }).join('');
    const section = visibleTasks.length ? `<div class="ap-dashboard-section ap-dashboard-onboarding-section" style="margin-bottom:18px;"><div class="ap-dashboard-section-head" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding:0 4px;"><h3 style="margin:0; font-size:14px; font-weight:500; color:var(--text);">신입생 적응 확인</h3></div><div class="ap-dashboard-onboarding-list" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:10px;">${cards}</div></div>` : '';
    return `${section}${renderOnboardingPanel()}`;
}

function updateDashboardOnboardingTasksSection() {
    const target = document.getElementById('dashboard-onboarding-tasks-root');
    if (!target) return;
    const store = ensureDashboardOnboardingState();
    target.innerHTML = renderOnboardingTasks(store.tasks);
}

function queueDashboardOnboardingTasksLoad() {
    const store = ensureDashboardOnboardingState();
    updateDashboardOnboardingTasksSection();
    if (store.loading) return;
    fetchOnboardingTasks().then(updateDashboardOnboardingTasksSection);
}
function renderDashboard() {
    if (state?.auth?.role === 'admin') {
        if (typeof renderAdminControlCenter === 'function') {
            return renderAdminControlCenter();
        }
        return;
    }

    state.ui.currentClassId = null;
    if (typeof renderAppDrawer === 'function') renderAppDrawer();
    const data = computeDashboardData();
    const root = document.getElementById('app-root');

    const shortcutRow = `
        <div class="ap-dashboard-shortcuts ap-dashboard-action-grid ap-dashboard-action-grid--teacher-quick" style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:18px;">
            <button class="btn ap-dashboard-action-button"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#2563eb; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof renderTimetable === 'function') renderTimetable(); else toast('불러오기 실패', 'warn');">
                시간표
            </button>
            <button class="btn ap-dashboard-action-button"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:#0891b2; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openAttendanceLedger === 'function') openAttendanceLedger(); else toast('불러오기 실패', 'warn');">
                출석부
            </button>
            <button class="btn ap-dashboard-action-button"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:var(--surface); color:var(--text); box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="openDashboardArchiveWindow(event);">
                아카이브
            </button>
        </div>
    `;

    const todayJournalCard = typeof renderTodayJournalCard === 'function' ? renderTodayJournalCard(data) : '';
    const todoSections = renderTodoSections();
    
    if (!state.ui.dashboardClassTab) state.ui.dashboardClassTab = 'all';
    const tab = state.ui.dashboardClassTab;

    const tabHtml = `
        <div class="ap-dashboard-tabbar" style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:12px;">
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:${tab==='all'?'var(--surface)':'transparent'}; color:${tab==='all'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='all'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='all'; renderDashboard()">전체</button>
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:${tab==='middle'?'var(--surface)':'transparent'}; color:${tab==='middle'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='middle'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='middle'; renderDashboard()">중등</button>
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:500; background:${tab==='high'?'var(--surface)':'transparent'}; color:${tab==='high'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='high'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='high'; renderDashboard()">고등</button>
        </div>
    `;

    let filteredClasses = sortClassesForDashboard(state.db.classes.filter(c => Number(c.is_active) !== 0));
    filteredClasses = filteredClasses.filter(c => {
        if (tab === 'middle') return isMiddleSchoolClass(c);
        if (tab === 'high') return !isMiddleSchoolClass(c);
        return true;
    });

    const classStatus = `
        <div class="ap-dashboard-section-head" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding:0 4px;">
            <h3 style="margin:0; font-size:14px; font-weight:500; color:var(--text);">학급관리</h3>
        </div>
        ${tabHtml}
        <div class="ap-dashboard-class-list" style="display:flex; flex-direction:column; gap:8px; margin-bottom:40px;">${filteredClasses.map(c => renderClassSummaryCard(c, data)).join('')}</div>
    `;

    const academyEntry = `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:4px; padding:4px; margin:0 0 16px; border:1px solid var(--border); border-radius:12px; background:var(--surface-2);">
            <span style="min-height:42px; border-radius:9px; background:var(--surface); color:var(--text); box-shadow:0 1px 2px rgba(0,0,0,0.05); display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:700;">AP Math</span>
            <a href="../eie/index.html" style="min-height:42px; border-radius:9px; color:var(--secondary); display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:700; text-decoration:none;">EIE 영어</a>
        </div>
    `;
    root.innerHTML = `<div class="ap-dashboard-shell" style="width:100%; max-width:850px; margin:0 auto; padding:0 16px 24px; box-sizing:border-box;">
        ${academyEntry}
        ${shortcutRow}
        ${todayJournalCard}
        <div id="dashboard-onboarding-tasks-root"></div>
        ${todoSections}
        ${classStatus}
    </div>`;
    queueDashboardOnboardingTasksLoad();
}

// [RESTORE] computeTodayCloseData: 원본 복구

function computeTodayCloseData() {
    const today = new Date().toLocaleDateString('sv-SE');
    const students = state?.db?.students || [];
    const classStudents = state?.db?.class_students || [];
    const classes = state?.db?.classes || [];
    const attendance = state?.db?.attendance || [];
    const homework = state?.db?.homework || [];

    const scheduledActive = students.filter(s => {
        if (String(s?.status || '') !== '재원') return false;
        const cid = classStudents.find(m => String(m?.student_id) === String(s?.id))?.class_id;
        const cls = classes.find(c => String(c?.id) === String(cid || ''));
        if (cls && Number(cls.is_active) === 0) return false;
        return isClassScheduledTodayForDashboard(cid);
    });

    const absents = [];
    const hwMisses = [];

    scheduledActive.forEach(s => {
        const cid = classStudents.find(m => String(m?.student_id) === String(s?.id))?.class_id;
        const className = classes.find(c => String(c?.id) === String(cid || ''))?.name || '미배정';
        const info = { id: s.id, name: s.name, className };

        const att = attendance.find(a => String(a?.student_id) === String(s.id) && String(a?.date) === today);
        if (att?.status === '결석') absents.push(info);

        const hw = homework.find(h => String(h?.student_id) === String(s.id) && String(h?.date) === today);
        if (hw?.status === '미완료') hwMisses.push(info);
    });

    const totalActive = scheduledActive.length;
    return {
        totalActive,
        absents,
        hwMisses,
        allClear: absents.length === 0 && hwMisses.length === 0
    };
}


// [RESTORE] quickToggleAtt: 원본 복구
async function quickToggleAtt(sid, status, tab = 'att') {
    const today = new Date().toLocaleDateString('sv-SE');
    const r = await api.patch('attendance', { studentId: sid, status, date: today });
    if (!r?.success) { toast('출결 처리 실패', 'warn'); return; }
    await refreshDataOnly();
    openTodayCloseModal(1);
}

// [RESTORE] quickToggleHw: 원본 복구
async function quickToggleHw(sid, status, tab = 'hw') {
    const today = new Date().toLocaleDateString('sv-SE');
    const r = await api.patch('homework', { studentId: sid, status, date: today });
    if (!r?.success) { toast('숙제 처리 실패', 'warn'); return; }
    await refreshDataOnly();
    openTodayCloseModal(1);
}


function renderDailyClosePanel(step = 1) {
    injectDashboardOpsStyles();
    const d = computeTodayCloseData();
    const risks = typeof computeRiskStudents === 'function' ? computeRiskStudents() : [];
    const clearedLogs = state?.dashboard?.clearedCareLogs || state?.dashboardClearedCareLogs || [];
    const today = new Date().toLocaleDateString('sv-SE');

    const renderStudentGroups = (items, type) => {
        if (!items.length) return `<div class="daily-close-empty">${type === 'att' ? '결석 학생이 없습니다.' : '숙제 미완료 학생이 없습니다.'}</div>`;
        const grouped = dashboardGroupByClass(items);
        const sortedClassNames = Object.keys(grouped).sort((a, b) => {
            const clsA = (state?.db?.classes || []).find(c => c.name === a);
            const clsB = (state?.db?.classes || []).find(c => c.name === b);
            const rankA = clsA ? getClassGradeRank(clsA.grade) : 99;
            const rankB = clsB ? getClassGradeRank(clsB.grade) : 99;
            if (rankA !== rankB) return rankA - rankB;
            return a.localeCompare(b, 'ko');
        });
        return `<div class="daily-close-list">${sortedClassNames.map(cName => `
            <div class="daily-close-class-group">
                <div class="daily-close-class-group__head">${apEscapeHtml(cName)}</div>
                ${grouped[cName].map(s => `
                    <div class="daily-close-student">
                        <div class="daily-close-student__row">
                            <span class="daily-close-student__name">${apEscapeHtml(s.name)}</span>
                            <span class="daily-close-student__link" onclick="closeModal();renderStudentDetail('${dashboardEscapeAttr(s.id)}')">상세 보기</span>
                        </div>
                        <div class="daily-close-student__actions">
                            ${type === 'att'
                                ? `<button class="btn btn-primary" onclick="quickToggleAtt('${dashboardEscapeAttr(s.id)}', '등원', 'step1')">등원 (취소)</button><button class="btn" disabled>결석 유지</button>`
                                : `<button class="btn btn-primary" onclick="quickToggleHw('${dashboardEscapeAttr(s.id)}', '완료', 'step1')">완료 (취소)</button><button class="btn" disabled>미완료 유지</button>`}
                        </div>
                    </div>
                `).join('')}
            </div>
        `).join('')}</div>`;
    };

    const renderCareLogs = () => {
        const activeCare = risks.slice(0, 8).map(r => `
            <div class="care-log-item">
                <div class="care-log-item__title">${apEscapeHtml(r.student?.name || '')} <span class="care-risk-badge">${apEscapeHtml(String(r.riskScore || 0))}점</span></div>
                <div class="care-log-item__text">${apEscapeHtml(r.className || '미배정')} · ${apEscapeHtml((r.reasons || []).join(' · '))}</div>
            </div>
        `).join('');
        const cleared = clearedLogs.slice(0, 8).map(log => `
            <div class="care-log-item">
                <div class="care-log-item__title">${apEscapeHtml(log.student_name || '')} <span class="care-risk-cleared">해소</span></div>
                <div class="care-log-item__text">${apEscapeHtml(log.summary || '')}</div>
            </div>
        `).join('');
        if (!activeCare && !cleared) return `<div class="daily-close-empty">보강/상담 상쇄로 확인할 집중케어 변동이 없습니다.</div>`;
        return `<div class="care-log-list">${activeCare}${cleared}</div>`;
    };

    const progress = [
        { no: 1, label: '예외 확인' },
        { no: 2, label: '상쇄 확인' },
        { no: 3, label: '일지 검토' }
    ].map(item => `<div class="daily-close-progress__item ${Number(step) === item.no ? 'daily-close-progress__item--active' : ''}">${item.no}. ${item.label}</div>`).join('');

    const stepHtml = `
        <div class="daily-close-step ${Number(step) === 1 ? 'daily-close-step--active' : ''}">
            <div class="daily-close-step__header">Step 1. 오늘 예외 확인</div>
            <div class="daily-close-step__body">
                ${renderStudentGroups(d.absents || [], 'att')}
                ${renderStudentGroups(d.hwMisses || [], 'hw')}
            </div>
        </div>
        <div class="daily-close-step ${Number(step) === 2 ? 'daily-close-step--active' : ''}">
            <div class="daily-close-step__header">Step 2. 보강/상담 상쇄 확인</div>
            <div class="daily-close-step__body">${renderCareLogs()}</div>
        </div>
        <div class="daily-close-step ${Number(step) === 3 ? 'daily-close-step--active' : ''}">
            <div class="daily-close-step__header">Step 3. 일지 초안 검토</div>
            <div class="daily-close-step__body">
                ${renderJournalDraftPreview(today)}
            </div>
        </div>
    `;

    const prevBtn = Number(step) <= 1
        ? `<button class="btn" onclick="closeModal()">취소</button>`
        : `<button class="btn" onclick="openTodayCloseModal(${Number(step) - 1})">이전</button>`;
    const nextBtn = Number(step) >= 3
        ? `<button class="btn btn-primary" onclick="openDailyJournalModal('${today}')">일지 작성</button>`
        : `<button class="btn btn-primary" onclick="openTodayCloseModal(${Number(step) + 1})">다음</button>`;

    return `
        <div class="daily-close-panel">
            <div class="daily-close-progress">${progress}</div>
            ${stepHtml}
            <div class="daily-close-actions">${prevBtn}${nextBtn}</div>
        </div>
    `;
}

function openTodayCloseModal(step = 1) {
    const numericStep = Number(step);
    const safeStep = Number.isFinite(numericStep) ? Math.max(1, Math.min(3, numericStep)) : 1;
    if (!state.ui) state.ui = {};
    state.ui.dailyCloseStep = safeStep;
    showModal('예외 현황', renderDailyClosePanel(safeStep));
}


// [RESTORE] getTodayExamConfig: 원본 복구
function getTodayExamConfig() {
    try {
        const raw = localStorage.getItem('AP_TODAY_EXAM');
        if (!raw) return null;
        const cfg = JSON.parse(raw);
        const today = new Date().toLocaleDateString('sv-SE');
        if (cfg.date !== today || !cfg.title) { localStorage.removeItem('AP_TODAY_EXAM'); return null; }
        return { date: cfg.date, title: String(cfg.title), q: parseInt(cfg.q, 10) || 20 };
    } catch (e) { localStorage.removeItem('AP_TODAY_EXAM'); return null; }
}

// [RESTORE] setTodayExamConfig: 원본 복구
function setTodayExamConfig(title, q) {
    const today = new Date().toLocaleDateString('sv-SE');
    const validQ = parseInt(q, 10) || 20;
    localStorage.setItem('AP_TODAY_EXAM', JSON.stringify({ date: today, title: String(title), q: validQ }));
}

// [RESTORE] clearTodayExamConfig: 원본 복구
function clearTodayExamConfig() {
    localStorage.removeItem('AP_TODAY_EXAM');
    if(state.auth.role === 'admin' && typeof renderAdminControlCenter === 'function') renderAdminControlCenter();
    else renderDashboard();
}

function openTodayExamSetModal() {
    const cfg = getTodayExamConfig();
    showModal('오늘 시험 설정', `
        <div style="display:flex; flex-direction:column; gap:12px;">
            <div style="font-size:12px; color:var(--secondary); background:var(--surface-2); padding:10px; border-radius:8px; line-height:1.5;">오늘 전체 학급에 적용될 시험 기준을 설정합니다.<br>(QR 코드 생성 시에도 자동 연동됩니다)</div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin:4px 0;">
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='쪽지시험'">쪽지시험</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='단원평가'">단원평가</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='월말평가'">월말평가</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='모의고사'">모의고사</button>
            </div>
            <input id="set-exam-title" class="btn" placeholder="시험명 직접 입력" value="${cfg?.title || ''}" style="text-align:left; width:100%; background:var(--surface-2); border:none;">
            <input id="set-exam-q" type="number" class="btn" placeholder="문항 수 (기본 20)" value="${cfg?.q || 20}" min="1" max="50" style="text-align:left; width:100%; background:var(--surface-2); border:none;">
            <div style="display:flex; gap:8px; margin-top:12px;">
                <button class="btn" style="flex:1; padding:12px; font-size:12px; color:var(--error); background:rgba(255,71,87,0.1); border:none; font-weight:500;" onclick="clearTodayExamConfig(); closeModal();">시험 없음</button>
                <button class="btn btn-primary" style="flex:1.5; padding:12px; font-size:12px; font-weight:500;" onclick="handleSetTodayExam()">저장 및 적용</button>
            </div>
        </div>
    `);
}

function handleSetTodayExam() {
    const t = document.getElementById('set-exam-title').value.trim();
    const q = parseInt(document.getElementById('set-exam-q').value, 10) || 20;
    if (!t) { toast('시험명을 입력하세요.', 'warn'); return; }
    setTodayExamConfig(t, q); 
    toast('오늘 시험이 설정되었습니다.', 'info'); 
    closeModal(); 
    if(state.auth.role === 'admin' && typeof renderAdminControlCenter === 'function') renderAdminControlCenter();
    else renderDashboard();
}

function extractJournalUnitAndNote(rawNote) {
    const raw = String(rawNote || '').trim();
    const result = { units: '', note: '' };
    if (!raw) return result;

    const match = raw.match(/^\[단원선택\]\s*([^\n]*)\n?/);
    if (!match) {
        result.note = raw;
        return result;
    }

    result.units = String(match[1] || '').trim();
    result.note = raw.replace(/^\[단원선택\]\s*[^\n]*\n?/, '').trim();
    return result;
}

function compactJournalUnitText(text) {
    return String(text || '').replace(/\s+/g, '').trim();
}

function formatJournalProgressLine(progress, unitText) {
    const title = String(progress?.textbook_title_snapshot || '교재').trim() || '교재';
    const progressText = String(progress?.progress_text || '').trim() || '(기록 없음)';
    const compactUnit = compactJournalUnitText(unitText);

    if (compactUnit) {
        return `  * ${title} ${compactUnit}-${progressText}`;
    }

    return `  * ${title}: ${progressText}`;
}

function appendJournalNote(text, note) {
    const clean = String(note || '').trim();
    if (!clean) return text;

    const lines = clean.split('\n').map(v => v.trim()).filter(Boolean);
    if (lines.length === 0) return text;

    if (lines.length === 1) {
        return text + `- 특이사항: ${lines[0]}\n`;
    }

    text += `- 특이사항:\n`;
    lines.forEach(line => {
        text += `  ${line}\n`;
    });
    return text;
}


function dashboardFormatConsultationFullText(row) {
    const bodyFields = [
        row?.content,
        row?.memo,
        row?.note,
        row?.consultation_content,
        row?.body,
        row?.description,
        row?.summary
    ];
    const mainBody = bodyFields
        .map(v => String(v || '').trim())
        .find(Boolean) || '';
    const nextAction = String(row?.next_action || row?.nextAction || row?.follow_up || row?.followUp || '').trim();
    const parts = [];
    if (mainBody) parts.push(mainBody);
    if (nextAction) parts.push(`다음 조치: ${nextAction}`);
    return parts.join('\n');
}


function dashboardGetJournalClassRows(targetDate) {
    const parts = String(targetDate || new Date().toLocaleDateString('sv-SE')).split('-');
    const targetDayIdx = String(new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])).getDay());

    return (state.db.classes || []).filter(c => {
        if (Number(c.is_active) === 0) return false;
        if (!isMiddleSchoolClass(c)) return false;
        if (!isClassVisibleForCurrentTeacher(c)) return false;

        if (!c.schedule_days) return true;
        return String(c.schedule_days)
            .split(',')
            .map(v => v.trim())
            .includes(targetDayIdx);
    });
}

function dashboardGetConsultationDate(cn) {
    return String(cn?.consultation_date || cn?.date || cn?.created_at || '').slice(0, 10);
}

function dashboardGetConsultationBody(cn) {
    return String(
        cn?.content ??
        cn?.memo ??
        cn?.note ??
        cn?.consultation_content ??
        cn?.body ??
        cn?.description ??
        cn?.summary ??
        ''
    ).trim();
}

function dashboardGetJournalConsultationsForClass(targetDate, memberIds) {
    const memberSet = new Set((memberIds || []).map(id => String(id)));
    return (state.db.consultations || []).filter(cn => {
        if (dashboardGetConsultationDate(cn) !== targetDate) return false;
        return memberSet.has(String(cn?.student_id || ''));
    });
}

function dashboardFormatJournalConsultationEntry(cn, students) {
    const sName = (students || []).find(s => String(s.id) === String(cn?.student_id))?.name || cn?.student_name_snapshot || cn?.student_name || '학생';
    const body = dashboardGetConsultationBody(cn);
    let text = `  * ${sName}\n`;
    if (body) {
        body.split(/\r?\n/).forEach(line => {
            text += `    ${line}\n`;
        });
    } else {
        text += `    상담 내용 없음\n`;
    }
    return text;
}

function dashboardJournalAlreadyHasConsultation(content, cn, students) {
    const source = String(content || '');
    const sName = (students || []).find(s => String(s.id) === String(cn?.student_id))?.name || cn?.student_name_snapshot || cn?.student_name || '학생';
    const body = dashboardGetConsultationBody(cn);
    if (body) {
        const normalizedBody = body.replace(/\r\n/g, '\n').trim();
        if (normalizedBody && source.replace(/\r\n/g, '\n').includes(normalizedBody)) return true;
        const firstLine = normalizedBody.split('\n').find(Boolean);
        if (firstLine && firstLine.length >= 12 && source.includes(firstLine)) return true;
    }
    return Boolean(sName && source.includes(sName) && body && source.includes(body.slice(0, Math.min(30, body.length))));
}

function dashboardInsertJournalConsultationsIntoClassSection(content, className, entries) {
    if (!entries.length) return content;
    const source = String(content || '');
    const header = `■ ${className}반`;
    const start = source.indexOf(header);
    const entryText = entries.join('');

    if (start < 0) {
        return `${source.trimEnd()}\n\n■ ${className}반\n- 상담:\n${entryText}`;
    }

    const nextStart = source.indexOf('\n■ ', start + header.length);
    const sectionEnd = nextStart >= 0 ? nextStart : source.length;
    const section = source.slice(start, sectionEnd);
    const hasConsultationTitle = /\n- 상담:\s*\n/.test(section);
    const insertion = hasConsultationTitle ? entryText : `- 상담:\n${entryText}`;
    const trimmedSectionEnd = sectionEnd - (source.slice(0, sectionEnd).match(/\s*$/)?.[0]?.length || 0);
    const safeInsertAt = Math.max(start + header.length, trimmedSectionEnd);

    return source.slice(0, safeInsertAt) + `\n${insertion}` + source.slice(safeInsertAt);
}

function mergeJournalConsultationsIntoContent(content, targetDate) {
    const classes = dashboardGetJournalClassRows(targetDate);
    let merged = String(content || '').trimEnd();
    if (!merged) merged = buildJournalContent(targetDate).trimEnd();

    classes.forEach(cls => {
        const memberIds = (state.db.class_students || []).filter(m => String(m.class_id) === String(cls.id)).map(m => String(m.student_id));
        const students = (state.db.students || []).filter(s => memberIds.includes(String(s.id)) && s.status === '재원');
        const missingEntries = dashboardGetJournalConsultationsForClass(targetDate, memberIds)
            .filter(cn => !dashboardJournalAlreadyHasConsultation(merged, cn, students))
            .map(cn => dashboardFormatJournalConsultationEntry(cn, students));

        if (missingEntries.length > 0) {
            merged = dashboardInsertJournalConsultationsIntoClassSection(merged, cls.name, missingEntries);
        }
    });

    return merged.trim() + '\n';
}

function buildJournalContent(dateStr) {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');
    let text = `[AP Math 운영 일지 - ${targetDate}]\n작성자: ${state.ui.userName}\n\n`;

    const activeClasses = dashboardGetJournalClassRows(targetDate);

    if (activeClasses.length === 0) {
        text += `해당 날짜에 담당 학급이 없습니다.\n`;
        return text;
    }

    activeClasses.forEach(cls => {
        text += `■ ${cls.name}반\n`;

        const memberIds = (state.db.class_students || []).filter(m => String(m.class_id) === String(cls.id)).map(m => String(m.student_id));
        const students = (state.db.students || []).filter(s => memberIds.includes(String(s.id)) && s.status === '재원');
        const total = students.length;

        const absents = [];
        const lates = [];
        const makeups = [];
        const hwMiss = [];

        students.forEach(s => {
            const att = (state.db.attendance || []).find(a => String(a.student_id) === String(s.id) && a.date === targetDate);
            const hw = (state.db.homework || []).find(h => String(h.student_id) === String(s.id) && h.date === targetDate);
            const attStatus = String(att?.status || '').trim();
            const tagList = String(att?.tags || '')
                .split(',')
                .map(v => v.trim())
                .filter(Boolean);

            if (attStatus === '결석') absents.push(s.name);
            if (attStatus === '지각' || tagList.includes('지각')) lates.push(s.name);
            if (attStatus === '보강' || tagList.includes('보강')) makeups.push(s.name);
            if (hw?.status === '미완료') hwMiss.push(s.name);
        });

        const attendanceCount = Math.max(0, total - absents.length);
        const homeworkCount = Math.max(0, total - hwMiss.length);

        text += `- 출석: ${attendanceCount}/${total}\n`;
        text += `- 숙제: ${homeworkCount}/${total}\n`;
        if (absents.length > 0) text += `- 결석: ${absents.join(', ')}\n`;
        if (lates.length > 0) text += `- 지각: ${lates.join(', ')}\n`;
        if (makeups.length > 0) text += `- 보강: ${makeups.join(', ')}\n`;
        if (hwMiss.length > 0) text += `- 숙제 미완료: ${hwMiss.join(', ')}\n`;

        const dailyRecord = (state.db.class_daily_records || []).find(r => String(r.class_id) === String(cls.id) && r.date === targetDate);
        if (dailyRecord) {
            const noteData = extractJournalUnitAndNote(dailyRecord.special_note);
            const progresses = (state.db.class_daily_progress || []).filter(p => String(p.record_id) === String(dailyRecord.id));
            if (progresses.length > 0) {
                text += `- 진도:\n`;
                progresses.forEach(p => {
                    text += formatJournalProgressLine(p, noteData.units) + `\n`;
                });
            } else text += `- 진도: (기록 없음)\n`;

            text = appendJournalNote(text, noteData.note);
        } else {
            text += `- 진도: (수업 기록 미입력)\n`;
        }

        const cns = dashboardGetJournalConsultationsForClass(targetDate, memberIds);
        if (cns.length > 0) {
            text += `- 상담:\n`;
            cns.forEach(cn => {
                text += dashboardFormatJournalConsultationEntry(cn, students);
            });
        }

        text += `\n`;
    });

    return text.trim() + '\n';
}


function openDailyJournalModal(dateStr) {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');

    if (state.ui.viewScope === 'all' || state.auth.role === 'admin') {
        renderAdminJournalList(targetDate);
        return;
    }

    const journals = state.db.journals || [];
    const myJournal = journals.find(j => j.date === targetDate && j.teacher_name === state.ui.userName);

    const status = myJournal ? myJournal.status : '작성중';
    const isLocked = status === '제출완료' || status === '결재완료';
    const content = isLocked
        ? (myJournal?.content || buildJournalContent(targetDate))
        : mergeJournalConsultationsIntoContent(myJournal?.content || buildJournalContent(targetDate), targetDate);

    let actionBtns = '';
    if (!myJournal || status === '작성중') {
        actionBtns = `
            <button class="btn" style="flex:1; padding:14px; font-weight:500; background:var(--surface); color:var(--text);" onclick="saveJournal('작성중', null, '${targetDate}')">임시 저장</button>
            <button class="btn btn-primary" style="flex:1; padding:14px; font-weight:500;" onclick="saveJournal('제출완료', null, '${targetDate}')">제출</button>
        `;
    } else if (status === '제출완료') {
        actionBtns = `
            <button class="btn" style="flex:1; padding:14px; font-weight:500; color:var(--error); background:rgba(255,71,87,0.1); border:none;" onclick="saveJournal('작성중', '${myJournal.id}', '${targetDate}')">제출 취소 및 수정</button>
        `;
    }

    showModal('일지', `
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px; background:var(--surface-2); padding:10px 14px; border-radius:10px;">
            <span style="font-size:13px; color:var(--secondary);; font-weight:500;">작성 기준일</span>
            <input type="date" class="btn" value="${targetDate}" style="flex:1; text-align:left; border:none; background:transparent; padding:0; height:auto; min-height:0; font-size:14px; font-weight:500; color:var(--text);" onchange="openDailyJournalModal(this.value)">
        </div>
        ${status === '결재완료' ? `
            <div style="background:rgba(var(--success-rgb),0.10); color:var(--success); padding:16px; border-radius:12px; margin-bottom:16px;">
                <span style="display:flex; align-items:center; gap:8px; font-size:14px;; font-weight:500;">원장님 확인 완료</span>
                ${myJournal.feedback ? `<div style="margin-top:10px; font-size:13px; background:var(--surface); padding:12px; border-radius:8px; color:var(--text);"><span style="font-weight:500;">피드백:</span><br>${apEscapeHtml(myJournal.feedback)}</div>` : ''}
            </div>
        ` : ''}
        <textarea id="journal-content" class="btn" style="width:100%; height:250px; text-align:left; resize:vertical; font-family:inherit; font-size:14px; line-height:1.6; background:${isLocked ? 'var(--surface-2)' : 'var(--surface)'}; border:1px solid var(--border); color:var(--text);" ${isLocked ? 'readonly' : ''}>${apEscapeHtml(content)}</textarea>
        <div style="display:flex; gap:10px; margin-top:16px; flex-wrap:wrap;">
            ${actionBtns}
        </div>
    `);
}

async function saveJournal(status, existingId = null, targetDate) {
    const el = document.getElementById('journal-content');
    if (!el) return toast('일지 입력칸을 찾을 수 없습니다.', 'warn');

    const content = el.value;
    const journals = state.db.journals || [];
    const myJournal = journals.find(j => j.date === targetDate && j.teacher_name === state.ui.userName);

    const journalId = existingId || myJournal?.id;
    let result;
    if (journalId) {
        result = await api.patch(`daily-journals/${journalId}`, { content, status });
    } else {
        result = await api.post('daily-journals', { date: targetDate, content, status });
    }

    if (!result || result.error) return toast(result?.error || '저장 실패', 'error');

    toast(`저장 완료`, 'success');
    closeModal();
    await loadData();
}

function renderAdminJournalList(dateStr, teacherName = '') {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');
    const safeTeacher = dashboardEscapeAttr(teacherName || '');
    let journals = (state.db.journals || []).filter(j => j.date === targetDate && j.status !== '작성중');
    if (teacherName) journals = journals.filter(j => j.teacher_name === teacherName);
    const title = teacherName ? `${teacherName} 선생님 일지` : '일지확인';
    
    const backBtn = teacherName ? `<button class="btn" style="width:100%; margin-bottom:16px; padding:14px; border-radius:12px; font-weight:500; background:var(--surface-2); border:none; color:var(--text);" onclick="closeModal(true)">닫기</button>` : '';
    
    const rows = journals.map(j => {
        const teacherArg = dashboardEscapeAttr(teacherName || j.teacher_name || '');
        const statusText = j.status === '결재완료' ? '확인완료' : j.status;
        const statusColor = j.status === '결재완료' ? 'var(--success)' : 'var(--primary)';
        const statusBg = j.status === '결재완료' ? 'rgba(var(--success-rgb),0.10)' : 'var(--primary-soft)';
        
        return `
            <div class="card" style="padding:16px; margin-bottom:12px; cursor:pointer; border:1px solid var(--border); border-radius:16px; box-shadow:var(--shadow); background:var(--surface);" onclick="openAdminJournalFeedback('${j.id}', '${teacherArg}')">
                <div style="display:flex; justify-content:space-between; margin-bottom:10px; gap:8px; align-items:center;">
                    <span style="font-size:15px; color:var(--text);; font-weight:500;">${apEscapeHtml(j.teacher_name)} 선생님</span>
                    <span style="font-size:11px; font-weight:500; color:${statusColor}; background:${statusBg}; padding:4px 8px; border-radius:6px;">${apEscapeHtml(statusText)}</span>
                </div>
                <div style="font-size:13px; color:var(--text-soft); white-space:pre-wrap; max-height:60px; overflow:hidden; line-height:1.6;">${apEscapeHtml(j.content)}</div>
            </div>`;
    }).join('');
    
    showModal(`${apEscapeHtml(title)}`, `
        ${backBtn}
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px; background:var(--surface-2); padding:12px 14px; border-radius:12px;">
            <span style="font-size:13px; color:var(--secondary); white-space:nowrap;; font-weight:500;">기준일</span>
            <input type="date" class="btn" value="${targetDate}" style="flex:1; text-align:left; border:none; background:transparent; padding:0; height:auto; min-height:0; font-size:14px; font-weight:500; color:var(--text);" onchange="renderAdminJournalList(this.value, '${safeTeacher}')">
        </div>
        <div style="max-height:55vh; overflow-y:auto; padding-right:4px;">
            ${journals.length ? rows : `<div style="text-align:center; color:var(--secondary); padding:30px; font-weight:500; font-size:13px; background:var(--surface-2); border-radius:12px;">해당 날짜에 제출된 일지가 없습니다.</div>`}
        </div>
    `);
}

function openAdminJournalFeedback(id, teacherName = '') {
    const journal = (state.db.journals || []).find(j => j.id === id);
    if (!journal) return toast('일지를 찾을 수 없습니다.', 'warn');
    const safeTeacher = dashboardEscapeAttr(teacherName || journal.teacher_name || '');
    
    showModal(`${apEscapeHtml(journal.teacher_name)} 선생님 일지`, `
        <textarea readonly class="btn" style="width:100%; height:200px; text-align:left; resize:vertical; font-size:14px; line-height:1.6; background:var(--surface-2); border:none; border-radius:12px; padding:16px; margin-bottom:12px; color:var(--text);">${apEscapeHtml(journal.content)}</textarea>
        <textarea id="journal-feedback" class="btn" placeholder="선생님께 전달할 피드백 (선택)" style="width:100%; height:90px; text-align:left; resize:vertical; border:1px solid var(--border); border-radius:12px; padding:14px; font-size:13px; background:var(--surface); color:var(--text);">${apEscapeHtml(journal.feedback || '')}</textarea>
        <div style="margin-top:16px;">
            <button class="btn btn-primary" style="width:100%; padding:16px; border-radius:14px; font-weight:500; font-size:15px;" onclick="approveJournal('${journal.id}', '${journal.date}', '${safeTeacher}')">확인완료</button>
        </div>
    `);
}

function approveJournal(id, dateStr, teacherName = '') {
    const feedback = document.getElementById('journal-feedback')?.value.trim() || '';
    return api.patch(`daily-journals/${id}`, { feedback, status: '결재완료' }).then(async result => {
        if (!result || result.error) return toast(result?.error || '저장 실패', 'error');
        toast('저장 완료', 'success');
        closeModal();
        await loadData();
        renderAdminJournalList(dateStr, teacherName);
    });
}

function formatAdminRecentJournalDate(dateStr) {
    const datePart = String(dateStr || '').split('T')[0].split(' ')[0];
    const parts = datePart.split('-').map(Number);
    if (parts.length !== 3 || parts.some(n => !Number.isFinite(n))) return datePart;
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    const weekdays = ['일', '월', '화', '수', '목', '금', '토'];
    return `${parts[1]}/${parts[2]} ${weekdays[date.getDay()] || ''}`.trim();
}

function getAdminRecentTeacherJournals(teacherName, baseDateStr = '', days = 30) {
    const baseTime = apParseLocalDateTime(baseDateStr || new Date().toLocaleDateString('sv-SE'));
    if (baseTime === null) return [];
    return (state.db.journals || [])
        .filter(j => {
            if (String(j?.teacher_name || '') !== String(teacherName || '')) return false;
            if (String(j?.status || '') === '작성중') return false;
            const time = apParseLocalDateTime(j?.date);
            if (time === null) return false;
            const diff = (baseTime - time) / (1000 * 60 * 60 * 24);
            return diff >= 0 && diff < days;
        })
        .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
}

function openAdminRecentTeacherJournals(teacherName, baseDateStr = '') {
    const safeTeacher = dashboardEscapeAttr(teacherName || '');
    const rows = getAdminRecentTeacherJournals(teacherName, baseDateStr, 30).map(j => `
        <button type="button" class="btn" style="width:100%; min-height:44px; padding:0 14px; margin-bottom:6px; border-radius:12px; border:1px solid var(--border); background:var(--surface); color:var(--text); box-shadow:none; justify-content:flex-start; font-size:14px; font-weight:500;" onclick="openAdminJournalFeedback('${dashboardEscapeAttr(String(j.id || ''))}', '${safeTeacher}')">
            ${apEscapeHtml(formatAdminRecentJournalDate(j.date))}
        </button>
    `).join('');
    showModal('최근 일지', `<div style="max-height:55vh; overflow-y:auto;">${rows}</div>`);
}


function renderAdminTeacherCards(todayStr) {
    injectDashboardOpsStyles();
    const activeClasses = (state?.db?.classes || []).filter(c => Number(c?.is_active) !== 0);
    const teacherMap = {};
    activeClasses.forEach(c => {
        const tName = String(c.teacher_name || '담당').trim();
        if (!tName || tName === '담당') return;
        if (!teacherMap[tName]) teacherMap[tName] = [];
        teacherMap[tName].push(c);
    });
    const teacherNames = Object.keys(teacherMap).filter(Boolean).sort((a, b) => a.localeCompare(b, 'ko'));
    if (!teacherNames.length) return `<div class="daily-close-empty">등록된 선생님이 없습니다.</div>`;

    return teacherNames.map(tName => {
        const myClasses = teacherMap[tName];
        const safeName = dashboardEscapeAttr(tName);

        return `
            <div class="card ap-admin-teacher-card">
                <div class="admin-teacher-card__head">
                    <div class="admin-teacher-card__name">${apEscapeHtml(tName)} 선생님</div>
                    <div class="admin-teacher-card__quick-actions">
                        <button class="btn admin-teacher-card__quick-action" onclick="event.stopPropagation(); renderAdminTeacherStudents('${safeName}')">담당반</button>
                        <button class="btn admin-teacher-card__quick-action" onclick="event.stopPropagation(); renderAdminTeacherAllStudents('${safeName}')">재원</button>
                    </div>
                </div>
                <div class="admin-teacher-card__journal">
                    <div class="admin-teacher-card__journal-title" style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <span>이번 주 일지</span>
                        <button type="button" class="btn admin-teacher-card__quick-action" style="min-height:28px; height:28px; padding:0 8px; font-size:11px;" onclick="event.stopPropagation(); openAdminRecentTeacherJournals('${safeName}')">최근 일지</button>
                    </div>
                    ${renderDashboardJournalWeekMatrix(tName, todayStr, myClasses)}
                </div>
            </div>`;
    }).join('');
}


function openAdminTeacherPanel(teacherName) {
    state.ui.currentAdminTeacherName = teacherName;
    const safeName = dashboardEscapeAttr(teacherName || '');
    renderAdminJournalList(new Date().toLocaleDateString('sv-SE'), safeName);
}


function renderAdminTeacherAllStudents(teacherName) {
    injectDashboardOpsStyles();
    const myClasses = (state?.db?.classes || []).filter(c => String(c.teacher_name || '담당').trim() === teacherName && Number(c.is_active) !== 0);
    const myClassIds = myClasses.map(c => String(c.id));
    const myStudentIds = [...new Set((state?.db?.class_students || [])
        .filter(m => myClassIds.includes(String(m.class_id)))
        .map(m => String(m.student_id)))];
    const gradeOrder = ['중1', '중2', '중3', '고1', '고2', '고3', '기타'];
    const gradeCounts = {};
    gradeOrder.forEach(label => { gradeCounts[label] = 0; });
    let totalCount = 0;
    (state?.db?.students || [])
        .filter(s => myStudentIds.includes(String(s.id)) && adminNormalizeStatus(s.status) === '재원')
        .forEach(s => {
            const grade = adminGetGradeLabel(s);
            const label = gradeOrder.includes(grade) ? grade : '기타';
            gradeCounts[label] += 1;
            totalCount += 1;
        });

    const chips = gradeOrder
        .filter(label => gradeCounts[label] > 0)
        .map(label => `<span class="admin-teacher-grade-pill"><span>${apEscapeHtml(label)}</span><span>${gradeCounts[label]}명</span></span>`)
        .join('');

    showModal(`${apEscapeHtml(teacherName)} 선생님 재원`, `
        <div class="admin-teacher-grade-pills">
            ${totalCount > 0 ? `<span class="admin-teacher-grade-pill admin-teacher-grade-pill--total"><span>총원</span><span>${totalCount}명</span></span>${chips}` : `<div class="daily-close-empty">재원생이 없습니다.</div>`}
        </div>
    `);
}


function renderAdminTeacherStudents(teacherName) {
    const myClasses = sortClassesForDashboard(state.db.classes.filter(c => String(c.teacher_name || '담당').trim() === teacherName && Number(c.is_active) !== 0));
    const rows = myClasses.map(cls => {
        const safeClassId = dashboardEscapeAttr(cls.id || '');
        const isToday = isClassScheduledTodayForDashboard(cls.id);
        return `
            <button class="btn" style="width:100%; min-height:50px; padding:10px 12px; border-radius:14px; border:1px solid var(--border); background:var(--surface); box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:12px; text-align:left;" onclick="closeModal(true); if(typeof renderClass==='function') renderClass('${safeClassId}'); else toast('반 화면을 불러오지 못했습니다.', 'warn');">
                <div style="min-width:0; flex:1;">
                    <div style="font-size:14px; font-weight:500; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.name || '')}</div>
                    <div style="font-size:11px; font-weight:500; color:var(--secondary); margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.grade || '')}${cls.time_label ? ` · ${apEscapeHtml(cls.time_label)}` : ''}</div>
                </div>
                <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
                    <span style="font-size:11px; font-weight:500; color:${isToday ? 'var(--primary)' : 'var(--secondary)'}; background:${isToday ? 'var(--primary-soft)' : 'var(--surface-2)'}; padding:4px 8px; border-radius:999px; white-space:nowrap;">${isToday ? '오늘 수업' : '수업 없음'}</span>
                    <span style="font-size:18px; font-weight:500; color:var(--secondary); line-height:1;">›</span>
                </div>
            </button>
        `;
    }).join('');

    showModal(`${apEscapeHtml(teacherName)} 선생님 담당반`, `
        <div style="display:flex; flex-direction:column; gap:8px;">
            <div style="max-height:56vh; overflow-y:auto; display:flex; flex-direction:column; gap:7px; padding-right:4px;">
                ${rows || `<div style="text-align:center; padding:30px; color:var(--secondary); font-weight:500; background:var(--surface-2); border-radius:16px;">담당반이 없습니다.</div>`}
            </div>
        </div>
    `);
}

// [Button Audit Patch] Split-module duplicate handlers removed from dashboard.js.
// Source of truth: management.js, textbook.js, memo.js, schedule.js.

