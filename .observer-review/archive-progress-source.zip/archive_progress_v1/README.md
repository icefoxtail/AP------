# Archive Progress Observer — targeted residual cache recovery review

Scope: existing GitHub PR / registration / Pages status display. **Read-only observer is separate from all producer, review, scheduled lane and deployment workflows.** No new required check, manual receipt, or main publication.

## Apply on a review branch only

```bash
python3 apply.py /path/to/AP-repo
B15_DIAGNOSTIC_ZIP=/secure/local/b15-release-diagnostics.zip node --test \
  tests/archive-progress-observer.test.mjs tests/archive-progress-realpaths.test.mjs \
  tests/archive-progress-recovery.test.mjs tests/archive-progress-cache-targets.test.mjs \
  tests/b15-actual-diagnostic.test.mjs
python3 tests/browser-smoke.py
```

`apply.py` refuses `main` and retains the original review-overlay installer behavior. Its existing compatibility cleanup removes only obsolete v1 progress-observer upload hooks **if they were previously injected** into registration/release workflow YAML; the actual production registration/release actions are not changed. No such cleanup was performed on GitHub in this task. The B15 test uses independently downloaded small diagnostics ZIP bytes via `B15_DIAGNOSTIC_ZIP`; without those bytes the test **SKIPs** (never report full PASS). It does **not** download the 2.18GB Pages artifact. Never commit diagnostic bytes to the public repository.

## Targeted changes

- `archive-progress-observer.mjs` invokes `observeRun` for every newly observed run, regardless of overall `updatedAt`. Run-version identity is `registration|release:run_id:attempt:head_sha`. Verified proof is reused, unknown transient results are retried with a bounded exponential interval (5, 10, 20, 40 minutes, max four tries), permanent size/expiry reasons are not redownloaded. An explicit workflow dispatch may retry before the interval but does not bypass the attempt limit. A small number of pending runs that fall beyond the recent 24-run window are also revisited. Historical reprocessing remains a separate manual run.
- `archive-progress-core.mjs` allows same-run same-attempt `미확인→완료` when new evidence arrives, never erases earlier verified evidence solely due to a transient query failure, marks later mismatch as current `불일치`, and retains a separately dated `lastSuccessfulRelease`.
- Cache repair A: the deploy-job success proof is persisted as a *partial* release observation while Pages-byte parity remains retryable. A later call uses the cached authenticated job evidence, queries only the missing Pages artifact evidence and upgrades the same run/attempt/SHA to verified. Temporary downloads and ambiguous artifact selection use bounded retries; oversized/expired files are permanent file-evidence outcomes, with deploy-job success still visible. Old wrongly sealed `verified` job-only observations are migrated on read.
- Cache repair B: when a previously incomplete PR file list reveals a new exam, only runs at/after that PR and lacking that exam's evidence are backfilled. Valid old hashes and results are preserved. The production `collectEvidence` adapter reuses the confirmed registration commit to read its tree without downloading the prior logs/ZIP; a previously validated uploaded Pages ZIP is fetched again only if a newly found exam's file parity is absent. Negative exam coverage is remembered to avoid repeated queries.
- `deployedSiteProof` uses existing small `archive-pages-release-evidence-<run>-<attempt>` diagnostics plus actual successful Pages `deploy` job / `Deploy Pages artifact` step. This is a **deployment-job success** signal only. Site source / asset / registration parity is a separate column. Pages ZIP over 256MiB, including B15's 2.18GB artifact, is not downloaded. Parity remains `미확인` with reason. For genuinely small artifacts, original uploaded Pages bytes remain the parity authority.
- Residual fix A: after the diagnostic and successful deploy job are authenticated, exceptions during the Pages attempt lookup, HTTPS download, or response-stream pipeline preserve the confirmed job proof as a partial observation. Only the still-unconfirmed file witness is retried within the existing four-attempt schedule; size limit and expired outcomes stay terminal. Confirmed job/diagnostic evidence is reused.
- Residual fix B: historical backfill uses per-run/per-exam missing coverage, not just newly-discovered PR IDs. Prior `entries[*].main.at` retains eligibility after a PR ages out of the recent PR listing. The existing eight historical runs per stage/per invocation limit stays intact and resumes on the next invocation. Both positive and genuinely checked-negative exam rows are cached; unknown exams are not certified absent before PR discovery.
- `archive/progress.html` and `archive/progress.js` show `배포 작업` and `파일 일치` separately, and distinguish current `불일치` from last normal release; existing one-minute refresh, manual refresh and stale-screen retention remain.

Public JSON permits exam identifiers, run/attempt/SHA, GitHub URLs, timestamps, statuses, reasons, and content digests only. No answers, solution text, Library IDs, credentials or downloaded artifact contents. The `archive-progress-state` branch remains separate from `main`.

## Known limits

No production workflow dispatched, main merged or Pages deployed. GitHub consumer observer storage and actual production page rendering were **not** end-to-end exercised. B15 actual run/job metadata and downloaded small diagnostic were separately inspected; this does not establish 2.18GB deployed-file byte parity. The Chromium smoke runs on test fixtures, not live GitHub JSON.

## Confirming the *actual* code used in the next observer run (no production execution here)

The existing `.github/workflows/archive-progress-observer.yml` uses `actions/checkout` with **`ref: main`**, regardless of the branch selected in the `workflow_dispatch` UI. Clicking **Run workflow** while viewing a review branch therefore **does not execute this ZIP's code**. No workflow was dispatched as part of this review.

For local/review validation, create a separate review branch from fresh `origin/main`, run `python3 apply.py /path/to/AP-repo`, then run the tests above; confirm `git diff --name-only` includes only scoped observer files. To create a review commit, use targeted `git add` only, then record `PATCH_SHA=$(git rev-parse HEAD)` after committing. Tests executed from the unpacked ZIP validate these bytes but **do not prove a GitHub checkout SHA**.

For a later authorized operational observer run (only after separate approval to update `main`), open the Actions log and find `OBSERVER_CHECKOUT_SHA=<40-char SHA>`. This value is obtained by `git rev-parse HEAD` in the actual observer process. Cross-check the SHA against the Actions checkout and verify the reviewed patch SHA is an ancestor of the checked-out main HEAD (`git merge-base --is-ancestor "$PATCH_SHA" "$ACTUAL_CHECKOUT_SHA"`, after fetching the relevant commits). If it is not an ancestor, the observer was not running this patch. No status-branch write, deployment or operational merge was performed in this task.
