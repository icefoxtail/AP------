# Archive progress residual cache recovery — scoped validation (2026-10-11)

## Executed tests (2026-10-11 KST)

Actual **source ZIP**: `archive_progress_v1_cache_targeted_review.zip` (50,748 bytes), retained unchanged. Changed runtime files: `archive-progress-retry.mjs`, `archive-progress-observer.mjs`, `archive-progress-github-proof.mjs`. Changed test file: `archive-progress-cache-targets.test.mjs`. Updated README and this validation report. Existing `apply.py` and all other bytes are unchanged. No production checkout, merge, scheduled work, state-branch write, or deployment occurred.

```bash
cd archive_progress_v1
B15_DIAGNOSTIC_ZIP=/mnt/data/b15-release-diagnostics.zip node --test \
  tests/archive-progress-observer.test.mjs \
  tests/archive-progress-realpaths.test.mjs \
  tests/archive-progress-recovery.test.mjs \
  tests/archive-progress-cache-targets.test.mjs \
  tests/b15-actual-diagnostic.test.mjs
python3 tests/browser-smoke.py
```

- **Node: 53 tests, 53 PASS, 0 FAIL, 0 SKIP** (with actual B15 diagnostic input).
- **Chromium: PASS**, five mock fetches with separate job/parity columns, recover after failure, prior normal release, automatic refresh.
- **Residual exception cases** (`executeOnce` + real `collectEvidence`): first signed Pages ZIP fetch throws `ECONNREFUSED` or body stream aborts; the deployment job and diagnostic stay authenticated and cached as `partial`, file parity remains `미확인`; a later run verifies bytes, with no repeat job/diagnostic fetch. Network exception retry obeys the existing 5/10/20/40-minute maximum four-attempt policy.
- **Historical backlog cases** (`executeOnce` + real `collectEvidence` / `registeredGitProof`): 11 preexisting old run records outside recent run/PR listings, with existing exam state but missing per-run exam coverage, drain as 8 then 3. Positive and checked-negative exam coverage is retained with no repeated Git tree fetch. Prior successful release state remains present.
- The targeted suite injects the **production `collectEvidence` function** into `executeOnce`, rather than faking file verification. It generates real small Pages ZIP/TAR bytes and real diagnostic ZIP context, and exercises the real `deployedSiteProof` extraction and blob hashing. It tests: retry from failed Pages download to successful file evidence in auto/manual modes; cached job/diagnostics reused; missing Pages artifact queried again; oversized and expired artifacts not downloaded; later complete PR inventory adds only newly missing exam hash evidence; registration backfill uses cached validated Git commit and tree rather than job/log/ZIP; transient backfill failure preserves existing exam results; newer attempt/SHA never inherits earlier partial proof; and legacy job-only `verified` migration.
- Without `B15_DIAGNOSTIC_ZIP`, the B15-specific test **SKIPs** and the full run cannot be reported 53/53 PASS.

## B15 — real GitHub read-only cross-check

- Registration run `38109291851`, attempt `1`, `success`, input `86b3d531bd7b0d9b031f0a433c47f78c40947e4a`; actual commit log `[main c76a17200]` and successful `86b3d531b..c76a17200 HEAD -> main` push. GitHub exact commit `c76a172005603211ffce1245ed6f328b14fd07c8`, parent `86b3d531...`; this run exposed no observer proof artifact.
- Deployment run `38109580827`, attempt `1`, `success`, SHA `8ded9dbdacab31b37f60778b7577640156a3fefa`, whose GitHub commit parent is `c76a172005603211ffce1245ed6f328b14fd07c8`.
- Actual small diagnostics artifact `11691357897`, name `archive-pages-release-evidence-38109580827-1`, 247,524 bytes, was downloaded and `context.txt` read: `run_id=38109580827`, `run_attempt=1`, `source_sha=8ded9dbd...`. Deploy job `114383308420`, `Deploy the verified student release`, conclusion `success`, step `Deploy Pages artifact`, conclusion `success` (actual GitHub connector reads).
- `tests/b15-actual-diagnostic.test.mjs` invoked the **real `deployedSiteProof` function on the actual diagnostic ZIP bytes** using an API adapter populated with previously observed GitHub run/job/artifact metadata. The GitHub artifact was downloaded into a local secure test input; its full file SHA-256 `5fa43bfdd5902565942766c7e34c954cd9aada2f8665411add0f300cd8893e7a` matches the provider's artifact digest. This hybrid test is not a live-in-test API call. Result: **배포 작업 완료 / 파일 일치 미확인 (Pages ZIP 크기 초과)**.
- Pages artifact `11690559050`, 2,183,453,819 bytes at inspection, beyond 256MiB policy. It was not downloaded. Source/exam/asset/registry parity is **unverified**, not PASS.

## Deliberately unverified

No GitHub observer workflow or status-branch write was triggered. The shipped observer logs `OBSERVER_CHECKOUT_SHA` on execution; future main-only checkout must be compared with the review commit before claiming this patch was exercised. No producer, validator, scheduling or Pages run was restarted. Site output-byte parity and live status-page operation remain unverified. No PR or main merge was made.
