/**
 * AP Math OS 1.0 [js/dashboard.js]
 * 운영센터 및 선생님별 대시보드 엔진
 * [Dashboard Polish]: 52px 카드 높이 통일, 상단 바로가기 탭형 배치, 오늘일지 제목 외부 배치
 * [Schedule/Memo]: 오늘일정·주간일정 관리 버튼 제거, 일정 행 52px 규격 통일
 * [Class Filter]: 학급관리 전체/중등/고등 탭 필터 유지
 * [Stability]: 공휴일/휴무일 감지, Safari 안전 날짜 파싱, 교사별 표시 범위 유지
 */

function copyPhoneNumber(text) {
    const value = String(text || '').trim();
    if (!value) return;

    const showCopied = () => toast('전화번호가 복사되었습니다.', 'info');
    const showCopyFailed = (err) => {
        console.warn('[AP Math OS] phone copy failed:', err);
        toast('복사 실패', 'warn');
    };
    const fallbackCopy = () => {
        const textarea = document.createElement('textarea');
        textarea.value = value;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '0';
        document.body.appendChild(textarea);
        textarea.select();

        let copied = false;
        try {
            copied = document.execCommand('copy');
        } catch (err) {
            document.body.removeChild(textarea);
            showCopyFailed(err);
            return;
        }

        document.body.removeChild(textarea);
        if (copied) showCopied();
        else showCopyFailed(new Error('fallback copy returned false'));
    };

    if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(value).then(showCopied).catch(fallbackCopy);
    } else {
        fallbackCopy();
    }
}

function apEscapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function apParseLocalDateTime(value) {
    const str = String(value || '').trim();
    if (!str) return null;

    const datePart = str.split('T')[0].split(' ')[0];
    const parts = datePart.split('-').map(Number);

    if (parts.length !== 3) return null;

    const [y, m, d] = parts;
    if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;

    const time = new Date(y, m - 1, d).getTime();
    return Number.isFinite(time) ? time : null;
}

function apFormatMonthDay(value) {
    const str = String(value || '').trim();
    const datePart = str.split('T')[0].split(' ')[0];
    const parts = datePart.split('-').map(Number);

    if (parts.length !== 3) return '';

    const [, m, d] = parts;
    if (!Number.isFinite(m) || !Number.isFinite(d)) return '';

    return `${m}월 ${d}일`;
}

const DASH_HOLIDAYS = [
    '2026-01-01', '2026-02-16', '2026-02-17', '2026-02-18', '2026-03-01', '2026-03-02',
    '2026-05-01', '2026-05-05', '2026-05-24', '2026-05-25', '2026-06-06', '2026-07-17',
    '2026-08-15', '2026-08-17', '2026-09-24', '2026-09-25', '2026-09-26', '2026-10-03',
    '2026-10-05', '2026-10-09', '2026-12-25'
];

function isDashboardHoliday(dateStr) {
    if (DASH_HOLIDAYS.includes(dateStr)) return true;
    if (state.db.academy_schedules) {
        return state.db.academy_schedules.some(s =>
            String(s.is_deleted || 0) !== '1' &&
            s.schedule_date === dateStr &&
            s.schedule_type === 'closed' &&
            s.target_scope !== 'student'
        );
    }
    return false;
}

function isClassScheduledTodayForDashboard(cid) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const cls = state.db.classes.find(c => String(c.id) === String(cid));
    if (!cls) return false;

    const cIds = state.db.class_students
        .filter(m => String(m.class_id) === String(cid))
        .map(m => String(m.student_id));
    const hasActiveAttendance = state.db.attendance.some(
        a => a.date === todayStr && cIds.includes(String(a.student_id)) && a.status === '등원'
    );
    if (hasActiveAttendance) return true;

    if (isDashboardHoliday(todayStr)) return false;

    if (!cls.schedule_days) return true;
    const today = new Date().getDay();
    return String(cls.schedule_days).split(',').map(d => d.trim()).includes(String(today));
}

function isMiddleSchoolClass(c) {
    const gradeText = String(c?.grade || '');
    const nameText = String(c?.name || '');

    if (
        gradeText.startsWith('고') ||
        nameText.startsWith('고') ||
        nameText.includes('고1') ||
        nameText.includes('고2') ||
        nameText.includes('고3') ||
        nameText.includes('고등')
    ) return false;

    return true;
}

function isClassVisibleForCurrentTeacher(c) {
    if (!c) return false;

    if (state?.auth?.role === 'admin') return true;
    if (state?.ui?.viewScope === 'all') return true;

    const currentTeacher = typeof getTeacherNameForUI === 'function'
        ? getTeacherNameForUI()
        : (state?.ui?.userName || state?.auth?.name || '');

    const normalizedCurrent = String(currentTeacher || '')
        .replace(/\s*선생님\s*$/g, '')
        .trim();

    const normalizedClassTeacher = String(c.teacher_name || '')
        .replace(/\s*선생님\s*$/g, '')
        .trim();

    if (!normalizedClassTeacher) return true;

    return normalizedClassTeacher === normalizedCurrent;
}

// [5G] 관리필요(구 위험학생) 판정 알고리즘
function computeRiskStudents() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr);
    
    if (todayTime === null) return [];

    const active = state.db.students.filter(s => s.status === '재원');

    const attendanceHistory = state.db.attendance_history || [];
    const homeworkHistory = state.db.homework_history || [];
    const examSessions = state.db.exam_sessions || [];
    const consultations = state.db.consultations || [];
    const classStudents = state.db.class_students || [];
    const classes = state.db.classes || [];
    
    // [Stabilization] 최근 14일 기준 생성
    const LOOKBACK_DAYS = 14;
    const cutoffTime = todayTime - (LOOKBACK_DAYS - 1) * 24 * 60 * 60 * 1000;

    const getRecordTime = apParseLocalDateTime;
    
    const risks = [];
    
    active.forEach(s => {
        let riskTypes = [];
        let reasons = [];
        
        // [Stabilization] 출결 14일 필터 실제 적용
        const recentAtt = attendanceHistory.filter(a => {
            if (String(a.student_id) !== String(s.id)) return false;
            if (a.status !== '결석') return false;
            const t = getRecordTime(a.date);
            return t !== null && t >= cutoffTime && t <= todayTime;
        });
        const absenceCount = recentAtt.length;
        if (absenceCount >= 2) { riskTypes.push('출결주의'); reasons.push(`최근 14일 결석 ${absenceCount}회`); }
        
        // [Stabilization] 숙제 14일 필터 실제 적용
        const recentHw = homeworkHistory.filter(h => {
            if (String(h.student_id) !== String(s.id)) return false;
            if (h.status !== '미완료') return false;
            const t = getRecordTime(h.date);
            return t !== null && t >= cutoffTime && t <= todayTime;
        });
        const hwMissCount = recentHw.length;
        if (hwMissCount >= 3) { riskTypes.push('숙제주의'); reasons.push(`최근 14일 숙제 미완료 ${hwMissCount}회`); }
        
        const exams = examSessions.filter(e => e.student_id === s.id)
            .sort((a,b) => String(b.exam_date).localeCompare(String(a.exam_date)) || String(b.id).localeCompare(String(a.id)))
            .slice(0, 3);
        
        let scoreSummary = '';
        if (exams.length > 0) {
            scoreSummary = exams.map(e => `${e.score}점`).join(' ← ');
            const avg = exams.reduce((acc, cur) => acc + cur.score, 0) / exams.length;
            let scoreRisk = false;
            if (avg < 60) {
                scoreRisk = true; reasons.push(`최근 3회 평균 ${Math.round(avg)}점`);
            } else if (exams.length >= 3) {
                if (exams[0].score < exams[1].score && exams[1].score < exams[2].score) { scoreRisk = true; reasons.push(`시험성적 2회 연속 하락`); }
            }
            if (scoreRisk) riskTypes.push('성적주의');
        }
        
        const cns = consultations.filter(c => c.student_id === s.id).sort((a,b) => String(b.date).localeCompare(String(a.date)));
        let lastCnsDate = cns.length ? cns[0].date : '없음';
        let cnsDaysDiff = 999;
        if (cns.length > 0) {
            const cnsTime = apParseLocalDateTime(cns[0].date);
            if (cnsTime !== null) {
                cnsDaysDiff = (todayTime - cnsTime) / (1000*3600*24);
            }
        }
        
        let isNewStudent = false;
        if (s.created_at) {
            const createTime = apParseLocalDateTime(s.created_at);
            if (createTime !== null && (todayTime - createTime) / (1000*3600*24) <= 14) isNewStudent = true;
        }
        
        if (cnsDaysDiff >= 30 && !isNewStudent) { riskTypes.push('상담필요'); reasons.push(`최근 30일 상담 기록 없음`); }
        
        // [Stabilization] 종합주의 중복 방어
        if (riskTypes.length >= 2 && !riskTypes.includes('종합주의')) { 
            riskTypes.push('종합주의'); 
        }
        
        if (riskTypes.length > 0) {
            const cId = classStudents.find(m => m.student_id === s.id)?.class_id;
            const cName = classes.find(c => c.id === cId)?.name || '미배정';
            risks.push({ student: s, className: cName, riskTypes, reasons, scoreSummary, absenceCount, hwMissCount, lastConsultationDate: lastCnsDate });
        }
    });
    
    return risks;
}

// [Final Fix] 관리 메뉴 퇴원생 버튼과 연동
function openDischargedStudents() {
    openAdminStudentList('discharged');
}

function openRiskStudentReport(studentId) {
    const risks = typeof computeRiskStudents === 'function' ? computeRiskStudents() : [];
    const risk = risks.find(r => String(r.student?.id) === String(studentId));
    if (typeof openStudentReportModal === 'function') {
        openStudentReportModal(studentId, { riskInfo: risk || null, title: '관리필요 학생 문구 생성' });
        return;
    }
    toast('보고 문구 모듈을 불러오지 못했습니다.', 'warn');
}

async function restoreDischargedStudent(sid) {
    if (!confirm('이 학생을 재원으로 복구하시겠습니까?')) return;
    const r = await api.patch(`students/${sid}/restore`, {});
    if (r?.success) { await loadData(); openAdminStudentList('discharged'); }
    else toast(r?.message || r?.error || '복구에 실패했습니다.', 'error');
}

async function hideDischargedStudent(sid) {
    if (!confirm('퇴원생 목록에서 숨길까요?')) return;
    const r = await api.patch(`students/${sid}/hide`, {});
    if (r?.success) { await loadData(); openAdminStudentList('discharged'); }
    else toast(r?.message || r?.error || '목록숨김 처리에 실패했습니다.', 'error');
}

function openAdminStudentList(type) {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr);
    let list = [], title = "";

    if (type === 'active') { 
        list = state.db.students.filter(s => s.status === '재원'); 
        title = "재원생 목록"; 
    } else if (type === 'new') { 
        list = state.db.students.filter(s => { 
            if (s.status !== '재원' || !s.created_at || todayTime === null) return false; 
            const createdTime = apParseLocalDateTime(s.created_at);
            if (createdTime === null) return false;
            return (todayTime - createdTime) / (1000*3600*24) <= 30; 
        }); 
        title = "최근 등록 원생"; 
    } else if (type === 'discharged') { 
        list = state.db.students.filter(s => s.status === '제적'); 
        title = "퇴원생 목록"; 
    } else if (type === 'risk') { 
        list = computeRiskStudents().map(r => ({ ...r.student, riskInfo: r })); 
        title = "관리필요 학생"; 
    }

    const rows = list.map(s => {
        const cId = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const cName = state.db.classes.find(c => c.id === cId)?.name || '미배정';
        let riskDetails = "";
        if (s.riskInfo) { riskDetails = `<div style="font-size:11px; color:var(--error); margin-top:6px; background:rgba(255,71,87,0.08); padding:6px 8px; border-radius:6px; font-weight:600;">상태: ${s.riskInfo.riskTypes.join(', ')} <span style="opacity:0.7; font-weight:normal;">(${s.riskInfo.reasons.join(' · ')})</span></div>`; }
        const actionButtons = type === 'discharged'
            ? `
                <div style="display:flex; gap:6px; justify-content:flex-end; flex-wrap:wrap;">
                    <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:700; border-radius:10px; background:var(--surface-2); border:none; cursor:pointer;" onclick="closeModal(); renderStudentDetail('${s.id}')">상세 보기</button>
                    <button class="btn btn-primary" style="padding:7px 10px; font-size:11px; font-weight:700; border-radius:10px; box-shadow:none; cursor:pointer;" onclick="restoreDischargedStudent('${s.id}')">복구</button>
                    <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:700; border-radius:10px; background:var(--surface-2); color:var(--secondary); border:1px solid var(--border); cursor:pointer;" onclick="hideDischargedStudent('${s.id}')">목록숨김</button>
                </div>
            `
            : `<button class="btn" style="padding:8px 12px; font-size:12px; font-weight:700; border-radius:8px; background:var(--surface-2); border:none;" onclick="closeModal(); renderStudentDetail('${s.id}')">상세 보기</button>`;
        return `
            <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--surface);">
                <div style="flex:1; padding-right:12px;">
                    <div style="font-weight:700; font-size:14px; color:var(--text);">${apEscapeHtml(s.name)} <span style="font-size:12px; color:var(--secondary); font-weight:600; margin-left:4px;">${apEscapeHtml(s.school_name || '')} ${apEscapeHtml(s.grade || '')}</span></div>
                    <div style="font-size:12px; color:var(--primary); font-weight:600; margin-top:4px;">${apEscapeHtml(cName)} <span style="color:var(--secondary); font-weight:500;">| ${apEscapeHtml(s.status)} ${s.created_at ? `| 등록: ${s.created_at.split(' ')[0]}` : ''}</span></div>
                    ${riskDetails}
                </div>
                ${actionButtons}
            </div>
        `;
    }).join('');

    showModal(`${title} (${list.length}명)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:600;">조회 대상이 없습니다.</div>`}</div>`);
}


function openAdminOperationMenu() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const isAdmin = String(state?.auth?.role || '') === 'admin';
    const showBillingAccountingFoundationEntry = false;
    const cardStyle = 'padding:16px; border:1px solid var(--border); border-radius:16px; background:var(--surface); text-align:left; cursor:pointer; box-shadow:none; min-height:92px; align-items:flex-start; justify-content:flex-start; flex-direction:column; gap:6px;';
    const titleStyle = 'font-size:14px; font-weight:800; color:var(--text); line-height:1.35;';
    const descStyle = 'font-size:12px; font-weight:650; color:var(--secondary); line-height:1.5; margin-top:4px;';

    showModal('관리', `
        <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
            <button class="btn" style="${cardStyle}" onclick="openAdminTeacherAccountManage()">
                <div style="${titleStyle}">선생님 계정</div>
                <div style="${descStyle}">선생님 계정 생성, 권한 수정, 비밀번호 초기화</div>
            </button>
            <button class="btn" style="${cardStyle}" onclick="renderAdminJournalList('${todayStr}')">
                <div style="${titleStyle}">일지 확인</div>
                <div style="${descStyle}">제출된 일지를 날짜별로 확인하고 피드백 작성</div>
            </button>
            <button class="btn" style="${cardStyle}" onclick="openAdminStudentList('discharged')">
                <div style="${titleStyle}">퇴원생 관리</div>
                <div style="${descStyle}">퇴원생 조회, 복구, 목록숨김 처리</div>
            </button>
            <button class="btn" style="${cardStyle}" onclick="openAdminPinBatchModal()">
                <div style="${titleStyle}">PIN 생성</div>
                <div style="${descStyle}">전체 재원생 중 PIN 없는 재원생에게만 자동 부여</div>
            </button>
            ${isAdmin && showBillingAccountingFoundationEntry ? `
            <button class="btn" style="${cardStyle}" onclick="if(typeof openBillingAccountingFoundationModal==='function') openBillingAccountingFoundationModal(); else toast('수납·출납 foundation 화면을 불러오지 못했습니다.', 'warn');">
                <div style="${titleStyle}">수납·출납 foundation</div>
                <div style="${descStyle}">결제수단, 수납 정책, 요약, 조회 목록 확인</div>
            </button>
            ` : ''}
        </div>
        <div style="margin-top:14px; padding:12px 14px; border-radius:14px; background:var(--surface-2); color:var(--secondary); font-size:12px; font-weight:700; line-height:1.55;">
            반 담당 변경과 담임 일괄 변경은 Worker 구조분리 이후 별도 연결합니다.
        </div>
    `);
}

function openAdminPinBatchModal() {
    const activeStudents = (state.db.students || []).filter(s => String(s.status || '재원') === '재원');
    const missingPins = activeStudents.filter(s => !String(s.student_pin || '').trim());

    const gradeOrder = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const gradeCounts = gradeOrder
        .map(grade => {
            const total = activeStudents.filter(s => String(s.grade || '').includes(grade)).length;
            const missing = missingPins.filter(s => String(s.grade || '').includes(grade)).length;
            return { grade, total, missing };
        })
        .filter(row => row.total > 0 || row.missing > 0);

    const gradeHtml = gradeCounts.map(row => `
        <div style="display:flex; justify-content:space-between; align-items:center; min-height:32px; padding:6px 0; border-bottom:1px solid var(--border);">
            <span style="font-size:13px; font-weight:800; color:var(--text);">${apEscapeHtml(row.grade)}</span>
            <span style="font-size:12px; font-weight:700; color:var(--secondary);">미발급 ${row.missing}명 / 재원 ${row.total}명</span>
        </div>
    `).join('');

    showModal('PIN 생성', `
        <div style="display:flex; flex-direction:column; gap:14px;">
            <div style="padding:12px 14px; border-radius:14px; background:var(--surface-2); color:var(--secondary); font-size:12px; font-weight:700; line-height:1.55;">
                PIN 없는 재원생에게만 학년 규칙에 맞춰 번호를 부여합니다. 기존 PIN은 바뀌지 않습니다.
            </div>

            <div style="border:1px solid var(--border); border-radius:16px; background:var(--surface); padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-end; gap:10px; margin-bottom:10px;">
                    <div>
                        <div style="font-size:13px; font-weight:800; color:var(--text); line-height:1.35;">미발급 PIN</div>
                        <div style="font-size:12px; font-weight:700; color:var(--secondary); line-height:1.45; margin-top:2px;">대상 ${missingPins.length}명 / 재원 ${activeStudents.length}명</div>
                    </div>
                    <div style="font-size:20px; font-weight:800; color:var(--primary); line-height:1;">${missingPins.length}</div>
                </div>
                <button class="btn btn-primary" style="width:100%; min-height:52px; border-radius:14px; font-size:14px; font-weight:800; box-shadow:none;" onclick="handleAdminBatchGeneratePins()" ${missingPins.length ? '' : 'disabled'}>
                    미발급 PIN 생성
                </button>
            </div>

            <div style="border:1px solid var(--border); border-radius:16px; background:var(--surface); padding:12px 14px;">
                <div style="font-size:12px; font-weight:800; color:var(--secondary); margin-bottom:6px;">학년별 현황</div>
                ${gradeHtml || `<div style="font-size:13px; color:var(--secondary); font-weight:700; text-align:center; padding:16px 0;">재원생 정보가 없습니다.</div>`}
            </div>
        </div>
    `);
}

function getAdminClassGradeRank(cls) {
    const text = `${cls?.grade || ''} ${cls?.name || ''}`;
    const order = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const idx = order.findIndex(g => text.includes(g));
    return idx === -1 ? order.length : idx;
}

async function handleAdminBatchGeneratePins() {
    const activeStudents = (state.db.students || []).filter(s => String(s.status || '재원') === '재원');
    const missingPins = activeStudents.filter(s => !String(s.student_pin || '').trim());

    if (!missingPins.length) {
        toast('PIN 미발급 학생이 없습니다.', 'info');
        return;
    }

    if (!confirm(`PIN 없는 학생 ${missingPins.length}명에게 번호를 생성할까요?\n기존 PIN은 바뀌지 않습니다.`)) return;

    try {
        const r = await api.post('students/batch-pins', {});
        if (r?.success) {
            toast(`PIN ${r.count || 0}개 생성 완료`, 'success');
            await loadData();
            openAdminPinBatchModal();
            return;
        }
        toast(r?.message || r?.error || 'PIN 생성에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminBatchGeneratePins] failed:', e);
        toast('PIN 생성 중 오류가 발생했습니다.', 'error');
    }
}

function getAdminTeacherRows() {
    return Array.isArray(state?.ui?.adminTeacherRows) ? state.ui.adminTeacherRows : [];
}

function adminTeacherRoleLabel(role) {
    return String(role || '') === 'admin' ? '원장' : '선생님';
}

async function openAdminTeacherAccountManage() {
    showModal('선생님 계정', `<div style="text-align:center; padding:36px; color:var(--secondary); font-size:13px; font-weight:700;">선생님 계정을 불러오는 중입니다.</div>`);

    try {
        const data = await api.get('teachers');
        if (data?.error) return toast(data.error || '선생님 계정을 불러오지 못했습니다.', 'error');
        if (!state.ui) state.ui = {};
        state.ui.adminTeacherRows = Array.isArray(data.teachers) ? data.teachers : [];
        renderAdminTeacherAccountManage();
    } catch (e) {
        console.error('[openAdminTeacherAccountManage] failed:', e);
        toast('선생님 계정 조회 중 오류가 발생했습니다.', 'error');
    }
}

function renderAdminTeacherAccountManage() {
    const teachers = getAdminTeacherRows().slice().sort((a, b) => {
        const ar = String(a.role || '') === 'admin' ? 0 : 1;
        const br = String(b.role || '') === 'admin' ? 0 : 1;
        if (ar !== br) return ar - br;
        return String(a.name || '').localeCompare(String(b.name || ''), 'ko');
    });

    const rows = teachers.map(t => {
        const safeId = apEscapeHtml(String(t.id || ''));
        const role = String(t.role || 'teacher');
        const roleColor = role === 'admin' ? 'var(--error)' : 'var(--primary)';
        const roleBg = role === 'admin' ? 'rgba(255,71,87,0.08)' : 'rgba(26,92,255,0.08)';
        return `
            <div style="padding:14px 0; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:12px;">
                <div style="min-width:0; flex:1;">
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <b style="font-size:14px; color:var(--text); line-height:1.35;">${apEscapeHtml(t.name || '')}</b>
                        <span style="font-size:11px; font-weight:800; color:${roleColor}; background:${roleBg}; padding:3px 8px; border-radius:999px;">${adminTeacherRoleLabel(role)}</span>
                    </div>
                    <div style="font-size:12px; color:var(--secondary); font-weight:700; margin-top:4px; line-height:1.4;">ID ${apEscapeHtml(t.login_id || '')}</div>
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
                    <button class="btn" style="min-height:34px; padding:6px 10px; font-size:11px; font-weight:800; border-radius:10px; background:var(--surface-2); border:none;" onclick="openAdminEditTeacherModal('${safeId}')">수정</button>
                    <button class="btn" style="min-height:34px; padding:6px 10px; font-size:11px; font-weight:800; border-radius:10px; background:rgba(255,165,2,0.10); color:var(--warning); border:none;" onclick="openAdminResetTeacherPasswordModal('${safeId}')">PW 초기화</button>
                </div>
            </div>
        `;
    }).join('');

    showModal('선생님 계정', `
        <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:800; margin-bottom:14px;" onclick="openAdminCreateTeacherModal()">새 선생님 계정</button>
        <div style="max-height:58vh; overflow-y:auto; padding-right:4px;">
            ${rows || `<div style="text-align:center; padding:28px; color:var(--secondary); font-size:13px; font-weight:700;">등록된 선생님 계정이 없습니다.</div>`}
        </div>
    `);
}

function openAdminCreateTeacherModal() {
    showModal('새 선생님 계정', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <input id="admin-new-teacher-name" class="btn" placeholder="이름" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <input id="admin-new-teacher-login" class="btn" placeholder="로그인 ID" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <input id="admin-new-teacher-password" type="password" class="btn" placeholder="초기 비밀번호" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <select id="admin-new-teacher-role" class="btn" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
                <option value="teacher">선생님</option>
                <option value="admin">원장</option>
            </select>
            <div style="font-size:12px; color:var(--secondary); font-weight:700; line-height:1.5; background:var(--surface-2); padding:10px 12px; border-radius:12px;">계정 생성 후 담당반 배정은 반 관리/담당 변경 메뉴에서 별도로 진행합니다.</div>
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:800;" onclick="handleAdminCreateTeacher()">생성</button>
        </div>
    `);
}

async function handleAdminCreateTeacher() {
    const name = document.getElementById('admin-new-teacher-name')?.value.trim() || '';
    const loginId = document.getElementById('admin-new-teacher-login')?.value.trim() || '';
    const password = document.getElementById('admin-new-teacher-password')?.value.trim() || '';
    const role = document.getElementById('admin-new-teacher-role')?.value || 'teacher';

    if (!name || !loginId || !password) return toast('이름, ID, 비밀번호를 모두 입력하세요.', 'warn');
    if (password.length < 4) return toast('비밀번호는 4자 이상으로 입력하세요.', 'warn');

    try {
        const r = await api.post('teachers', { name, login_id: loginId, password, role });
        if (r?.success) {
            toast('선생님 계정이 생성되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '선생님 계정 생성에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminCreateTeacher] failed:', e);
        toast('선생님 계정 생성 중 오류가 발생했습니다.', 'error');
    }
}

function openAdminEditTeacherModal(teacherId) {
    const teacher = getAdminTeacherRows().find(t => String(t.id) === String(teacherId));
    if (!teacher) return toast('선생님 계정을 찾을 수 없습니다.', 'warn');

    showModal('선생님 계정 수정', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="font-size:12px; color:var(--secondary); font-weight:800; padding:0 4px;">로그인 ID: ${apEscapeHtml(teacher.login_id || '')}</div>
            <input id="admin-edit-teacher-name" class="btn" value="${apEscapeHtml(teacher.name || '')}" placeholder="이름" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <select id="admin-edit-teacher-role" class="btn" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
                <option value="teacher" ${String(teacher.role || '') !== 'admin' ? 'selected' : ''}>선생님</option>
                <option value="admin" ${String(teacher.role || '') === 'admin' ? 'selected' : ''}>원장</option>
            </select>
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:800;" onclick="handleAdminUpdateTeacher('${apEscapeHtml(String(teacher.id || ''))}')">저장</button>
        </div>
    `);
}

async function handleAdminUpdateTeacher(teacherId) {
    const name = document.getElementById('admin-edit-teacher-name')?.value.trim() || '';
    const role = document.getElementById('admin-edit-teacher-role')?.value || 'teacher';
    if (!name) return toast('이름을 입력하세요.', 'warn');

    try {
        const r = await api.patch(`teachers/${teacherId}`, { name, role });
        if (r?.success) {
            toast('선생님 계정이 수정되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '선생님 계정 수정에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminUpdateTeacher] failed:', e);
        toast('선생님 계정 수정 중 오류가 발생했습니다.', 'error');
    }
}

function openAdminResetTeacherPasswordModal(teacherId) {
    const teacher = getAdminTeacherRows().find(t => String(t.id) === String(teacherId));
    if (!teacher) return toast('선생님 계정을 찾을 수 없습니다.', 'warn');

    showModal('비밀번호 초기화', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="font-size:13px; color:var(--text); font-weight:800; line-height:1.5; background:var(--surface-2); padding:12px; border-radius:12px;">${apEscapeHtml(teacher.name || '')} 선생님의 비밀번호를 새 값으로 초기화합니다.</div>
            <input id="admin-reset-teacher-password" type="password" class="btn" placeholder="새 비밀번호" style="width:100%; text-align:left; background:var(--surface-2); border:none;">
            <button class="btn btn-primary" style="width:100%; min-height:46px; border-radius:14px; font-size:13px; font-weight:800;" onclick="handleAdminResetTeacherPassword('${apEscapeHtml(String(teacher.id || ''))}')">초기화</button>
        </div>
    `);
}

async function handleAdminResetTeacherPassword(teacherId) {
    const newPassword = document.getElementById('admin-reset-teacher-password')?.value.trim() || '';
    if (!newPassword) return toast('새 비밀번호를 입력하세요.', 'warn');
    if (newPassword.length < 4) return toast('비밀번호는 4자 이상으로 입력하세요.', 'warn');
    if (!confirm('비밀번호를 초기화할까요?')) return;

    try {
        const r = await api.patch(`teachers/${teacherId}/reset-password`, { new_password: newPassword });
        if (r?.success) {
            toast('비밀번호가 초기화되었습니다.', 'success');
            await openAdminTeacherAccountManage();
            return;
        }
        toast(r?.message || r?.error || '비밀번호 초기화에 실패했습니다.', 'error');
    } catch (e) {
        console.error('[handleAdminResetTeacherPassword] failed:', e);
        toast('비밀번호 초기화 중 오류가 발생했습니다.', 'error');
    }
}

// ─────────────────────────────────────────────
// [Admin Overview] 원장모드 상시 운영 요약
// ─────────────────────────────────────────────
function adminNormalizeStatus(value) {
    return String(value || '재원').trim() || '재원';
}

function adminGetStudentClassMap(studentId) {
    return (state.db.class_students || []).find(m => String(m.student_id) === String(studentId)) || null;
}

function adminGetClassById(classId) {
    return (state.db.classes || []).find(c => String(c.id) === String(classId)) || null;
}

function adminGetStudentClass(studentId) {
    const map = adminGetStudentClassMap(studentId);
    return map ? adminGetClassById(map.class_id) : null;
}

function adminGetClassStudentIds(classId) {
    return (state.db.class_students || [])
        .filter(m => String(m.class_id) === String(classId))
        .map(m => String(m.student_id));
}

function adminGetCreatedDateText(student) {
    return String(student?.created_at || '').split('T')[0].split(' ')[0];
}

function adminGetDaysSince(dateText, todayTime) {
    const time = apParseLocalDateTime(dateText);
    if (time === null) return null;
    return Math.max(0, Math.floor((todayTime - time) / (1000 * 60 * 60 * 24)) + 1);
}

function adminIsRecentStudent(student, todayTime, days = 30) {
    const createdDate = adminGetCreatedDateText(student);
    const createdTime = apParseLocalDateTime(createdDate);
    if (createdTime === null) return false;
    const diff = (todayTime - createdTime) / (1000 * 60 * 60 * 24);
    return diff >= 0 && diff <= days;
}

function adminBuildOverviewData(todayStr, todayTime) {
    const students = state.db.students || [];
    const classes = state.db.classes || [];
    const maps = state.db.class_students || [];

    const activeStudents = students.filter(s => adminNormalizeStatus(s.status) === '재원');
    const dischargedStudents = students.filter(s => adminNormalizeStatus(s.status) === '제적');
    const leaveStudents = students.filter(s => adminNormalizeStatus(s.status) === '휴원');
    const recentStudents = activeStudents
        .filter(s => adminIsRecentStudent(s, todayTime, 30))
        .sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')) || String(a.name || '').localeCompare(String(b.name || ''), 'ko'));

    const missingPinStudents = activeStudents.filter(s => !String(s.student_pin || '').trim());
    const unassignedStudents = activeStudents.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return true;
        const cls = adminGetClassById(map.class_id);
        return !cls;
    });

    const teacherlessClasses = classes.filter(c => {
        if (Number(c.is_active) === 0) return false;
        const teacherName = String(c.teacher_name || '').trim();
        return !teacherName || teacherName === '담당';
    });

    const cleanupStudents = students.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return false;
        const cls = adminGetClassById(map.class_id);
        const status = adminNormalizeStatus(s.status);
        if (status !== '재원') return true;
        return !!cls && Number(cls.is_active) === 0;
    });

    return {
        todayStr,
        todayTime,
        activeStudents,
        dischargedStudents,
        leaveStudents,
        recentStudents,
        missingPinStudents,
        unassignedStudents,
        teacherlessClasses,
        cleanupStudents
    };
}

function adminOpenStudentEditOrDetail(studentId) {
    if (typeof openEditStudent === 'function') {
        openEditStudent(studentId, { returnTo: { type: 'dashboard' } });
        return;
    }
    closeModal(true);
    if (typeof renderStudentDetail === 'function') renderStudentDetail(studentId);
    else toast('학생 화면을 불러오지 못했습니다.', 'warn');
}

function renderAdminMiniMetric(label, value, tone = 'text', onclick = '') {
    const colorMap = {
        primary: 'var(--primary)',
        success: 'var(--success)',
        warning: 'var(--warning)',
        error: 'var(--error)',
        secondary: 'var(--secondary)',
        text: 'var(--text)'
    };
    const color = colorMap[tone] || colorMap.text;
    const clickAttr = onclick ? ` onclick="${onclick}"` : '';
    const cursor = onclick ? 'cursor:pointer;' : '';
    return `
        <div class="ap-admin-mini-metric"${clickAttr} style="${cursor} min-height:62px; padding:11px 8px; border-radius:14px; background:var(--surface); border:1px solid var(--border); display:flex; flex-direction:column; align-items:center; justify-content:center; box-sizing:border-box;">
            <div style="font-size:18px; font-weight:700; color:${color}; line-height:1;">${value}</div>
            <div style="font-size:11px; font-weight:700; color:var(--secondary); margin-top:6px; line-height:1.25; white-space:nowrap;">${label}</div>
        </div>
    `;
}

function renderAdminStudentOverviewPanel(data) {
    return `
        <div class="ap-admin-section" style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:15px; font-weight:700; color:var(--text);">오늘 운영</h3>
            </div>
            <div class="ap-admin-overview-grid" style="display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px; padding:4px; border:1px solid var(--border); border-radius:18px; background:var(--surface-2);">
                ${renderAdminMiniMetric('재원', data.activeStudents.length, 'primary', "openAdminStudentList('active')")}
                ${renderAdminMiniMetric('최근 등록', data.recentStudents.length, 'success', "openAdminStudentList('new')")}
                ${renderAdminMiniMetric('퇴원', data.dischargedStudents.length, 'secondary', "openAdminStudentList('discharged')")}
                ${renderAdminMiniMetric('휴원', data.leaveStudents.length, 'warning', "openAdminLeaveStudentList()")}
            </div>
        </div>
    `;
}

function renderAdminNeedCheckPanel(data) {
    const items = [
        { label: '반 배정 필요', value: data.unassignedStudents.length, action: 'openAdminUnassignedStudentList()' },
        { label: 'PIN 미발급', value: data.missingPinStudents.length, action: 'openAdminPinBatchModal()' },
        { label: '담당 선생님 미지정', value: data.teacherlessClasses.length, unit: '개', action: 'openAdminTeacherlessClassList()' },
        { label: '반 정리 필요', value: data.cleanupStudents.length, action: 'openAdminClassCleanupList()' }
    ];

    return `
        <div class="ap-admin-section" style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:15px; font-weight:700; color:var(--text);">확인 필요</h3>
            </div>
            <div style="display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px;">
                ${items.map(item => {
                    const hasIssue = Number(item.value || 0) > 0;
                    return `
                        <button class="btn ap-admin-check-item" style="min-height:52px; padding:0 10px; border-radius:16px; border:1px solid ${hasIssue ? 'rgba(255,71,87,0.18)' : 'var(--border)'}; background:${hasIssue ? 'rgba(255,71,87,0.045)' : 'var(--surface)'}; box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:8px;" onclick="${item.action}">
                            <span style="min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--text); font-size:12px; font-weight:700;">${item.label}</span>
                            <span style="flex-shrink:0; font-size:13px; font-weight:800; color:${hasIssue ? 'var(--error)' : 'var(--secondary)'};">${item.value}${item.unit || '명'}</span>
                        </button>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function renderAdminNewStudentPanel(data) {
    const list = data.recentStudents.slice(0, 4);
    const rows = list.map(s => {
        const cls = adminGetStudentClass(s.id);
        const days = adminGetDaysSince(adminGetCreatedDateText(s), data.todayTime);
        const attCount = (state.db.attendance_history || state.db.attendance || []).filter(a => String(a.student_id) === String(s.id)).length;
        const hwCount = (state.db.homework_history || state.db.homework || []).filter(h => String(h.student_id) === String(s.id)).length;
        const examCount = (state.db.exam_sessions || []).filter(e => String(e.student_id) === String(s.id)).length;
        const hasPin = !!String(s.student_pin || '').trim();
        const hasClass = !!cls;
        const recordText = examCount > 0 ? `시험 ${examCount}회` : (attCount + hwCount > 0 ? `기록 ${attCount + hwCount}회` : '기록 없음');
        return `
            <div onclick="closeModal(true); renderStudentDetail('${s.id}')" style="height:46px; min-height:46px; padding:0 12px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; box-sizing:border-box;">
                <div style="min-width:0; display:flex; align-items:center; gap:8px;">
                    <b style="font-size:13px; color:var(--text); white-space:nowrap;">${apEscapeHtml(s.name)}</b>
                    <span style="font-size:11px; color:var(--secondary); font-weight:700; white-space:nowrap;">등록 ${days || '-'}일차</span>
                </div>
                <div style="display:flex; align-items:center; gap:5px; flex-shrink:0; min-width:0;">
                    <span style="font-size:10.5px; font-weight:800; color:${hasPin ? 'var(--success)' : 'var(--error)'}; background:${hasPin ? 'rgba(0,208,132,0.08)' : 'rgba(255,71,87,0.08)'}; padding:3px 6px; border-radius:999px; white-space:nowrap;">${hasPin ? 'PIN 완료' : 'PIN 필요'}</span>
                    <span style="font-size:10.5px; font-weight:800; color:${hasClass ? 'var(--primary)' : 'var(--error)'}; background:${hasClass ? 'rgba(26,92,255,0.08)' : 'rgba(255,71,87,0.08)'}; padding:3px 6px; border-radius:999px; white-space:nowrap;">${hasClass ? apEscapeHtml(cls.name) : '반 배정 필요'}</span>
                    <span style="font-size:10.5px; font-weight:800; color:var(--secondary); background:var(--surface-2); padding:3px 6px; border-radius:999px; white-space:nowrap;">${recordText}</span>
                </div>
            </div>
        `;
    }).join('');

    return `
        <div class="ap-admin-section" style="margin-bottom:28px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:15px; font-weight:700; color:var(--text);">최근 등록 원생</h3>
                <span style="font-size:12px; font-weight:700; color:var(--secondary);">최근 30일 ${data.recentStudents.length}명</span>
            </div>
            <div class="card" style="padding:0; overflow:hidden; border:1px solid var(--border); border-radius:16px; background:var(--surface);">
                ${rows || `<div style="height:52px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:700;">최근 등록 원생이 없습니다.</div>`}
            </div>
        </div>
    `;
}

function openAdminLeaveStudentList() {
    const list = (state.db.students || []).filter(s => adminNormalizeStatus(s.status) === '휴원');
    renderAdminSimpleStudentList('휴원생 목록', list);
}

function openAdminUnassignedStudentList() {
    const activeStudents = (state.db.students || []).filter(s => adminNormalizeStatus(s.status) === '재원');
    const list = activeStudents.filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return true;
        return !adminGetClassById(map.class_id);
    });
    renderAdminSimpleStudentList('반 배정 필요', list, true);
}

function openAdminClassCleanupList() {
    const list = (state.db.students || []).filter(s => {
        const map = adminGetStudentClassMap(s.id);
        if (!map) return false;
        const cls = adminGetClassById(map.class_id);
        const status = adminNormalizeStatus(s.status);
        if (status !== '재원') return true;
        return !!cls && Number(cls.is_active) === 0;
    });
    renderAdminSimpleStudentList('반 정리 필요', list, true);
}

function openAdminTeacherlessClassList() {
    const classes = (state.db.classes || []).filter(c => {
        if (Number(c.is_active) === 0) return false;
        const teacherName = String(c.teacher_name || '').trim();
        return !teacherName || teacherName === '담당';
    });

    const rows = classes.map(c => `
        <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:12px; background:var(--surface);">
            <div style="min-width:0;">
                <div style="font-size:14px; font-weight:800; color:var(--text); line-height:1.35;">${apEscapeHtml(c.name || '')}</div>
                <div style="font-size:12px; font-weight:700; color:var(--secondary); margin-top:3px;">${apEscapeHtml(c.grade || '')} · 담당 선생님 미지정</div>
            </div>
            <button class="btn" style="padding:7px 10px; font-size:11px; font-weight:800; border-radius:10px; background:var(--surface-2); border:none;" onclick="closeModal(true); if(typeof openClassManageModal==='function') openClassManageModal(); else toast('반 관리 화면을 불러오지 못했습니다.', 'warn');">반 관리</button>
        </div>
    `).join('');

    showModal(`담당 선생님 미지정 (${classes.length}개)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:700;">확인할 반이 없습니다.</div>`}</div>`);
}

function renderAdminSimpleStudentList(title, list, editable = false) {
    const rows = list.map(s => {
        const cls = adminGetStudentClass(s.id);
        const classText = cls ? cls.name : '미배정';
        const status = adminNormalizeStatus(s.status);
        const action = editable
            ? `<button class="btn" style="padding:7px 10px; font-size:11px; font-weight:800; border-radius:10px; background:rgba(26,92,255,0.08); color:var(--primary); border:none;" onclick="adminOpenStudentEditOrDetail('${s.id}')">수정</button>`
            : `<button class="btn" style="padding:7px 10px; font-size:11px; font-weight:800; border-radius:10px; background:var(--surface-2); border:none;" onclick="closeModal(true); renderStudentDetail('${s.id}')">상세</button>`;
        return `
            <div style="padding:14px 12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; gap:12px; background:var(--surface);">
                <div style="min-width:0; flex:1;">
                    <div style="font-weight:800; font-size:14px; color:var(--text); line-height:1.35;">${apEscapeHtml(s.name || '')} <span style="font-size:12px; color:var(--secondary); font-weight:700; margin-left:4px;">${apEscapeHtml(s.school_name || '')} ${apEscapeHtml(s.grade || '')}</span></div>
                    <div style="font-size:12px; color:var(--primary); font-weight:700; margin-top:4px;">${apEscapeHtml(classText)} <span style="color:var(--secondary); font-weight:600;">| ${apEscapeHtml(status)}</span></div>
                </div>
                ${action}
            </div>
        `;
    }).join('');

    showModal(`${title} (${list.length}명)`, `<div style="max-height:65vh; overflow-y:auto; padding-right:4px; margin:-12px; background:var(--bg);">${rows || `<div style="text-align:center; padding:40px; color:var(--secondary); font-size:13px; font-weight:700;">조회 대상이 없습니다.</div>`}</div>`);
}


// ─────────────────────────────────────────────
// [Admin Search] 원장모드 전체 검색
// ─────────────────────────────────────────────
function adminNormalizeSearchValue(value) {
    return String(value || '').toLowerCase().replace(/\s+/g, '');
}

function adminSearchIncludes(values, keyword) {
    const key = adminNormalizeSearchValue(keyword);
    if (!key) return false;
    return values.some(value => adminNormalizeSearchValue(value).includes(key));
}

function adminGetSearchClassNameByStudentId(studentId) {
    const cls = adminGetStudentClass(studentId);
    return cls ? String(cls.name || '') : '미배정';
}

function adminGetSearchClassNameByClassId(classId) {
    const cls = adminGetClassById(classId);
    return cls ? String(cls.name || '') : '미배정';
}

function adminGetAssignmentTypeLabel(row) {
    const sourceType = String(row?.source_type || '').trim().toLowerCase();
    const archiveFile = String(row?.archive_file || '').trim();
    if (sourceType === 'clinic') return '클리닉';
    if (sourceType === 'mixed' || archiveFile.startsWith('MIXED:')) return '믹서';
    if (archiveFile) return '아카이브';
    return '자료';
}

function adminBuildGlobalSearchResults(keyword) {
    const key = String(keyword || '').trim();
    if (!key) return [];

    const results = [];
    const students = state.db.students || [];
    const classes = state.db.classes || [];
    const examSchedules = state.db.exam_schedules || [];
    const assignments = state.db.class_exam_assignments || [];

    students.forEach(s => {
        const className = adminGetSearchClassNameByStudentId(s.id);
        if (!adminSearchIncludes([s.name, s.school_name, s.grade, s.status, s.phone, className], key)) return;
        results.push({
            type: 'student',
            label: s.name || '학생',
            meta: `${className} · ${s.school_name || ''} ${s.grade || ''}`.trim(),
            desc: adminNormalizeStatus(s.status),
            actionLabel: '학생 보기',
            studentId: s.id
        });
    });

    classes.forEach(c => {
        if (Number(c.is_active) === 0) return;
        if (!adminSearchIncludes([c.name, c.grade, c.teacher_name], key)) return;
        const count = adminGetClassStudentIds(c.id)
            .filter(id => students.some(s => String(s.id) === String(id) && adminNormalizeStatus(s.status) === '재원'))
            .length;
        results.push({
            type: 'class',
            label: c.name || '반',
            meta: `${c.grade || ''} · ${c.teacher_name || '담당 미지정'}`,
            desc: `재원 ${count}명`,
            actionLabel: '반 열기',
            classId: c.id
        });
    });

    examSchedules.forEach(e => {
        if (!adminSearchIncludes([e.school_name, e.grade, e.exam_name, e.exam_date], key)) return;
        results.push({
            type: 'exam',
            label: `${e.school_name || '학교'} ${e.exam_name || '시험'}`.trim(),
            meta: `${e.grade || '학교공통'} · ${e.exam_date || ''}`,
            desc: '시험일정',
            actionLabel: '일정 보기',
            examDate: e.exam_date
        });
    });

    assignments.forEach(row => {
        const className = adminGetSearchClassNameByClassId(row.class_id);
        if (!adminSearchIncludes([row.exam_title, row.exam_date, row.archive_file, row.source_type, className], key)) return;
        results.push({
            type: 'assignment',
            label: row.exam_title || '배정 자료',
            meta: `${className} · ${row.exam_date || ''}`,
            desc: `${adminGetAssignmentTypeLabel(row)} · ${Number(row.question_count || 0) ? `${row.question_count}문항` : '문항 수 없음'}`,
            actionLabel: '반 열기',
            classId: row.class_id
        });
    });

    const typeOrder = { student: 0, class: 1, exam: 2, assignment: 3 };
    results.sort((a, b) => {
        const ao = typeOrder[a.type] ?? 99;
        const bo = typeOrder[b.type] ?? 99;
        if (ao !== bo) return ao - bo;
        return String(a.label || '').localeCompare(String(b.label || ''), 'ko');
    });

    return results.slice(0, 18);
}

function adminSearchTypeLabel(type) {
    if (type === 'student') return '학생';
    if (type === 'class') return '반';
    if (type === 'exam') return '시험';
    if (type === 'assignment') return '자료';
    return '검색';
}

function renderAdminGlobalSearchResults(results) {
    if (!results.length) {
        return `<div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:700;">검색 결과가 없습니다.</div>`;
    }

    return results.map((item, idx) => `
        <button class="btn ap-admin-search-row"
                style="width:100%; min-height:48px; padding:8px 10px; border-radius:12px; border:1px solid var(--border); background:var(--surface); box-shadow:none; display:flex; justify-content:space-between; align-items:center; gap:10px; text-align:left;"
                onclick="openAdminGlobalSearchResult(${idx})">
            <div style="min-width:0; flex:1;">
                <div style="display:flex; align-items:center; gap:6px; min-width:0;">
                    <span style="flex-shrink:0; font-size:10px; font-weight:700; color:var(--primary); background:rgba(26,92,255,0.08); padding:2px 7px; border-radius:999px;">${adminSearchTypeLabel(item.type)}</span>
                    <b style="min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13px; color:var(--text); font-weight:700;">${apEscapeHtml(item.label)}</b>
                </div>
                <div style="margin-top:3px; font-size:11px; font-weight:700; color:var(--secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(item.meta || '')}${item.desc ? ` · ${apEscapeHtml(item.desc)}` : ''}</div>
            </div>
            <span style="flex-shrink:0; font-size:11px; font-weight:700; color:var(--secondary);">${apEscapeHtml(item.actionLabel || '열기')}</span>
        </button>
    `).join('');
}

function handleAdminGlobalSearchInput(value) {
    const area = document.getElementById('admin-global-search-results');
    if (!area) return;

    const keyword = String(value || '').trim();
    if (!state.ui) state.ui = {};
    if (!keyword) {
        state.ui.adminGlobalSearchResults = [];
        area.innerHTML = `<div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:700;">학생, 반, 학교, 시험, 자료를 검색하세요.</div>`;
        return;
    }

    const results = adminBuildGlobalSearchResults(keyword);
    state.ui.adminGlobalSearchResults = results;
    area.innerHTML = renderAdminGlobalSearchResults(results);
}

function openAdminGlobalSearchResult(index) {
    const item = (state.ui?.adminGlobalSearchResults || [])[Number(index)];
    if (!item) return toast('검색 결과를 찾을 수 없습니다.', 'warn');

    if (item.type === 'student' && item.studentId) {
        renderStudentDetail(item.studentId);
        return;
    }

    if ((item.type === 'class' || item.type === 'assignment') && item.classId) {
        if (typeof renderClass === 'function') renderClass(String(item.classId));
        else toast('반 화면을 불러오지 못했습니다.', 'warn');
        return;
    }

    if (item.type === 'exam') {
        if (typeof openExamScheduleModal === 'function') openExamScheduleModal();
        else toast('시험일정 화면을 불러오지 못했습니다.', 'warn');
        return;
    }

    toast('이 항목은 바로 열 수 없습니다.', 'warn');
}

function renderAdminGlobalSearchPanel() {
    return `
        <div class="ap-admin-section" style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:15px; font-weight:700; color:var(--text);">전체 검색</h3>
            </div>
            <div style="padding:10px; border:1px solid var(--border); border-radius:18px; background:var(--surface-2);">
                <input id="admin-global-search-input"
                       type="search"
                       autocomplete="off"
                       placeholder="학생 · 반 · 학교 · 시험 · 자료 검색"
                       oninput="handleAdminGlobalSearchInput(this.value)"
                       style="width:100%; height:44px; border:1px solid var(--border); border-radius:14px; background:var(--surface); color:var(--text); padding:0 14px; font-size:14px; font-weight:700; box-sizing:border-box;">
                <div id="admin-global-search-results" style="display:flex; flex-direction:column; gap:7px; margin-top:8px;">
                    <div style="height:48px; display:flex; align-items:center; justify-content:center; color:var(--secondary); font-size:13px; font-weight:700;">학생, 반, 학교, 시험, 자료를 검색하세요.</div>
                </div>
            </div>
        </div>
    `;
}


function renderAdminControlCenter() {
    if (typeof renderAppDrawer === 'function') renderAppDrawer();
    const root = document.getElementById('app-root');
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const activeStudents = state.db.students.filter(s => s.status === '재원');
    const dischargedStudents = state.db.students.filter(s => s.status === '제적');
    const newStudents = activeStudents.filter(s => { 
        if (!s.created_at) return false; 
        const createdTime = apParseLocalDateTime(s.created_at);
        if (createdTime === null) return false;
        return (todayTime - createdTime) / (1000*3600*24) <= 30; 
    });
    const adminOverviewData = adminBuildOverviewData(todayStr, todayTime);
    const headerHtml = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding:0 4px;">
            <h3 style="margin:0; font-size:15px; font-weight:700; color:var(--text);">운영센터</h3>
            <span style="font-size:12px; font-weight:700; color:var(--secondary);">원장님</span>
        </div>
    `;

    const adminShortcutRow = `
        <div class="ap-admin-shortcuts" style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:18px;">
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#0891b2; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openAttendanceLedger === 'function') openAttendanceLedger(); else toast('불러오기 실패', 'warn');">
                출석부
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#2563eb; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof renderTimetable === 'function') renderTimetable(); else toast('불러오기 실패', 'warn');">
                시간표
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#0f172a; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openSchoolExamLedger === 'function') openSchoolExamLedger(); else toast('불러오기 실패', 'warn');">
                성적표
            </button>
            <button class="btn"
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#7c3aed; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="openAdminOperationMenu()">
                관리
            </button>
        </div>
    `;

    const adminGlobalSearchPanel = typeof renderAdminGlobalSearchPanel === 'function' ? renderAdminGlobalSearchPanel() : '';

    const todayOverviewHtml = renderAdminStudentOverviewPanel(adminOverviewData);
    const needCheckHtml = renderAdminNeedCheckPanel(adminOverviewData);
    const recentStudentsHtml = renderAdminNewStudentPanel(adminOverviewData);

    const teacherCardsHtml = `
        <div class="ap-admin-section" style="margin-bottom:28px;">
            <div style="margin-bottom:12px;">
                <h3 class="ap-admin-section-title" style="margin:0; font-size:16px; font-weight:700; color:var(--text);">선생님 현황</h3>
            </div>
            <div class="ap-admin-teacher-grid" style="display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:12px; align-items:stretch;">
                ${renderAdminTeacherCards(todayStr)}
            </div>
        </div>
    `;

    const nextWeekTime = todayTime + 7 * 24 * 60 * 60 * 1000;
    const nextWeekStr = new Date(nextWeekTime).toLocaleDateString('sv-SE');
    const adminWeeklyItems = [];

    (state.db.exam_schedules || [])
        .filter(e => e.exam_date >= todayStr && e.exam_date <= nextWeekStr)
        .forEach(e => adminWeeklyItems.push({ type: 'exam', date: e.exam_date, item: e }));

    (state.db.academy_schedules || [])
        .filter(s =>
            String(s.is_deleted || 0) !== '1' &&
            String(s.target_scope || 'global') === 'global' &&
            s.schedule_date >= todayStr &&
            s.schedule_date <= nextWeekStr
        )
        .forEach(s => adminWeeklyItems.push({ type: 'academy', date: s.schedule_date, item: s }));

    adminWeeklyItems.sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));

    const adminScheduleHtml = `
        <div class="ap-admin-section" style="margin-bottom:32px;">
            <h3 class="ap-admin-section-title" style="margin:0 0 12px 0; font-size:15px; font-weight:700; color:var(--secondary);">주간일정</h3>
            <div class="card" style="padding:0; overflow:hidden; border:1px solid var(--border); border-radius:16px; background:var(--surface);">
                ${adminWeeklyItems.length > 0 ? adminWeeklyItems.map(w => {
                    const dateLabel = apFormatMonthDay(w.date) || w.date;
                    if (w.type === 'exam') {
                        const e = w.item;
                        const gradeLabel = e.grade ? `<span style="color:var(--secondary); font-weight:600;">${apEscapeHtml(e.grade)}</span> ` : '<span style="color:var(--secondary); font-weight:600;">학교공통</span> ';
                        return `<div style="display:flex; justify-content:space-between; align-items:center; min-height:52px; padding:0 16px; border-bottom:1px solid var(--border); font-size:13px; gap:10px; box-sizing:border-box;"><div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; font-weight:700; color:var(--error); background:rgba(255,71,87,0.08); padding:3px 8px; border-radius:8px; margin-right:6px;">시험</span><b style="font-weight:700; color:var(--text);">${apEscapeHtml(e.school_name)}</b> ${gradeLabel}${apEscapeHtml(e.exam_name)}</div><div style="color:var(--primary); font-size:11px; font-weight:600; white-space:nowrap; background:rgba(26,92,255,0.1); padding:2px 8px; border-radius:6px;">${dateLabel}</div></div>`;
                    }
                    const s = w.item;
                    const isClosed = s.schedule_type === 'closed' || s.is_closed === true || s.is_closed === 1;
                    const label = isClosed ? '휴무' : '기타';
                    const labelColor = isClosed ? 'var(--warning)' : 'var(--primary)';
                    const labelBg = isClosed ? 'rgba(255,165,2,0.12)' : 'rgba(26,92,255,0.08)';
                    const title = s.title || (isClosed ? '휴무' : '일정');
                    return `<div style="display:flex; justify-content:space-between; align-items:center; min-height:52px; padding:0 16px; border-bottom:1px solid var(--border); font-size:13px; gap:10px; box-sizing:border-box;"><div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; font-weight:700; color:${labelColor}; background:${labelBg}; padding:3px 8px; border-radius:8px; margin-right:6px;">${label}</span><b style="font-weight:700; color:var(--text);">${apEscapeHtml(title)}</b>${s.memo ? ` <span style="color:var(--secondary); font-weight:600;">${apEscapeHtml(s.memo)}</span>` : ''}</div><div style="color:var(--primary); font-size:11px; font-weight:600; white-space:nowrap; background:rgba(26,92,255,0.1); padding:2px 8px; border-radius:6px;">${dateLabel}</div></div>`;
                }).join('') : `<div style="text-align:center; padding:20px; color:var(--secondary); font-size:13px; font-weight:600;">이번 주 예정된 일정이 없습니다.</div>`}
            </div>
        </div>
    `;
    
    const adminUnifiedStyle = `
        <style>
            #ap-admin-dashboard { width:100%; max-width:850px; margin:0 auto; padding:0 16px 24px; box-sizing:border-box; }
            #ap-admin-dashboard .card,
            #ap-admin-dashboard .ap-admin-card {
                border:1px solid var(--border) !important;
                border-radius:18px !important;
                background:var(--surface) !important;
                box-shadow:0 1px 2px rgba(0,0,0,0.03) !important;
                box-sizing:border-box !important;
            }
            #ap-admin-dashboard .card[onclick],
            #ap-admin-dashboard .ap-admin-card[onclick],
            #ap-admin-dashboard button {
                -webkit-tap-highlight-color:transparent;
            }
            @media (hover:hover) {
                #ap-admin-dashboard .card[onclick]:hover,
                #ap-admin-dashboard .ap-admin-card[onclick]:hover {
                    transform:translateY(-1px);
                    border-color:rgba(26,92,255,0.16) !important;
                }
            }
            #ap-admin-dashboard .ap-admin-shortcuts {
                display:grid !important;
                grid-template-columns:repeat(4, minmax(0, 1fr));
                gap:8px !important;
                padding:4px !important;
                border:1px solid var(--border) !important;
                border-radius:18px !important;
                background:var(--surface-2) !important;
                margin-bottom:18px !important;
                box-shadow:none !important;
            }
            #ap-admin-dashboard .ap-admin-shortcuts .btn {
                height:44px !important;
                min-height:44px !important;
                max-height:44px !important;
                padding:0 10px !important;
                border-radius:14px !important;
                border:1px solid transparent !important;
                background:var(--surface) !important;
                color:var(--text) !important;
                box-shadow:0 1px 2px rgba(0,0,0,0.03) !important;
                font-size:13px !important;
                font-weight:700 !important;
                line-height:1.2 !important;
            }
            #ap-admin-dashboard .ap-admin-summary-grid,
            #ap-admin-dashboard .ap-admin-teacher-grid {
                align-items:stretch !important;
            }
            #ap-admin-dashboard .ap-admin-summary-grid .card {
                min-height:86px !important;
                display:flex !important;
                flex-direction:column !important;
                align-items:center !important;
                justify-content:center !important;
                padding:14px 8px !important;
            }
            #ap-admin-dashboard .ap-admin-teacher-grid .card {
                min-height:190px !important;
                height:100% !important;
                display:flex !important;
                flex-direction:column !important;
                justify-content:space-between !important;
            }
            #ap-admin-dashboard .ap-admin-section { margin-bottom:28px !important; }
            #ap-admin-dashboard .ap-admin-section-title { letter-spacing:-0.2px; }

            #ap-admin-dashboard .ap-admin-overview-grid {
                grid-template-columns:repeat(4, minmax(0, 1fr)) !important;
            }
            @media (max-width:1024px) and (min-width:721px) {
                #ap-admin-dashboard .ap-admin-teacher-grid { grid-template-columns:repeat(2, minmax(0, 1fr)) !important; }
            }
            #ap-admin-dashboard .ap-admin-check-item {
                -webkit-tap-highlight-color:transparent;
            }
            @media (max-width:720px) {
                #ap-admin-dashboard .ap-admin-overview-grid { grid-template-columns:repeat(2, minmax(0, 1fr)) !important; }
                #ap-admin-dashboard .ap-admin-teacher-grid { grid-template-columns:1fr !important; }
                #ap-admin-dashboard .ap-admin-check-item { min-height:50px !important; }
            }
            @media (max-width:480px) {
                #ap-admin-dashboard { padding-left:14px !important; padding-right:14px !important; }
                #ap-admin-dashboard .ap-admin-shortcuts { gap:6px !important; }
                #ap-admin-dashboard .ap-admin-shortcuts .btn { font-size:12px !important; padding:0 6px !important; }
                #ap-admin-dashboard .ap-admin-summary-grid { gap:8px !important; }
                #ap-admin-dashboard .ap-admin-summary-grid .card { min-height:78px !important; }
            }
        </style>
    `;

    root.innerHTML = `<div id="ap-admin-dashboard">
        ${adminUnifiedStyle}
        ${headerHtml}
        ${adminShortcutRow}
        ${todayOverviewHtml}
        ${teacherCardsHtml}
        ${adminScheduleHtml}
        ${needCheckHtml}
        ${recentStudentsHtml}
        ${adminGlobalSearchPanel}
    </div>`;
}

function renderAdminStudentSearch() {
    const keyword = document.getElementById('admin-search-input').value.trim().toLowerCase();
    const resultArea = document.getElementById('admin-search-results');
    if (!keyword) { resultArea.innerHTML = `<div style="color:var(--secondary); font-size:13px; text-align:center; padding:10px;">검색어를 입력하세요.</div>`; return; }
    
    const results = state.db.students.filter(s => s.name.toLowerCase().includes(keyword));
    if (results.length === 0) { resultArea.innerHTML = `<div style="color:var(--secondary); font-size:13px; text-align:center; padding:10px;">일치하는 학생이 없습니다.</div>`; return; }
    
    resultArea.innerHTML = results.map(s => {
        const cName = state.db.classes.find(c => c.id === state.db.class_students.find(m => m.student_id === s.id)?.class_id)?.name || '미배정';
        return `
            <div style="padding:10px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
                <div><b style="font-size:13px; color:var(--text);">${apEscapeHtml(s.name)}</b> <span style="font-size:11px; color:var(--secondary); margin-left:6px;">${apEscapeHtml(cName)} | ${apEscapeHtml(s.status)}</span></div>
                <button class="btn" style="padding:6px 10px; font-size:11px;" onclick="renderStudentDetail('${s.id}')">상세 보기</button>
            </div>
        `;
    }).join('');
}


// --- Teacher Dashboard 공통 함수 ---


























// [Partner B] 필수 입력 제거: 날짜만 있으면 저장 가능




// [Phase 4/5] 글로벌 진입점
function openGlobalExamGradeView() {
    const classes = state.db.classes.filter(c => Number(c.is_active) !== 0);
    const rows = classes.map(c => `
        <button class="btn" style="width:100%; justify-content:space-between; padding:16px; margin-bottom:10px; background:var(--surface); border:1px solid var(--border);" onclick="closeModal(); if(typeof openExamGradeView==='function') openExamGradeView('${c.id}')">
            <span style="font-weight:700; font-size:15px; color:var(--text);">${apEscapeHtml(c.name)}</span>
            <span style="font-size:12px; font-weight:700; color:var(--primary); background:rgba(26,92,255,0.1); padding:4px 10px; border-radius:8px;">${apEscapeHtml(c.grade)}</span>
        </button>
    `).join('');
    showModal('반별 시험성적', `
        <div style="margin-bottom:16px; font-size:13px; color:var(--secondary); font-weight:600;">조회할 반을 선택하세요.</div>
        <div style="max-height:60vh; overflow-y:auto; padding-right:4px;">${rows || `<div style="text-align:center; color:var(--secondary); padding:30px; font-size:13px; font-weight:600;">담당 반이 없습니다.</div>`}</div>
    `);
}

function openOperationMenu() {
    const isOnline = navigator.onLine;
    const qLen = typeof syncQueue !== 'undefined' ? syncQueue.length : 0;
    const syncStatusText = qLen > 0 ? `대기 ${qLen}건` : '대기 없음';
    const onlineStatusText = isOnline ? '연결됨' : '오프라인';

    showModal('시스템·동기화 상태', `
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="padding:16px; border-radius:14px; background:var(--surface-2); border:none;">
                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:600; margin-bottom:8px; color:var(--secondary);"><span>네트워크</span><b style="color:${isOnline ? 'var(--success)' : 'var(--error)'}">${onlineStatusText}</b></div>
                <div style="display:flex; justify-content:space-between; font-size:13px; font-weight:600; margin-bottom:16px; color:var(--secondary);"><span>미전송 데이터</span><b style="color:${qLen > 0 ? 'var(--warning)' : 'var(--success)'}">${syncStatusText}</b></div>
                <button class="btn btn-primary" style="width:100%; font-size:14px; font-weight:700; padding:12px; border-radius:10px;" onclick="if(typeof processSyncQueue==='function') processSyncQueue(); closeModal();">지금 동기화 시도</button>
            </div>
        </div>
    `);
}

function getClassGradeRank(grade) {
    const order = ['중1', '중2', '중3', '고1', '고2', '고3'];
    const idx = order.indexOf(grade);
    return idx >= 0 ? idx : 99;
}

function sortClassesForDashboard(classes) {
    return [...classes].sort((a, b) => {
        const aToday = isClassScheduledTodayForDashboard(a.id) ? 0 : 1;
        const bToday = isClassScheduledTodayForDashboard(b.id) ? 0 : 1;
        if (aToday !== bToday) return aToday - bToday;
        const aRank = getClassGradeRank(a.grade);
        const bRank = getClassGradeRank(b.grade);
        if (aRank !== bRank) return aRank - bRank;
        return (a.name || '').localeCompare(b.name || '');
    });
}

function computeDashboardData() {
    const today = new Date().toLocaleDateString('sv-SE');
    const activeStudents = state.db.students.filter(s => s.status === '재원');
    
    const scheduledActiveStudents = activeStudents.filter(s => {
        const cid = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const cls = state.db.classes.find(c => c.id === cid);
        if (cls && Number(cls.is_active) === 0) return false;
        return isClassScheduledTodayForDashboard(cid);
    });
    
    const scheduledIds = new Set(scheduledActiveStudents.map(s => s.id));
    
    const absentCount = state.db.attendance.filter(a => a.date === today && a.status === '결석' && scheduledIds.has(a.student_id)).length;
    const presentCount = scheduledActiveStudents.length - absentCount;
    
    const hwNotDoneCount = state.db.homework.filter(h => h.date === today && h.status === '미완료' && scheduledIds.has(h.student_id)).length;

    const todoCount = state.db.operation_memos.filter(m => {
        const isDone = m.is_done == 1 || m.is_done === true;
        const isPinned = m.is_pinned == 1 || m.is_pinned === true;
        return !isDone && (isPinned || m.memo_date === today);
    }).length;

    const classSummaries = {};
    state.db.classes.filter(c => Number(c.is_active) !== 0).forEach(c => {
        const cIds = state.db.class_students.filter(m => m.class_id === c.id).map(m => m.student_id);
        const cActiveIds = activeStudents.filter(s => cIds.includes(s.id)).map(s => s.id);
        let cMiss=0, cAbs=0;
        
        cActiveIds.forEach(id => {
            const att = state.db.attendance.find(a => a.student_id===id && a.date===today);
            if (att?.status === '결석') cAbs++;
            
            const hw = state.db.homework.find(h => h.student_id===id && h.date===today);
            if (hw?.status === '미완료') cMiss++;
        });
        
        let cPre = cActiveIds.length - cAbs;
        classSummaries[c.id] = { activeCount: cActiveIds.length, present: cPre, absent: cAbs, hwNotDone: cMiss, isScheduled: isClassScheduledTodayForDashboard(c.id) };
    });

    return { 
        global: { 
            totalActive: activeStudents.length, 
            scheduledActive: scheduledActiveStudents.length, 
            presentCount, 
            absentCount, 
            hwNotDoneCount,
            todoCount
        }, 
        classSummaries 
    };
}

function openDashboardClass(cid) {
    const safeCid = String(cid || '');
    if (!safeCid) {
        toast('학급 정보를 찾을 수 없습니다.', 'warn');
        return;
    }

    if (!state.ui) state.ui = {};
    state.ui.currentClassId = safeCid;

    if (typeof renderClass === 'function') {
        renderClass(safeCid);
        return;
    }

    if (typeof window !== 'undefined' && typeof window.renderClass === 'function') {
        window.renderClass(safeCid);
        return;
    }

    console.error('[AP Math OS] renderClass is not available. classroom.js load/order check required.', safeCid);
    toast('학급 화면 모듈을 불러오지 못했습니다.', 'error');
}

// [POLISH] 학급 카드: 수평적 미니멀리즘 레이아웃
function renderClassSummaryCard(cls, data) {
    const s = data.classSummaries[cls.id];
    if (!s) return '';

    const baseStyle = `
        cursor:pointer;
        display:flex;
        align-items:center;
        justify-content:space-between;
        height:52px;
        min-height:52px;
        max-height:52px;
        padding:0 16px;
        border-radius:16px;
        gap:12px;
        box-sizing:border-box;
        transition:all 0.2s ease;
        overflow:hidden;
    `;

    if (!s.isScheduled) {
        return `
            <div onclick="openDashboardClass('${cls.id}')" style="${baseStyle} opacity:0.68; filter:grayscale(18%); background:var(--surface-2); border:1px dashed var(--border);">
                <div style="font-weight:700; font-size:15px; color:var(--secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.name)}</div>
                <div style="font-size:12px; font-weight:600; color:var(--secondary); white-space:nowrap; flex-shrink:0;">수업 없음</div>
            </div>
        `;
    }

    const gradientBg = 'linear-gradient(135deg, rgba(225,29,72,0.04) 0%, var(--surface) 100%)';
    const borderColor = 'rgba(225,29,72,0.18)';

    return `
        <div onclick="openDashboardClass('${cls.id}')" style="${baseStyle} background:${gradientBg}; border:1px solid ${borderColor};">
            <div style="font-weight:700; font-size:15px; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.name)}</div>
            <div style="display:flex; gap:6px; align-items:center; flex-shrink:0;">
                <div style="height:26px; display:inline-flex; align-items:center; background:var(--bg); border-radius:8px; padding:0 8px; font-size:11px; font-weight:700; color:var(--secondary); border:1px solid var(--border); white-space:nowrap;">재원 <span style="color:var(--text); margin-left:3px;">${s.activeCount}</span></div>
                <div style="height:26px; display:inline-flex; align-items:center; background:var(--bg); border-radius:8px; padding:0 8px; font-size:11px; font-weight:700; color:var(--secondary); border:1px solid var(--border); white-space:nowrap;">등원 <span style="color:var(--success); margin-left:3px;">${s.present}</span></div>
                <div style="height:26px; display:inline-flex; align-items:center; background:var(--bg); border-radius:8px; padding:0 8px; font-size:11px; font-weight:700; color:var(--secondary); border:1px solid var(--border); white-space:nowrap;">결석 <span style="color:${s.absent > 0 ? 'var(--error)' : 'var(--text)'}; margin-left:3px;">${s.absent}</span></div>
            </div>
        </div>
    `;
}

// [POLISH] 일정 섹션: 오렌지(오늘) vs 보라(주간) 은은한 컬러 분리
function renderTodoSections() {
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const nextWeekTime = todayTime + 7 * 24 * 60 * 60 * 1000;
    const nextWeekStr = new Date(nextWeekTime).toLocaleDateString('sv-SE');
    const getMemoDate = (m) => String(m.memo_date || m.memoDate || m.date || '').split('T')[0].split(' ')[0];
    const isMemoDone = (m) => m.is_done == 1 || m.is_done === true || m.isDone === true;
    const isMemoPinned = (m) => m.is_pinned == 1 || m.is_pinned === true || m.isPinned === true;

    const rowBase = `
        height:52px;
        min-height:52px;
        max-height:52px;
        padding:0 16px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        box-sizing:border-box;
        overflow:hidden;
    `;

    const todayMemos = state.db.operation_memos.filter(m => {
        const memoDate = getMemoDate(m);
        return !isMemoDone(m) && (isMemoPinned(m) || memoDate === todayStr);
    });
    
    const upcomingExams = state.db.exam_schedules.filter(e => e.exam_date >= todayStr && e.exam_date <= nextWeekStr);
    const upcomingAcademySchedules = (state.db.academy_schedules || []).filter(s =>
        String(s.is_deleted || 0) !== '1' &&
        String(s.target_scope || 'global') === 'global' &&
        s.schedule_date >= todayStr &&
        s.schedule_date <= nextWeekStr
    );

    const todayHtml = todayMemos.length ? todayMemos.map(m => {
        const isPinned = isMemoPinned(m);
        return `
        <div style="${rowBase} border-bottom:1px solid rgba(99,102,241,0.1); background:transparent;">
            <label onclick="event.stopPropagation()" style="display:flex; align-items:center; gap:12px; flex:1; min-width:0; cursor:pointer;">
                <input type="checkbox" onclick="event.stopPropagation()" onchange="toggleMemoDone('${m.id}', this.checked)" style="transform:scale(1.15); margin:0; accent-color:#6366f1; flex-shrink:0;">
                <span style="font-size:13px; font-weight:700; color:var(--text); ${isPinned ? 'color:var(--primary);' : ''} white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    ${isPinned ? `<span style="background:rgba(26,92,255,0.1); padding:2px 6px; border-radius:10px; font-size:11px; margin-right:6px;">고정</span> ` : ''}${apEscapeHtml(m.content)}
                </span>
            </label>
        </div>
    `}).join('') : `<div style="${rowBase} justify-content:center; font-size:13px; font-weight:600; color:var(--secondary); text-align:center;">오늘 등록된 할 일이 없습니다.</div>`;

    let upcomingHtml = '';
    const upcomingItems = [];
    upcomingExams.forEach(e => upcomingItems.push({ type: 'exam', date: e.exam_date, item: e }));
    upcomingAcademySchedules.forEach(s => upcomingItems.push({ type: 'academy', date: s.schedule_date, item: s }));
    
    upcomingItems.sort((a,b) => a.date.localeCompare(b.date));

    if (upcomingItems.length) {
        upcomingHtml = upcomingItems.slice(0, 5).map(u => {
            const timeVal = apParseLocalDateTime(u.date);
            const diffTime = timeVal !== null ? (timeVal - todayTime) : 0;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const dDay = diffDays === 0 ? 'D-Day' : `D-${diffDays}`;

            if (u.type === 'exam') {
                const e = u.item;
                const displayTitle = e.exam_name ? `${apEscapeHtml(e.school_name || '일반')} ${apEscapeHtml(e.grade || '')} ${apEscapeHtml(e.exam_name)}` : `${apEscapeHtml(e.school_name || '일정 확인')}`;
                return `<div onclick="event.stopPropagation(); openExamScheduleModal()" style="${rowBase} cursor:pointer; font-size:13px; font-weight:700; color:var(--text); border-bottom:1px solid rgba(5,150,105,0.08); background:transparent;">
                    <div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${displayTitle}</div>
                    <span style="font-size:11px; color:#059669; background:rgba(5,150,105,0.08); padding:4px 8px; border-radius:10px; font-weight:700; white-space:nowrap; flex-shrink:0;">${dDay}</span>
                </div>`;
            }

            const s = u.item;
            const isClosed = s.schedule_type === 'closed' || s.is_closed === true || s.is_closed === 1;
            const label = isClosed ? '휴무' : '기타';
            const labelColor = isClosed ? 'var(--warning)' : 'var(--primary)';
            const labelBg = isClosed ? 'rgba(255,165,2,0.12)' : 'rgba(26,92,255,0.08)';
            const title = s.title || (isClosed ? '휴무' : '일정');
            return `<div onclick="event.stopPropagation(); openExamScheduleModal()" style="${rowBase} cursor:pointer; font-size:13px; font-weight:700; color:var(--text); border-bottom:1px solid rgba(5,150,105,0.08); background:transparent;">
                <div style="min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><span style="font-size:11px; color:${labelColor}; background:${labelBg}; padding:3px 8px; border-radius:8px; margin-right:6px;">${label}</span>${apEscapeHtml(title)}${s.memo ? ` <span style="color:var(--secondary); font-weight:600;">${apEscapeHtml(s.memo)}</span>` : ''}</div>
                <span style="font-size:11px; background:rgba(5,150,105,0.08); color:#059669; padding:4px 8px; border-radius:10px; font-weight:700; white-space:nowrap; flex-shrink:0;">${dDay}</span>
            </div>`;
        }).join('');
    }

    return `
        <div style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                <h3 style="margin:0; font-size:15px; font-weight:700; color:var(--text);">오늘일정</h3>
            </div>
            <div onclick="openTodoMemoModal()" style="cursor:pointer; margin-bottom:18px; overflow:hidden; border-radius:16px; border:1px solid rgba(99,102,241,0.2); background:rgba(99,102,241,0.04);">
                ${todayHtml}
            </div>
            
            ${upcomingHtml ? `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
                    <h3 style="margin:0; font-size:15px; font-weight:700; color:var(--text);">주간일정</h3>
                </div>
                <div onclick="openExamScheduleModal()" style="cursor:pointer; overflow:hidden; border-radius:16px; border:1px solid rgba(5,150,105,0.2); background:rgba(5,150,105,0.04);">
                    ${upcomingHtml}
                </div>
            ` : ''}
        </div>
    `;
}

// [NEW] 오늘일지 카드 생성 함수 (요일 필터 정밀 적용)
function renderTodayJournalCard(data) {
    const todayClasses = state.db.classes.filter(c => {
        if (Number(c.is_active) === 0) return false;
        if (!isMiddleSchoolClass(c)) return false;
        if (!isClassVisibleForCurrentTeacher(c)) return false;

        const summary = data.classSummaries[c.id];
        if (!summary || !summary.isScheduled || summary.activeCount === 0) return false;
        return true;
    });

    const contentHtml = todayClasses.length === 0
        ? `<span style="font-size:14px; font-weight:600; color:var(--secondary);">수업 없음</span>`
        : `<span style="font-size:14px; font-weight:700; color:var(--text);">${todayClasses.map(c => `${apEscapeHtml(c.name)} ${data.classSummaries[c.id].present}/${data.classSummaries[c.id].activeCount}`).join(' · ')}</span>`;

    return `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:0 4px;">
            <h3 style="margin:0; font-size:15px; font-weight:700; color:var(--text);">오늘일지</h3>
        </div>
        <div id="dashboard-journal-card" onclick="if(typeof openDailyJournalModal === 'function') openDailyJournalModal(); else toast('불러오기 실패', 'warn');"
             style="background:rgba(217,119,6,0.06); border:1px solid rgba(217,119,6,0.2); border-radius:16px; height:52px; min-height:52px; max-height:52px; padding:0 16px; box-sizing:border-box; cursor:pointer; margin-bottom:18px; display:flex; justify-content:space-between; align-items:center; gap:12px; overflow:hidden;">
            <div id="dashboard-journal-content" style="min-width:0; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                ${contentHtml}
            </div>
            <span style="font-size:18px; font-weight:700; color:var(--text); flex-shrink:0;">›</span>
        </div>
    `;
}

// [POLISH] 메인 대시보드: 제목 규격화 및 마감 배너 시각적 축소
function renderDashboard() {
    if (state?.auth?.role === 'admin') {
        if (typeof renderAdminControlCenter === 'function') {
            return renderAdminControlCenter();
        }
        return;
    }

    state.ui.currentClassId = null;
    if (typeof renderAppDrawer === 'function') renderAppDrawer();
    const data = computeDashboardData();
    const root = document.getElementById('app-root');

    const shortcutRow = `
        <div style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:18px;">
            <button class="btn" 
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#2563eb; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof renderTimetable === 'function') renderTimetable(); else toast('불러오기 실패', 'warn');">
                시간표
            </button>
            <button class="btn" 
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#0891b2; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="if(typeof openAttendanceLedger === 'function') openAttendanceLedger(); else toast('불러오기 실패', 'warn');">
                출석부
            </button>
            <button class="btn" 
                    style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:var(--surface); color:#0f172a; box-shadow:0 1px 2px rgba(0,0,0,0.05); border:none;"
                    onclick="window.location.href='../archive/index';">
                아카이브
            </button>
        </div>
    `;

    const todayJournalCard = typeof renderTodayJournalCard === 'function' ? renderTodayJournalCard(data) : '';
    const todoSections = renderTodoSections();
    
    if (!state.ui.dashboardClassTab) state.ui.dashboardClassTab = 'all';
    const tab = state.ui.dashboardClassTab;

    const tabHtml = `
        <div style="display:flex; gap:8px; background:var(--surface-2); padding:4px; border-radius:12px; margin-bottom:12px;">
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:${tab==='all'?'var(--surface)':'transparent'}; color:${tab==='all'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='all'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='all'; renderDashboard()">전체</button>
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:${tab==='middle'?'var(--surface)':'transparent'}; color:${tab==='middle'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='middle'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='middle'; renderDashboard()">중등</button>
            <button class="btn" style="flex:1; height:44px; min-height:44px; max-height:44px; padding:0 12px; border-radius:10px; font-size:13px; font-weight:700; background:${tab==='high'?'var(--surface)':'transparent'}; color:${tab==='high'?'var(--text)':'var(--secondary)'}; box-shadow:${tab==='high'?'0 1px 2px rgba(0,0,0,0.05)':'none'}; border:none;" onclick="state.ui.dashboardClassTab='high'; renderDashboard()">고등</button>
        </div>
    `;

    let filteredClasses = sortClassesForDashboard(state.db.classes.filter(c => Number(c.is_active) !== 0));
    filteredClasses = filteredClasses.filter(c => {
        if (tab === 'middle') return isMiddleSchoolClass(c);
        if (tab === 'high') return !isMiddleSchoolClass(c);
        return true;
    });

    const classStatus = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding:0 4px;">
            <h3 style="margin:0; font-size:15px; font-weight:700; color:var(--text);">학급관리</h3>
        </div>
        ${tabHtml}
        <div style="display:flex; flex-direction:column; gap:8px; margin-bottom:40px;">${filteredClasses.map(c => renderClassSummaryCard(c, data)).join('')}</div>
    `;

    root.innerHTML = `<div style="width:100%; max-width:850px; margin:0 auto; padding:0 16px 24px; box-sizing:border-box;">
        ${shortcutRow}
        ${todayJournalCard}
        ${todoSections}
        ${classStatus}
    </div>`;
}

// [RESTORE] computeTodayCloseData: 원본 복구
function computeTodayCloseData() {
    const today = new Date().toLocaleDateString('sv-SE');

    const scheduledActive = state.db.students.filter(s => {
        if (s.status !== '재원') return false;
        const cid = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const cls = state.db.classes.find(c => c.id === cid);
        if (cls && Number(cls.is_active) === 0) return false;
        return isClassScheduledTodayForDashboard(cid);
    });

    const absents = [];
    const hwMisses = [];

    scheduledActive.forEach(s => {
        const cid = state.db.class_students.find(m => m.student_id === s.id)?.class_id;
        const className = state.db.classes.find(c => c.id === cid)?.name || '미배정';
        const info = { id: s.id, name: s.name, className };

        const att = state.db.attendance.find(a => String(a.student_id) === String(s.id) && a.date === today);
        if (att?.status === '결석') absents.push(info);

        const hw = state.db.homework.find(h => String(h.student_id) === String(s.id) && h.date === today);
        if (hw?.status === '미완료') hwMisses.push(info);
    });

    const totalActive = scheduledActive.length;
    return {
        totalActive,
        absents,
        hwMisses,
        allClear: absents.length === 0 && hwMisses.length === 0
    };
}

// [RESTORE] quickToggleAtt: 원본 복구
async function quickToggleAtt(sid, status, tab = 'att') {
    const today = new Date().toLocaleDateString('sv-SE');
    const r = await api.patch('attendance', { studentId: sid, status, date: today });
    if (!r?.success) { toast('출결 처리 실패', 'warn'); return; }
    await refreshDataOnly();
    openTodayCloseModal(tab);
}

// [RESTORE] quickToggleHw: 원본 복구
async function quickToggleHw(sid, status, tab = 'hw') {
    const today = new Date().toLocaleDateString('sv-SE');
    const r = await api.patch('homework', { studentId: sid, status, date: today });
    if (!r?.success) { toast('숙제 처리 실패', 'warn'); return; }
    await refreshDataOnly();
    openTodayCloseModal(tab);
}

function openTodayCloseModal(tab = 'att') {
    const d = computeTodayCloseData();

    const tabs = [
        { key: 'att',  label: `결석 ${d.absents.length}명`,  list: d.absents,  emptyMsg: '결석 학생이 없습니다.' },
        { key: 'hw',   label: `미완료 ${d.hwMisses.length}명`, list: d.hwMisses, emptyMsg: '숙제 미완료 학생이 없습니다.' }
    ];
    const cur = tabs.find(t => t.key === tab) || tabs[0];

    const tabBtns = tabs.map(t => `
        <button onclick="openTodayCloseModal('${t.key}')" style="
            flex:1; padding:12px; border:none; border-radius:10px; font-size:13px; font-weight:700; transition:all 0.2s;
            background:${t.key === tab ? 'var(--primary)' : 'var(--surface-2)'};
            color:${t.key === tab ? 'white' : 'var(--secondary)'};
            cursor:pointer;">
            ${t.label}
        </button>
    `).join('');

    const grouped = cur.list.reduce((acc, item) => {
        if(!acc[item.className]) acc[item.className] = [];
        acc[item.className].push(item);
        return acc;
    }, {});

    // [Master Fix] 학급 정렬 알고리즘 적용
    const sortedClassNames = Object.keys(grouped).sort((a, b) => {
        const clsA = state.db.classes.find(c => c.name === a);
        const clsB = state.db.classes.find(c => c.name === b);
        const rankA = clsA ? getClassGradeRank(clsA.grade) : 99;
        const rankB = clsB ? getClassGradeRank(clsB.grade) : 99;
        if (rankA !== rankB) return rankA - rankB;
        return a.localeCompare(b);
    });

    const rows = cur.list.length
        ? sortedClassNames.map(cName => {
            const classHeader = `<div style="background:var(--surface-2); padding:8px 12px; font-size:12px; font-weight:700; color:var(--secondary); margin-top:12px; border-radius:8px;">${apEscapeHtml(cName)}</div>`;
            const studentRows = grouped[cName].map(s => {
                let actionBtns = '';
                if (tab === 'att') {
                    actionBtns = `<div style="display:flex; gap:8px; margin-top:12px;"><button class="btn btn-primary" style="flex:1; padding:10px; font-size:12px; border-radius:8px;" onclick="quickToggleAtt('${s.id}', '등원', '${tab}')">등원 (취소)</button><button class="btn" style="flex:1; padding:10px; font-size:12px; color:var(--error); background:rgba(255,71,87,0.1); border:none; border-radius:8px; cursor:default; font-weight:700;">결석 유지</button></div>`;
                } else if (tab === 'hw') {
                    actionBtns = `<div style="display:flex; gap:8px; margin-top:12px;"><button class="btn btn-primary" style="flex:1; padding:10px; font-size:12px; border-radius:8px;" onclick="quickToggleHw('${s.id}', '완료', '${tab}')">완료 (취소)</button><button class="btn" style="flex:1; padding:10px; font-size:12px; color:var(--warning); background:rgba(255,165,2,0.12); border:none; border-radius:8px; cursor:default; font-weight:700;">미완료 유지</button></div>`;
                }
                return `
                    <div style="padding:16px 8px; border-bottom:1px solid var(--border); background:var(--surface);">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <div onclick="closeModal();renderStudentDetail('${s.id}')" style="cursor:pointer; flex:1;">
                                <span style="font-weight:700; font-size:15px; color:var(--text);">${apEscapeHtml(s.name)}</span>
                            </div>
                            <span onclick="closeModal();renderStudentDetail('${s.id}')" style="font-size:11px; font-weight:700; color:var(--primary); background:rgba(26,92,255,0.1); padding:4px 8px; border-radius:6px; cursor:pointer;">상세 보기</span>
                        </div>
                        ${actionBtns}
                    </div>`;
            }).join('');
            return classHeader + studentRows;
        }).join('')
        : `<div style="padding:40px 20px; text-align:center; color:var(--secondary); font-weight:600; font-size:13px;">${cur.emptyMsg}</div>`;

    showModal('예외 현황', `<div style="display:flex; gap:8px; margin-bottom:16px;">${tabBtns}</div><div>${rows}</div>`);
}

// [RESTORE] getTodayExamConfig: 원본 복구
function getTodayExamConfig() {
    try {
        const raw = localStorage.getItem('AP_TODAY_EXAM');
        if (!raw) return null;
        const cfg = JSON.parse(raw);
        const today = new Date().toLocaleDateString('sv-SE');
        if (cfg.date !== today || !cfg.title) { localStorage.removeItem('AP_TODAY_EXAM'); return null; }
        return { date: cfg.date, title: String(cfg.title), q: parseInt(cfg.q, 10) || 20 };
    } catch (e) { localStorage.removeItem('AP_TODAY_EXAM'); return null; }
}

// [RESTORE] setTodayExamConfig: 원본 복구
function setTodayExamConfig(title, q) {
    const today = new Date().toLocaleDateString('sv-SE');
    const validQ = parseInt(q, 10) || 20;
    localStorage.setItem('AP_TODAY_EXAM', JSON.stringify({ date: today, title: String(title), q: validQ }));
}

// [RESTORE] clearTodayExamConfig: 원본 복구
function clearTodayExamConfig() {
    localStorage.removeItem('AP_TODAY_EXAM');
    if(state.auth.role === 'admin' && typeof renderAdminControlCenter === 'function') renderAdminControlCenter();
    else renderDashboard();
}

function openTodayExamSetModal() {
    const cfg = getTodayExamConfig();
    showModal('오늘 시험 설정', `
        <div style="display:flex; flex-direction:column; gap:12px;">
            <div style="font-size:12px; color:var(--secondary); background:var(--surface-2); padding:10px; border-radius:8px; line-height:1.5;">오늘 전체 학급에 적용될 시험 기준을 설정합니다.<br>(QR 코드 생성 시에도 자동 연동됩니다)</div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin:4px 0;">
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='쪽지시험'">쪽지시험</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='단원평가'">단원평가</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='월말평가'">월말평가</button>
                <button class="btn" style="padding:6px 10px; font-size:11px; background:var(--surface-2); border:none;" onclick="document.getElementById('set-exam-title').value='모의고사'">모의고사</button>
            </div>
            <input id="set-exam-title" class="btn" placeholder="시험명 직접 입력" value="${cfg?.title || ''}" style="text-align:left; width:100%; background:var(--surface-2); border:none;">
            <input id="set-exam-q" type="number" class="btn" placeholder="문항 수 (기본 20)" value="${cfg?.q || 20}" min="1" max="50" style="text-align:left; width:100%; background:var(--surface-2); border:none;">
            <div style="display:flex; gap:8px; margin-top:12px;">
                <button class="btn" style="flex:1; padding:12px; font-size:12px; color:var(--error); background:rgba(255,71,87,0.1); border:none; font-weight:700;" onclick="clearTodayExamConfig(); closeModal();">시험 없음</button>
                <button class="btn btn-primary" style="flex:1.5; padding:12px; font-size:12px; font-weight:700;" onclick="handleSetTodayExam()">저장 및 적용</button>
            </div>
        </div>
    `);
}

function handleSetTodayExam() {
    const t = document.getElementById('set-exam-title').value.trim();
    const q = parseInt(document.getElementById('set-exam-q').value, 10) || 20;
    if (!t) { toast('시험명을 입력하세요.', 'warn'); return; }
    setTodayExamConfig(t, q); 
    toast('오늘 시험이 설정되었습니다.', 'info'); 
    closeModal(); 
    if(state.auth.role === 'admin' && typeof renderAdminControlCenter === 'function') renderAdminControlCenter();
    else renderDashboard();
}

function extractJournalUnitAndNote(rawNote) {
    const raw = String(rawNote || '').trim();
    const result = { units: '', note: '' };
    if (!raw) return result;

    const match = raw.match(/^\[단원선택\]\s*([^\n]*)\n?/);
    if (!match) {
        result.note = raw;
        return result;
    }

    result.units = String(match[1] || '').trim();
    result.note = raw.replace(/^\[단원선택\]\s*[^\n]*\n?/, '').trim();
    return result;
}

function compactJournalUnitText(text) {
    return String(text || '').replace(/\s+/g, '').trim();
}

function formatJournalProgressLine(progress, unitText) {
    const title = String(progress?.textbook_title_snapshot || '교재').trim() || '교재';
    const progressText = String(progress?.progress_text || '').trim() || '(기록 없음)';
    const compactUnit = compactJournalUnitText(unitText);

    if (compactUnit) {
        return `  * ${title} ${compactUnit}-${progressText}`;
    }

    return `  * ${title}: ${progressText}`;
}

function appendJournalNote(text, note) {
    const clean = String(note || '').trim();
    if (!clean) return text;

    const lines = clean.split('\n').map(v => v.trim()).filter(Boolean);
    if (lines.length === 0) return text;

    if (lines.length === 1) {
        return text + `- 특이사항: ${lines[0]}\n`;
    }

    text += `- 특이사항:\n`;
    lines.forEach(line => {
        text += `  ${line}\n`;
    });
    return text;
}

function buildJournalContent(dateStr) {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');
    let text = `[AP Math 운영 일지 - ${targetDate}]\n작성자: ${state.ui.userName}\n\n`;

    const parts = targetDate.split('-');
    const targetDayIdx = String(new Date(parts[0], parts[1]-1, parts[2]).getDay());

    const activeClasses = state.db.classes.filter(c => {
        if (Number(c.is_active) === 0) return false;
        if (!isMiddleSchoolClass(c)) return false;
        if (!isClassVisibleForCurrentTeacher(c)) return false;

        // 수업 요일이 비어 있으면 매일 수업으로 간주한다.
        if (!c.schedule_days) return true;

        // 제출일/선택일 기준 해당 요일 반만 출력한다.
        return String(c.schedule_days)
            .split(',')
            .map(v => v.trim())
            .includes(targetDayIdx);
    });

    if (activeClasses.length === 0) {
        text += `해당 날짜에 담당 학급이 없습니다.\n`;
        return text;
    }

    activeClasses.forEach(cls => {
        text += `■ ${cls.name}반\n`;

        const memberIds = state.db.class_students.filter(m => String(m.class_id) === String(cls.id)).map(m => String(m.student_id));
        const students = state.db.students.filter(s => memberIds.includes(String(s.id)) && s.status === '재원');
        const total = students.length;

        const absents = [];
        const lates = [];
        const makeups = [];
        const hwMiss = [];

        students.forEach(s => {
            const att = state.db.attendance.find(a => String(a.student_id) === String(s.id) && a.date === targetDate);
            const hw = state.db.homework.find(h => String(h.student_id) === String(s.id) && h.date === targetDate);
            const attStatus = String(att?.status || '').trim();
            const tagList = String(att?.tags || '')
                .split(',')
                .map(v => v.trim())
                .filter(Boolean);

            if (attStatus === '결석') absents.push(s.name);
            if (attStatus === '지각' || tagList.includes('지각')) lates.push(s.name);
            if (attStatus === '보강' || tagList.includes('보강')) makeups.push(s.name);
            if (hw?.status === '미완료') hwMiss.push(s.name);
        });

        const attendanceCount = Math.max(0, total - absents.length);
        const homeworkCount = Math.max(0, total - hwMiss.length);

        text += `- 출석: ${attendanceCount}/${total}\n`;
        text += `- 숙제: ${homeworkCount}/${total}\n`;
        if (absents.length > 0) text += `- 결석: ${absents.join(', ')}\n`;
        if (lates.length > 0) text += `- 지각: ${lates.join(', ')}\n`;
        if (makeups.length > 0) text += `- 보강: ${makeups.join(', ')}\n`;
        if (hwMiss.length > 0) text += `- 숙제 미완료: ${hwMiss.join(', ')}\n`;

        const dailyRecord = (state.db.class_daily_records || []).find(r => String(r.class_id) === String(cls.id) && r.date === targetDate);
        if (dailyRecord) {
            const noteData = extractJournalUnitAndNote(dailyRecord.special_note);
            const progresses = (state.db.class_daily_progress || []).filter(p => String(p.record_id) === String(dailyRecord.id));
            if (progresses.length > 0) {
                text += `- 진도:\n`;
                progresses.forEach(p => {
                    text += formatJournalProgressLine(p, noteData.units) + `\n`;
                });
            } else text += `- 진도: (기록 없음)\n`;

            text = appendJournalNote(text, noteData.note);
        } else {
            text += `- 진도: (수업 기록 미입력)\n`;
        }

        const cns = (state.db.consultations || []).filter(c => c.date === targetDate && memberIds.includes(String(c.student_id)));
        if (cns.length > 0) {
            text += `- 상담:\n`;
            cns.forEach(cn => {
                const sName = students.find(s => String(s.id) === String(cn.student_id))?.name || '학생';
                text += `  * ${sName}: ${cn.content}\n`;
            });
        }

        text += `\n`;
    });

    return text.trim() + '\n';
}

function openDailyJournalModal(dateStr) {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');

    if (state.ui.viewScope === 'all' || state.auth.role === 'admin') {
        renderAdminJournalList(targetDate);
        return;
    }

    const journals = state.db.journals || [];
    const myJournal = journals.find(j => j.date === targetDate && j.teacher_name === state.ui.userName);

    const content = myJournal ? myJournal.content : buildJournalContent(targetDate);
    const status = myJournal ? myJournal.status : '작성중';
    const isLocked = status === '제출완료' || status === '결재완료';

    let actionBtns = '';
    if (!myJournal || status === '작성중') {
        actionBtns = `
            <button class="btn" style="flex:1; padding:14px; font-weight:700; background:var(--surface); color:var(--text);" onclick="saveJournal('작성중', null, '${targetDate}')">임시 저장</button>
            <button class="btn btn-primary" style="flex:1; padding:14px; font-weight:700;" onclick="saveJournal('제출완료', null, '${targetDate}')">제출</button>
        `;
    } else if (status === '제출완료') {
        actionBtns = `
            <button class="btn" style="flex:1; padding:14px; font-weight:700; color:var(--error); background:rgba(255,71,87,0.1); border:none;" onclick="saveJournal('작성중', '${myJournal.id}', '${targetDate}')">제출 취소 및 수정</button>
        `;
    }

    showModal('일지', `
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px; background:var(--surface-2); padding:10px 14px; border-radius:10px;">
            <b style="font-size:13px; color:var(--secondary);">작성 기준일</b>
            <input type="date" class="btn" value="${targetDate}" style="flex:1; text-align:left; border:none; background:transparent; padding:0; height:auto; min-height:0; font-size:14px; font-weight:700; color:var(--text);" onchange="openDailyJournalModal(this.value)">
        </div>
        ${status === '결재완료' ? `
            <div style="background:rgba(0,208,132,0.1); color:var(--success); padding:16px; border-radius:12px; margin-bottom:16px;">
                <b style="display:flex; align-items:center; gap:8px; font-size:14px;">원장님 확인 완료</b>
                ${myJournal.feedback ? `<div style="margin-top:10px; font-size:13px; background:var(--surface); padding:12px; border-radius:8px; color:var(--text);"><b>피드백:</b><br>${apEscapeHtml(myJournal.feedback)}</div>` : ''}
            </div>
        ` : ''}
        <textarea id="journal-content" class="btn" style="width:100%; height:250px; text-align:left; resize:vertical; font-family:inherit; font-size:14px; line-height:1.6; background:${isLocked ? 'var(--surface-2)' : 'var(--surface)'}; border:1px solid var(--border); color:var(--text);" ${isLocked ? 'readonly' : ''}>${apEscapeHtml(content)}</textarea>
        <div style="display:flex; gap:10px; margin-top:16px; flex-wrap:wrap;">
            ${actionBtns}
        </div>
    `);
}

async function saveJournal(status, existingId = null, targetDate) {
    const el = document.getElementById('journal-content');
    if (!el) return toast('일지 입력칸을 찾을 수 없습니다.', 'warn');

    const content = el.value;
    const journals = state.db.journals || [];
    const myJournal = journals.find(j => j.date === targetDate && j.teacher_name === state.ui.userName);

    const journalId = existingId || myJournal?.id;
    let result;
    if (journalId) {
        result = await api.patch(`daily-journals/${journalId}`, { content, status });
    } else {
        result = await api.post('daily-journals', { date: targetDate, content, status });
    }

    if (!result || result.error) return toast(result?.error || '저장 실패', 'error');

    toast(`저장 완료`, 'success');
    closeModal();
    await loadData();
}

function renderAdminJournalList(dateStr, teacherName = '') {
    const targetDate = dateStr || new Date().toLocaleDateString('sv-SE');
    const safeTeacher = String(teacherName || '').replace(/'/g, "\\'");
    let journals = (state.db.journals || []).filter(j => j.date === targetDate && j.status !== '작성중');
    if (teacherName) journals = journals.filter(j => j.teacher_name === teacherName);
    const title = teacherName ? `${teacherName} 선생님 일지` : '일지확인';
    
    const backBtn = teacherName ? `<button class="btn" style="width:100%; margin-bottom:16px; padding:14px; border-radius:12px; font-weight:700; background:var(--surface-2); border:none; color:var(--text);" onclick="closeModal(true)">닫기</button>` : '';
    
    const rows = journals.map(j => {
        const teacherArg = String(teacherName || j.teacher_name || '').replace(/'/g, "\\'");
        const statusText = j.status === '결재완료' ? '확인완료' : j.status;
        const statusColor = j.status === '결재완료' ? 'var(--success)' : 'var(--primary)';
        const statusBg = j.status === '결재완료' ? 'rgba(0,208,132,0.1)' : 'rgba(26,92,255,0.1)';
        
        return `
            <div class="card" style="padding:16px; margin-bottom:12px; cursor:pointer; border:1px solid var(--border); border-radius:16px; box-shadow:var(--shadow); background:var(--surface);" onclick="openAdminJournalFeedback('${j.id}', '${teacherArg}')">
                <div style="display:flex; justify-content:space-between; margin-bottom:10px; gap:8px; align-items:center;">
                    <b style="font-size:15px; color:var(--text);">${apEscapeHtml(j.teacher_name)} 선생님</b>
                    <span style="font-size:11px; font-weight:700; color:${statusColor}; background:${statusBg}; padding:4px 8px; border-radius:6px;">${apEscapeHtml(statusText)}</span>
                </div>
                <div style="font-size:13px; color:var(--text-soft); white-space:pre-wrap; max-height:60px; overflow:hidden; line-height:1.6;">${apEscapeHtml(j.content)}</div>
            </div>`;
    }).join('');
    
    showModal(`${apEscapeHtml(title)}`, `
        ${backBtn}
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px; background:var(--surface-2); padding:12px 14px; border-radius:12px;">
            <b style="font-size:13px; color:var(--secondary); white-space:nowrap;">기준일</b>
            <input type="date" class="btn" value="${targetDate}" style="flex:1; text-align:left; border:none; background:transparent; padding:0; height:auto; min-height:0; font-size:14px; font-weight:700; color:var(--text);" onchange="renderAdminJournalList(this.value, '${safeTeacher}')">
        </div>
        <div style="max-height:55vh; overflow-y:auto; padding-right:4px;">
            ${journals.length ? rows : `<div style="text-align:center; color:var(--secondary); padding:30px; font-weight:600; font-size:13px; background:var(--surface-2); border-radius:12px;">해당 날짜에 제출된 일지가 없습니다.</div>`}
        </div>
    `);
}

function openAdminJournalFeedback(id, teacherName = '') {
    const journal = (state.db.journals || []).find(j => j.id === id);
    if (!journal) return toast('일지를 찾을 수 없습니다.', 'warn');
    const safeTeacher = String(teacherName || journal.teacher_name || '').replace(/'/g, "\\'");
    
    showModal(`${apEscapeHtml(journal.teacher_name)} 선생님 일지`, `
        <textarea readonly class="btn" style="width:100%; height:200px; text-align:left; resize:vertical; font-size:14px; line-height:1.6; background:var(--surface-2); border:none; border-radius:12px; padding:16px; margin-bottom:12px; color:var(--text);">${apEscapeHtml(journal.content)}</textarea>
        <textarea id="journal-feedback" class="btn" placeholder="선생님께 전달할 피드백 (선택)" style="width:100%; height:90px; text-align:left; resize:vertical; border:1px solid var(--border); border-radius:12px; padding:14px; font-size:13px; background:var(--surface); color:var(--text);">${apEscapeHtml(journal.feedback || '')}</textarea>
        <div style="margin-top:16px;">
            <button class="btn btn-primary" style="width:100%; padding:16px; border-radius:14px; font-weight:700; font-size:15px;" onclick="approveJournal('${journal.id}', '${journal.date}', '${safeTeacher}')">확인완료</button>
        </div>
    `);
}

function approveJournal(id, dateStr, teacherName = '') {
    const feedback = document.getElementById('journal-feedback')?.value.trim() || '';
    return api.patch(`daily-journals/${id}`, { feedback, status: '결재완료' }).then(async result => {
        if (!result || result.error) return toast(result?.error || '저장 실패', 'error');
        toast('저장 완료', 'success');
        closeModal();
        await loadData();
        renderAdminJournalList(dateStr, teacherName);
    });
}

function renderAdminTeacherCards(todayStr) {
    const activeClasses = state.db.classes.filter(c => Number(c.is_active) !== 0);
    const teacherMap = {};
    activeClasses.forEach(c => {
        const tName = String(c.teacher_name || '담당').trim();
        if (!tName || tName === '담당') return;
        if (!teacherMap[tName]) teacherMap[tName] = [];
        teacherMap[tName].push(c);
    });
    const teacherNames = Object.keys(teacherMap).filter(Boolean).sort((a, b) => a.localeCompare(b, 'ko'));
    if (!teacherNames.length) return `<div style="text-align:center; padding:24px; color:var(--secondary); font-weight:600; background:var(--surface-2); border-radius:16px;">등록된 선생님이 없습니다.</div>`;
    
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    return teacherNames.map(tName => {
        const myClasses = teacherMap[tName];
        const myClassIds = myClasses.map(c => String(c.id));
        const myStudentIds = [...new Set(state.db.class_students.filter(m => myClassIds.includes(String(m.class_id))).map(m => String(m.student_id)))];
        const activeStudents = state.db.students.filter(s => myStudentIds.includes(String(s.id)) && s.status === '재원');
        const recentStudents = activeStudents.filter(s => adminIsRecentStudent(s, todayTime, 30));
        const scheduledClasses = myClasses.filter(c => isClassScheduledTodayForDashboard(c.id));
        const safeName = String(tName).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
        const initial = apEscapeHtml(String(tName || '').charAt(0));
        
        return `
            <div class="card ap-admin-teacher-card" style="padding:16px; margin:0; min-height:190px; height:100%; border:1px solid var(--border); border-radius:20px; background:var(--surface); box-shadow:var(--shadow); display:flex; flex-direction:column; justify-content:space-between; gap:14px; box-sizing:border-box;">
                <div style="display:flex; align-items:flex-start; gap:12px; min-width:0;">
                    <div style="width:42px; height:42px; border-radius:14px; background:var(--surface-2); color:var(--primary); display:flex; align-items:center; justify-content:center; font-size:17px; font-weight:800; flex-shrink:0;">${initial}</div>
                    <div style="min-width:0; flex:1;">
                        <div style="font-size:16px; font-weight:800; color:var(--text); line-height:1.25; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(tName)} 선생님</div>
                        <div style="font-size:12px; color:var(--secondary); font-weight:700; margin-top:4px; line-height:1.45;">담당반 ${myClasses.length}개 · 재원 ${activeStudents.length}명 · 최근 등록 ${recentStudents.length}명</div>
                        <div style="font-size:12px; color:var(--secondary); font-weight:700; margin-top:2px; line-height:1.45;">오늘 수업 ${scheduledClasses.length}개</div>
                    </div>
                </div>
                <div style="display:flex; flex-direction:column; gap:8px; margin-top:auto;">
                    <button class="btn btn-primary" style="width:100%; min-height:38px; border-radius:12px; font-size:12px; font-weight:800; box-shadow:none;" onclick="event.stopPropagation(); renderAdminJournalList(new Date().toLocaleDateString('sv-SE'), '${safeName}')">일지 확인</button>
                    <button class="btn" style="width:100%; min-height:38px; border-radius:12px; font-size:12px; font-weight:800; background:var(--surface-2); border:none; color:var(--text);" onclick="event.stopPropagation(); renderAdminTeacherStudents('${safeName}')">담당반 보기</button>
                </div>
            </div>`;
    }).join('');
}

function openAdminTeacherPanel(teacherName) {
    state.ui.currentAdminTeacherName = teacherName;
    const safeName = String(teacherName || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    renderAdminJournalList(new Date().toLocaleDateString('sv-SE'), safeName);
}

function renderAdminTeacherAllStudents(teacherName) {
    const safeName = String(teacherName || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    const myClasses = state.db.classes.filter(c => String(c.teacher_name || '담당').trim() === teacherName && Number(c.is_active) !== 0);
    const myClassIds = myClasses.map(c => String(c.id));
    const myStudentIds = [...new Set((state.db.class_students || [])
        .filter(m => myClassIds.includes(String(m.class_id)))
        .map(m => String(m.student_id)))];
    const students = (state.db.students || [])
        .filter(s => myStudentIds.includes(String(s.id)) && adminNormalizeStatus(s.status) === '재원')
        .sort((a, b) => String(a.grade || '').localeCompare(String(b.grade || ''), 'ko') || String(a.name || '').localeCompare(String(b.name || ''), 'ko'));

    const rows = students.map(s => {
        const cls = adminGetStudentClass(s.id);
        return `
            <button class="btn" style="width:100%; min-height:48px; padding:10px 12px; border-radius:14px; border:1px solid var(--border); background:var(--surface); box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:12px; text-align:left;" onclick="closeModal(true); renderStudentDetail('${String(s.id).replace(/'/g, "\\'")}')">
                <div style="min-width:0; flex:1;">
                    <div style="font-size:13px; font-weight:800; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(s.name || '')}</div>
                    <div style="font-size:11px; font-weight:700; color:var(--secondary); margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(s.school_name || '')} ${apEscapeHtml(s.grade || '')}</div>
                </div>
                <span style="font-size:11px; font-weight:800; color:var(--primary); background:rgba(26,92,255,0.08); padding:4px 8px; border-radius:999px; white-space:nowrap;">${apEscapeHtml(cls?.name || '미배정')}</span>
            </button>
        `;
    }).join('');

    showModal(`${apEscapeHtml(teacherName)} 선생님 전체 학생 (${students.length}명)`, `
        <button class="btn" style="width:100%; margin-bottom:12px; min-height:42px; border-radius:12px; font-weight:800; background:var(--surface-2); border:none; color:var(--text);" onclick="renderAdminTeacherStudents('${safeName}')">담당반 보기</button>
        <div style="max-height:62vh; overflow-y:auto; display:flex; flex-direction:column; gap:7px; padding-right:4px;">
            ${rows || `<div style="text-align:center; padding:30px; color:var(--secondary); font-weight:700; background:var(--surface-2); border-radius:16px;">재원생이 없습니다.</div>`}
        </div>
    `);
}

function renderAdminTeacherStudents(teacherName) {
    const safeName = String(teacherName || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    const myClasses = sortClassesForDashboard(state.db.classes.filter(c => String(c.teacher_name || '담당').trim() === teacherName && Number(c.is_active) !== 0));
    const todayStr = new Date().toLocaleDateString('sv-SE');
    const todayTime = apParseLocalDateTime(todayStr) || Date.now();
    const myClassIds = myClasses.map(c => String(c.id));
    const myStudentIds = [...new Set((state.db.class_students || [])
        .filter(m => myClassIds.includes(String(m.class_id)))
        .map(m => String(m.student_id)))];
    const activeStudents = (state.db.students || []).filter(s => myStudentIds.includes(String(s.id)) && adminNormalizeStatus(s.status) === '재원');
    const recentStudents = activeStudents.filter(s => adminIsRecentStudent(s, todayTime, 30));

    const rows = myClasses.map(cls => {
        const safeClassId = String(cls.id || '').replace(/'/g, "\\'");
        const studentIds = adminGetClassStudentIds(cls.id);
        const activeCount = (state.db.students || []).filter(s => studentIds.includes(String(s.id)) && adminNormalizeStatus(s.status) === '재원').length;
        const isToday = isClassScheduledTodayForDashboard(cls.id);
        return `
            <button class="btn" style="width:100%; min-height:50px; padding:10px 12px; border-radius:14px; border:1px solid var(--border); background:var(--surface); box-shadow:none; display:flex; align-items:center; justify-content:space-between; gap:12px; text-align:left;" onclick="closeModal(true); if(typeof renderClass==='function') renderClass('${safeClassId}'); else toast('반 화면을 불러오지 못했습니다.', 'warn');">
                <div style="min-width:0; flex:1;">
                    <div style="font-size:14px; font-weight:800; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.name || '')}</div>
                    <div style="font-size:11px; font-weight:700; color:var(--secondary); margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${apEscapeHtml(cls.grade || '')}${cls.time_label ? ` · ${apEscapeHtml(cls.time_label)}` : ''}</div>
                </div>
                <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
                    <span style="font-size:11px; font-weight:800; color:${isToday ? 'var(--primary)' : 'var(--secondary)'}; background:${isToday ? 'rgba(26,92,255,0.08)' : 'var(--surface-2)'}; padding:4px 8px; border-radius:999px; white-space:nowrap;">${isToday ? '오늘 수업' : '수업 없음'}</span>
                    <span style="font-size:12px; font-weight:800; color:var(--text); white-space:nowrap;">${activeCount}명</span>
                    <span style="font-size:18px; font-weight:800; color:var(--secondary); line-height:1;">›</span>
                </div>
            </button>
        `;
    }).join('');

    showModal(`${apEscapeHtml(teacherName)} 선생님 담당반`, `
        <div style="display:flex; flex-direction:column; gap:12px;">
            <div style="padding:14px; border-radius:16px; background:var(--surface-2); border:1px solid var(--border);">
                <div style="font-size:14px; font-weight:800; color:var(--text); line-height:1.4;">${apEscapeHtml(teacherName)} 선생님</div>
                <div style="font-size:12px; font-weight:700; color:var(--secondary); margin-top:4px; line-height:1.45;">담당반 ${myClasses.length}개 · 재원 ${activeStudents.length}명 · 최근 등록 ${recentStudents.length}명</div>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <button class="btn btn-primary" style="min-height:42px; border-radius:12px; font-size:12px; font-weight:800; box-shadow:none;" onclick="renderAdminJournalList(new Date().toLocaleDateString('sv-SE'), '${safeName}')">일지 확인</button>
                <button class="btn" style="min-height:42px; border-radius:12px; font-size:12px; font-weight:800; background:var(--surface-2); border:none; color:var(--text);" onclick="renderAdminTeacherAllStudents('${safeName}')">전체 학생 보기</button>
            </div>
            <div style="font-size:12px; font-weight:800; color:var(--secondary); padding:0 2px;">담당반</div>
            <div style="max-height:56vh; overflow-y:auto; display:flex; flex-direction:column; gap:7px; padding-right:4px;">
                ${rows || `<div style="text-align:center; padding:30px; color:var(--secondary); font-weight:700; background:var(--surface-2); border-radius:16px;">담당반이 없습니다.</div>`}
            </div>
        </div>
    `);
}

// [Button Audit Patch] Split-module duplicate handlers removed from dashboard.js.
// Source of truth: management.js, textbook.js, memo.js, schedule.js.
